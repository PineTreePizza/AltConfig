((buffer-size . 20) (buffer-checksum . "3f89a0a3225b3685ce2d25e97c7179ea61a64bc1"))
((emacs-buffer-undo-list (nil fontified t 20 . 21) (nil face (rainbow-delimiters-depth-1-face font-lock-string-face) 20 . 21) (20 . 21) nil (19 . 20) nil (11 . 19) nil (10 . 11) nil (2 . 10) nil (1 . 2) nil ("#" . -1) ((marker . 20) . -1) ((marker . 20) . -1) 2 nil ("include<" . -2) ((marker . 20) . -8) ((marker . 20) . -8) 10 nil ("iostream>
" . -10) ((marker . 20) . -10) ((marker . 20) . -9) 20 (t 25680 27596 697920 188000) nil (nil fontified t 19 . 20) (nil face (rainbow-delimiters-depth-1-face font-lock-string-face) 19 . 20) (19 . 20) nil (10 . 19) ("i" . 10) (10 . 11) ("iostream>" . -10) (10 . 19) ("iostre" . -10) 16 nil (13 . 16) nil ("t" . -13) 14 nil (10 . 14) nil (9 . 10) nil (" " . -9) 10 nil (4 . 10) nil (2 . 4) nil (1 . 2) nil ("
" . -1) ("#" . -2) 3 nil (2 . 3) nil (1 . 2) (t 25680 27163 946039 822000) nil ("#" . -1) 2 nil ("include <" . -2) 11 nil ("iostream>

//" . -11) 24 nil ("function " . -24) 33 nil ("that " . -33) 38 nil ("prints " . -38) 45 nil ("hello " . -45) 51 nil ("world " . -51) 57 nil ("to " . -57) 60 nil ("the " . -60) 64 nil ("standard " . -64) 73 nil ("output
" . -73) 80 nil ("void " . -80) 85 nil ("print_" . -85) 91 nil ("hellp


" . -91) 99 nil ("int " . -99) 103 nil ("main(){
  " . -103) 113 nil ("print_" . -113) 119 nil ("hello_" . -119) 125 nil ("world();
  " . -125) 136 nil ("return " . -136) 143 nil ("0;
" . -143) 146 nil ("}" . -146) 147 nil ("o" . -96) 97 nil (90 . 97) nil ("_" . -90) 91 nil (90 . 91) nil (" " . -90) 91 nil (85 . 91) nil (80 . 85) nil ("b" . -80) ("o" . -81) 82 nil (80 . 82) nil ("p" . -80) 81 nil (80 . 81) nil (81 . 81) (81 . 82) (80 . 80) (80 . 81) nil (114 . 115) nil (")" . -113) (113 . 114) (")" . -113) (113 . 114) (112 . 114) nil (103 . 112) nil ("k" . -103) 104 nil (101 . 104) nil (98 . 101) nil ("n" . -98) ("t" . -99) ("_" . -100) ("h" . -101) ("e" . -102) ("l" . -103) ("l" . -104) ("o" . -105) ("_" . -106) ("w" . -107) ("o" . -108) ("r" . -109) ("l" . -110) ("d" . -111) 112 nil (101 . 112) nil (98 . 101) nil ("u" . -98) 99 nil (95 . 99) nil ("p" . -95) ("r" . -96) ("i" . -97) ("n" . -98) ("t" . -99) ("_" . -100) 101 nil (100 . 101) nil (95 . 100) nil (93 . 95) nil (104 . 105) nil (96 . 104) nil (94 . 96) ("  " . 93) (93 . 96) (92 . 94) nil (91 . 93) nil (")" . -90) (90 . 91) (")" . -90) (90 . 91) (89 . 91) nil (86 . 89) nil ("i" . -86) ("a" . -87) 88 nil (81 . 88) nil ("p" . -81) ("r" . -82) 83 nil (81 . 83) nil (79 . 81) nil (" " . -79) 80 nil (68 . 80) nil (66 . 68) nil (45 . 66) nil ("s" . -45) ("t" . -46) 47 nil (29 . 47) nil ("o" . -29) 30 nil (28 . 30) nil ("i" . -28) 29 nil (24 . 29) nil (22 . 24) nil (20 . 22) nil (19 . 20) nil (11 . 19) nil (10 . 11) nil (9 . 10) nil ("<" . -9) 10 nil (9 . 10) nil (" " . -9) 10 nil (2 . 10) nil (1 . 2) nil ("
" . -1) ("#" . -2) 3 nil (2 . 3) nil ("#" . -1) 2 nil ("include <" . -2) 11 nil ("iostream>

//" . -11) 24 nil ("function " . -24) 33 nil ("that " . -33) 38 nil ("prints " . -38) 45 nil ("hello " . -45) 51 nil ("world " . -51) 57 nil ("to " . -57) 60 nil ("the " . -60) 64 nil ("buffer
" . -64) 71 nil ("void " . -71) 76 nil ("print_" . -76) 82 nil ("hello_" . -82) 88 nil ("world(){
  
}

" . -88) 103 nil ("int " . -103) 107 nil ("main(){
  
  " . -107) 120 nil ("print_" . -120) 126 nil ("hello_" . -126) 132) (emacs-pending-undo-list) (emacs-undo-equiv-table))