((buffer-size . 1765) (buffer-checksum . "e7b896f0a7b96e5fb7103d8de387451062e1ba1d"))
((emacs-buffer-undo-list nil (1553 . 1555) nil ("8" . -1553) ((marker . 1553) . -1) ((marker . 1553) . -1) ((marker . 1553) . -1) ((marker . 1555) . -1) ((marker . 1555) . -1) ((marker . 1553) . -1) 1554 (t 25700 6282 975633 630000) nil (260 . 261) nil ("2" . -260) ((marker . 1555) . -1) ((marker . 1555) . -1) ((marker . 260) . -1) ("0" . -261) ((marker . 1555) . -1) ((marker . 1555) . -1) ((marker . 260) . -1) 262 (t 25700 6254 461204 689000) nil (1554 . 1555) nil ("3" . -1554) ((marker . 1555) . -1) ((marker . 1553) . -1) ((marker . 1555) . -1) ("2" . -1555) ((marker . 1555) . -1) ((marker . 1553) . -1) ((marker . 1555) . -1) 1556 (t 25700 6033 331938 426000) nil (")" . 1507) (t 25700 6027 8599 719000) nil (1502 . 1506) nil ("c" . -1502) ("s" . -1503) ("v" . -1504) 1505 nil ("\"" . 1507) (1482 . 1507) ("alpaca_data_clea" . -1482) 1498 nil (1497 . 1498) nil ("n" . -1497) ("e" . -1498) ("a" . -1499) ("d" . -1500) 1501 nil (1484 . 1501) nil (1482 . 1484) (t 25700 6001 805244 51000) nil ("/content/alpaca_data_cleaned.json" . 1482) (t 25700 5990 938567 289000) nil (48 . 63) ("im" . -48) 50 nil (34 . 50) nil (33 . 34) (t 25700 5954 308531 94000) nil (1745 . 1746) 1679 nil (nil rear-nonsticky nil 1744 . 1745) (nil fontified nil 1706 . 1745) (1706 . 1745) nil ("256" . 1706) (nil rear-nonsticky t 1708 . 1709) nil (nil rear-nonsticky nil 1708 . 1709) (nil fontified nil 1706 . 1709) (1706 . 1709) nil (1705 . 1706) (t 25700 5879 65112 58000) nil (1533 . 1535) nil ("2" . -1533) ("4" . -1534) 1535 (t 25700 5759 521605 964000) nil (1110 . 1111) nil (" \"cuda\" if torch.cuda.is_available() else " . 1110) 1106 (t 25700 5685 268138 372000) nil ("from torch.utils.data import Dataset
import json

class ChatData(Dataset):
    def __init__(self, path: str, tokenizer):
        self.data = json.load(open(path, \"r\"))

        self.X = []
        for entry in self.data:
            instruction = entry['instruction']
            input_text = entry['input']
            output_text = entry['output']
            self.X.append(\"<start> \" + instruction + \" <human>: \" + input_text + \" <bot>: \" + output_text + \" <end>\")

        self.X = self.X[:200]

        print(self.X[0])

        self.X_encoded = tokenizer(self.X, max_length=256, truncation=True, padding=\"max_length\", return_tensors=\"pt\")
        self.input_ids = self.X_encoded['input_ids']
        self.attention_mask = self.X_encoded['attention_mask']

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return self.input_ids[idx], self.attention_mask[idx]" . 1746) (nil fontified t 2589 . 2591) (nil fontified t 2588 . 2589) (nil fontified t 2583 . 2588) (nil fontified t 2579 . 2583) (nil fontified t 2578 . 2579) (nil fontified t 2567 . 2578) (nil fontified t 2566 . 2567) (nil fontified t 2563 . 2566) (nil fontified t 2557 . 2563) (nil fontified t 2556 . 2557) (nil fontified t 2554 . 2556) (nil fontified t 2550 . 2554) (nil fontified t 2549 . 2550) (nil fontified t 2546 . 2549) (nil fontified t 2545 . 2546) (nil fontified t 2539 . 2545) (nil fontified t 2529 . 2539) (nil fontified t 2528 . 2529) (nil fontified t 2524 . 2528) (nil fontified t 2523 . 2524) (nil fontified t 2516 . 2523) (nil fontified t 2515 . 2516) (nil fontified t 2512 . 2515) (nil fontified t 2506 . 2512) (nil fontified t 2505 . 2506) (nil fontified t 2489 . 2505) (nil fontified t 2488 . 2489) (nil fontified t 2478 . 2488) (nil fontified t 2474 . 2478) (nil fontified t 2456 . 2474) (nil fontified t 2452 . 2456) (nil fontified t 2443 . 2452) (nil fontified t 2442 . 2443) (nil fontified t 2431 . 2442) (nil fontified t 2430 . 2431) (nil fontified t 2420 . 2430) (nil fontified t 2416 . 2420) (nil fontified t 2403 . 2416) (nil fontified t 2399 . 2403) (nil fontified t 2390 . 2399) (nil fontified t 2389 . 2390) (nil fontified t 2385 . 2389) (nil fontified t 2368 . 2385) (nil fontified t 2356 . 2368) (nil fontified t 2346 . 2356) (nil fontified t 2342 . 2346) (nil fontified t 2311 . 2342) (nil fontified t 2307 . 2311) (nil fontified t 2306 . 2307) (nil fontified t 2294 . 2306) (nil fontified t 2285 . 2294) (nil fontified t 2284 . 2285) (nil fontified t 2280 . 2284) (nil fontified t 2270 . 2280) (nil fontified t 2269 . 2270) (nil fontified t 2268 . 2269) (nil fontified t 2267 . 2268) (nil fontified t 2266 . 2267) (nil fontified t 2264 . 2266) (nil fontified t 2260 . 2264) (nil fontified t 2259 . 2260) (nil fontified t 2254 . 2259) (nil fontified t 2244 . 2254) (nil fontified t 2243 . 2244) (nil fontified t 2239 . 2243) (nil fontified t 2238 . 2239) (nil fontified t 2236 . 2238) (nil fontified t 2232 . 2236) (nil fontified t 2229 . 2232) (nil fontified t 2228 . 2229) (nil fontified t 2227 . 2228) (nil fontified t 2223 . 2227) (nil fontified t 2213 . 2223) (nil fontified t 2212 . 2213) (nil fontified t 2204 . 2212) (nil fontified t 2187 . 2204) (nil fontified t 2177 . 2187) (nil fontified t 2161 . 2177) (nil fontified t 2149 . 2161) (nil fontified t 2132 . 2149) (nil fontified t 2122 . 2132) (nil fontified t 2121 . 2122) (nil fontified t 2112 . 2121) (nil fontified t 2108 . 2112) (nil fontified t 2095 . 2108) (nil fontified t 2094 . 2095) (nil fontified t 2086 . 2094) (nil fontified t 2085 . 2086) (nil fontified t 2077 . 2085) (nil fontified t 2066 . 2077) (nil fontified t 2053 . 2066) (nil fontified t 2052 . 2053) (nil fontified t 2045 . 2052) (nil fontified t 2044 . 2045) (nil fontified t 2036 . 2044) (nil fontified t 2026 . 2036) (nil fontified t 2013 . 2026) (nil fontified t 2012 . 2013) (nil fontified t 1999 . 2012) (nil fontified t 1998 . 1999) (nil fontified t 1965 . 1998) (nil fontified t 1961 . 1965) (nil fontified t 1960 . 1961) (nil fontified t 1956 . 1960) (nil fontified t 1955 . 1956) (nil fontified t 1953 . 1955) (nil fontified t 1946 . 1953) (nil fontified t 1943 . 1946) (nil fontified t 1934 . 1943) (nil fontified t 1933 . 1934) (nil fontified t 1932 . 1933) (nil fontified t 1929 . 1932) (nil fontified t 1928 . 1929) (nil fontified t 1927 . 1928) (nil fontified t 1923 . 1927) (nil fontified t 1913 . 1923) (nil fontified t 1912 . 1913) (nil fontified t 1911 . 1912) (nil fontified t 1908 . 1911) (nil fontified t 1902 . 1908) (nil fontified t 1901 . 1902) (nil fontified t 1897 . 1901) (nil fontified t 1896 . 1897) (nil fontified t 1879 . 1896) (nil fontified t 1875 . 1879) (nil fontified t 1865 . 1875) (nil fontified t 1864 . 1865) (nil fontified t 1853 . 1864) (nil fontified t 1850 . 1853) (nil fontified t 1848 . 1850) (nil fontified t 1844 . 1848) (nil fontified t 1842 . 1844) (nil fontified t 1838 . 1842) (nil fontified t 1837 . 1838) (nil fontified t 1829 . 1837) (nil fontified t 1828 . 1829) (nil fontified t 1825 . 1828) (nil fontified t 1819 . 1825) (nil fontified t 1818 . 1819) (nil fontified t 1811 . 1818) (nil fontified t 1810 . 1811) (nil fontified t 1802 . 1810) (nil fontified t 1801 . 1802) (nil fontified t 1796 . 1801) (nil fontified t 1789 . 1796) (nil fontified t 1783 . 1789) (nil fontified t 1774 . 1783) (nil fontified t 1768 . 1774) (nil fontified t 1750 . 1768) (nil fontified t 1746 . 1750) (nil rear-nonsticky t 2650 . 2651) nil (nil rear-nonsticky nil 2650 . 2651) (nil fontified nil 1746 . 2651) (1746 . 2651) (t 25700 5685 268138 372000) nil (1745 . 1746) nil (nil rear-nonsticky nil 1744 . 1745) (nil fontified nil 1 . 1745) (1 . 1745) nil ("from transformers import GPT2Tokenizer, GPT2LMHeadModel
from ChatData import ChatData
from torch.optim import Adam
from torch.utils.data import DataLoader
import tqdm

def train(chatData, model, optim):

    epochs = 10

    for i in tqdm(range(epochs)):
        for X, a in chatData:
            optim.zero_grad()
            model(X, attention_mask=a, labels=X).loss
            loss.backward()
            optim.step()
        torch.save(model.state_dict(), \"model_state.pt\")

def inference(input):
    inp =  \"<start> <human>: \"+inp+\" <bot>: \"
    inp = tokenizer(inp)
    output = model.generate(**inp)
    output = tokenizer.decode(output[0])
    return output

tokenizer = GPT2Tokenizer.from_pretrained(\"gpt2\")

tokenizer.add_special_tokens({\"pad_token\": \"<pad>\",
                              \"eos_token\": \"<eos>\",
                              \"bos_token\": \"<bos>\"})
tokenizer.add_tokens([\"<human>:\", \"<bot>:\"])

model = GPT2LMHeadModel.from_pretrained(\"gpt2\")
model.resize_token_embeddings(len(tokenizer))

#print(tokenizer.decode(model.generate(**tokenizer(\"Hello, my dog is cute!\", return_tensors=\"pt\"))[0]))

chatData = ChatData(\"chat_data.json\", tokenizer)
chatData = DataLoader(chatData, batch_size=64)

model.train()

optim = Adam(model.parameters())

" . 1) (t 25700 328 592739 362000) nil (654 . 667) ("ret" . -654) 657 nil (656 . 657) nil ("return output" . 656) (t 25700 321 439395 654000) nil (656 . 669) nil (654 . 656) nil ("o" . -654) ("u" . -655) ("t" . -656) 657 nil (654 . 657) (t 25700 314 546052 211000) nil (649 . 654) (t 25700 310 216045 803000) nil ("," . -648) (" " . -649) ("s" . -650) ("k" . -651) ("i" . -652) 653 nil ("p" . -653) ("_" . -654) ("s" . -655) ("p" . -656) ("e" . -657) ("c" . -658) ("i" . -659) ("a" . -660) ("l" . -661) ("_" . -662) ("t" . -663) ("o" . -664) ("k" . -665) ("e" . -666) ("n" . -667) ("s" . -668) ("=" . -669) ("T" . -670) ("r" . -671) ("u" . -672) ("e" . -673) 674 (t 25700 303 232702 41000) nil (621 . 675) nil (619 . 621) nil (" " . -619) 620 nil (619 . 620) nil (" " . -619) 620 nil (613 . 620) (t 25700 294 472688 791000) nil (608 . 613) (t 25700 290 962683 430000) nil (602 . 607) (601 . 603) ("(" . -601) (601 . 602) (t 25700 284 209339 694000) nil (591 . 601) nil ("l" . -591) 592) (emacs-pending-undo-list (495 . 496) nil ("2" . -495) ((marker . 495) . -1) ((marker . 495) . -1) ((marker . 495) . -1) 496 (t 25700 5705 31509 694000) nil (906 . 907) nil (nil rear-nonsticky nil 905 . 906) (nil fontified nil 1 . 906) (1 . 906) nil ("from torch.utils.data import Dataset
import json

class ChatData(Dataset):
    def __init__(self, path:str, tokenizer):
        self.data = json.load(open(path,\"r\"))

        self.X=[]
        for i in self.data:
            for j in i['dialog']:
                self.X.append(j['text'])

        for idx, i in enumerate(self.X):
            try:
                self.X[idx] = \"<start> <human>: \"+i+\" <bot>: \"+ self.X[idx+1]+\" <end>\"
            except:
                break

        self.X = self.X[:-1]
        
        print(self.X[0])
                
        self.X_encoded = tokenizer(self.X, truncation=True, padding=True)
        self.input_ids = self.X_encoded['input_ids']
        self.attention_mask = self.X_encoded['attention_mask']
        
    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return self.input_ids[idx], self.attention_mask[idx]
" . 1) (t 25699 65325 524804 769000) nil (420 . 422) (t 25699 65284 757984 15000) nil (45 . 49) ("j" . -45) 46 nil (38 . 46) nil (38 . 39) (t 25699 65255 687866 933000) nil ("s" . -138) ("\\" . -139) 140 nil (139 . 140) (t 25699 64958 26225 38000) nil (842 . 887) nil (835 . 842) nil ("p" . -835) ("a" . -836) ("s" . -837) ("s" . -838) 839 nil (493 . 502) (t 25699 64936 996070 770000) nil (489 . 492) nil ("1" . -489) (":" . -490) 491 nil (482 . 492) ("s" . -482) 483 nil (478 . 483) nil ("x" . -478) 479 nil (473 . 479) nil ("    " . -473) 477 nil (465 . 477) ("            " . 464) (463 . 477) (t 25699 64915 65903 248000) nil (743 . 754) nil (742 . 743) nil (" " . -742) 743 nil (736 . 743) nil ("p" . -736) ("a" . -737) ("s" . -738) ("s" . -739) 740 (t 25699 64906 759171 293000) nil (485 . 486) (484 . 486) ("[" . -484) (484 . 485) nil ("p" . -484) ("0" . -485) 486 (t 25699 64905 142491 800000) nil (484 . 486) (t 25699 64903 182476 198000) nil (472 . 485) ("print" . -472) 477 nil (472 . 477) nil ("    " . -472) 476 (t 25699 64898 809107 842000) nil (463 . 476) nil (458 . 463) nil (441 . 458) nil (440 . 441) nil (":" . -440) 441 nil (440 . 441) nil (434 . 440) ("e" . -434) (434 . 435) ("except" . -434) (434 . 440) ("ex" . -434) 436 nil (434 . 436) nil ("    " . -434) 438 nil (422 . 438) nil (423 . 439) ("            " . 422) (434 . 435) nil (337 . 353) ("            " . 337) 354 nil (334 . 336) nil ("e" . -334) 335 nil (332 . 335) nil (319 . 332) (t 25699 64868 665525 69000) nil (393 . 394) (t 25699 64863 788816 692000) nil (391 . 392) (t 25699 64859 8775 436000) nil (388 . 390) nil ("d" . -388) ("x" . -389) ("+" . -390) 391 nil (380 . 392) ("sel" . -380) 383 nil (380 . 383) nil ("x" . -380) 381 nil (379 . 381) (t 25699 64844 731983 288000) nil (363 . 364) nil (375 . 376) (t 25699 64833 401881 261000) nil (362 . 363) nil (354 . 355) (t 25699 64825 235139 681000) nil (360 . 361) nil (354 . 360) nil ("M" . -354) 355 nil (354 . 355) nil (" " . -354) 355 (t 25699 64815 568382 826000) nil (360 . 361) nil (365 . 366) (t 25699 64808 668317 430000) nil (366 . 367) nil (" " . -366) 367 nil (366 . 367) ("\"" . 366) (365 . 366) (" " . -365) (365 . 366) ("\"" . -365) (365 . 366) nil (" " . -365) 366 nil (363 . 366) nil ("t" . -363) 364 nil (361 . 364) nil (360 . 361) (359 . 361) ("\"" . -359) (359 . 360) (" " . -359) (359 . 360) ("\"" . -359) (359 . 360) nil (" " . -359) 360 nil (" " . -361) 362 nil (359 . 368) nil (358 . 359) nil (" " . -358) 359 nil (356 . 359) nil (354 . 355) (t 25699 64782 774730 891000) nil (353 . 354) (t 25699 64780 664709 704000) nil (348 . 353) nil ("s" . -348) ("t" . -349) ("r" . -350) ("t" . -351) ("s" . -352) ("t" . -353) ("r" . -354) 355 nil (348 . 355) nil ("S" . -348) 349 nil (347 . 349) (346 . 348) ("\"" . -346) (346 . 347) (t 25699 64768 354584 377000) nil ("i" . -346) ("." . -347) ("l" . -348) ("o" . -349) ("w" . -350) ("e" . -351) ("r" . -352) ("(" . -353) (")" . -354) 355 nil (337 . 355) nil (332 . 337) nil (320 . 332) nil (321 . 333) ("            " . 320) (332 . 333) (t 25699 64755 891121 130000) nil (319 . 332) nil (296 . 319) ("i" . -296) 297 nil (293 . 297) nil ("d" . -293) ("x" . -294) 295 nil (293 . 295) nil ("," . -293) 294 nil (293 . 294) nil ("x" . -293) (" " . -294) 295 nil (292 . 295) nil (" " . -292) ("i" . -293) ("n" . -294) (" " . -295) 296 nil ("s" . -296) ("e" . -297) ("l" . -298) ("f" . -299) ("." . -300) ("x" . -301) 302 nil (287 . 302) nil ("    " . -287) 291 nil ("    " . -291) 295 nil (279 . 295) ("        " . 278) (286 . 287) (t 25699 64675 351163 211000) nil (427 . 476) nil (422 . 427) nil (413 . 422) nil (374 . 413) ("input" . -374) 379 nil (377 . 379) nil ("i" . -377) ("t" . -378) 379 nil (369 . 379) nil (361 . 369) nil (362 . 370) ("        " . 361) (369 . 370) (t 25699 64633 767882 702000) nil ("    " . -286) 290 nil ("    " . -290) 294 nil (278 . 294) nil ("    " . -278) 282 nil ("    " . -282) 286 nil ("    " . -286) 290 nil ("    " . -290) 294 nil (278 . 294) ("        " . 278) 286 (t 25699 64630 851219 771000) nil ("    " . -286) 290 nil ("    " . -290) 294 nil (277 . 294) nil ("
" . -277) 278 nil ("        " . -361) 369 (t 25699 64622 757896 826000) nil ("," . -351) (" " . -352) ("m" . -353) ("a" . -354) ("x" . -355) ("_" . -356) ("l" . -357) ("e" . -358) ("n" . -359) ("g" . -360) ("t" . -361) ("h" . -362) ("=" . -363) 364 nil ("5" . -364) ("1" . -365) ("2" . -366) 367 nil ("," . -367) (" " . -368) ("t" . -369) ("r" . -370) ("u" . -371) ("n" . -372) ("c" . -373) ("a" . -374) ("t" . -375) ("i" . -376) ("o" . -377) ("n" . -378) ("_" . -379) ("s" . -380) ("t" . -381) ("r" . -382) ("a" . -383) ("t" . -384) ("e" . -385) ("g" . -386) ("y" . -387) 388 nil (322 . 388) ("truncation" . -322) 332 nil (331 . 332) nil (329 . 331) nil ("o" . -329) 330 nil (321 . 330) (t 25699 64609 834580 148000) nil (" " . -321) ("p" . -322) ("a" . -323) ("d" . -324) ("d" . -325) ("i" . -326) ("n" . -327) ("g" . -328) ("=" . -329) ("T" . -330) ("r" . -331) ("u" . -332) ("e" . -333) ("," . -334) (" " . -335) ("t" . -336) ("r" . -337) ("u" . -338) ("n" . -339) ("c" . -340) ("a" . -341) 342 nil ("t" . -342) ("i" . -343) ("o" . -344) ("n" . -345) ("=" . -346) ("T" . -347) ("r" . -348) ("u" . -349) ("e" . -350) ("," . -351) (" " . -352) ("m" . -353) ("a" . -354) ("x" . -355) ("_" . -356) ("l" . -357) ("e" . -358) ("n" . -359) ("g" . -360) ("t" . -361) ("h" . -362) 363 nil (292 . 364) ("X_encoded" . -292) 301 nil (296 . 301) nil ("g" . -296) 297 nil (292 . 297) nil ("x" . -292) 293 nil (287 . 293) nil ("    " . -287) 291 nil ("    " . -291) 295 nil (279 . 295) nil (280 . 296) ("                " . 279) (279 . 296) ("        " . 278) (286 . 287) (t 25699 64586 474610 472000) nil (97 . 98) nil ("T" . -97) 98 (t 25699 64576 494623 515000) nil (97 . 106) nil ("t" . -97) ("o" . -98) 99 nil (95 . 99) nil ("m" . -95) 96 nil (95 . 96) (t 25699 64562 411308 680000) nil (265 . 266) (t 25699 64560 21311 830000) nil (258 . 264) nil (257 . 259) ("[" . -257) (256 . 258) nil ("j" . -256) (")" . -257) 258 nil (247 . 258) ("X" . -247) 248 nil (242 . 248) (t 25699 64549 234659 421000) nil (225 . 242) (t 25699 64544 311332 617000) nil ("]" . 163) (162 . 163) (161 . 163) ("[" . -161) (160 . 162) nil (159 . 160) nil ("x" . -159) 160 nil (158 . 160) nil (" " . -158) 159 nil (154 . 159) nil (146 . 154) ("        " . 145) (153 . 154) nil ("s" . -153) 154 nil (153 . 154) (t 25699 64532 701348 70000) nil (144 . 153) nil (205 . 206) nil ("\"" . -205) ("\"" . 206) nil (205 . 207) ("\"" . -205) (205 . 206) nil (" " . -205) 206 nil (205 . 206) (t 25699 64513 878039 962000) nil (197 . 203) (196 . 198) ("'" . -196) (196 . 197) nil ("d" . -196) ("i" . -197) 198 nil (196 . 198) (195 . 197) ("[" . -195) (194 . 196) nil (186 . 194) nil ("p" . -186) ("o" . -187) 188 nil (187 . 188) nil ("r" . -187) 188 nil (185 . 188) nil (172 . 185) (t 25699 64484 274746 745000) nil (167 . 172) nil (153 . 167) nil (145 . 153) nil (146 . 154) ("        " . 145) (153 . 154) nil (145 . 153) (t 25699 64469 338100 535000) nil (140 . 141) (139 . 141) ("\"" . -139) (139 . 140) nil (138 . 139) nil (139 . 140) nil (")" . -139) 140 nil (139 . 140) nil ("/" . -139) ("," . -140) 141 nil (139 . 141) nil ("." . -139) 140 nil ("r" . -140) ("e" . -141) ("a" . -142) ("d" . -143) ("(" . -144) (")" . 145) (")" . -145) 146 (t 25699 64445 351467 33000) nil (")" . 147) (129 . 147) ("ope" . -129) 132 nil (129 . 132) nil ("p" . -129) 130 nil (129 . 130) (128 . 130) ("(" . -128) (128 . 129) nil (")" . -128) 129 nil (128 . 129) nil (118 . 128) ("j" . -118) 119 nil (106 . 119) nil ("p" . -106) ("a" . -107) ("s" . -108) ("s" . -109) 110 (t 25699 64433 298150 516000) nil ("," . -95) 96 nil ("t" . 96) ("e" . 96) ("s" . 96) nil ("a" . 96) ("t" . 96) ("a" . 96) ("d" . 96) (":" . 96) ("a" . 96) ("t" . 96) ("a" . 96) ("d" . 96) (" " . 96) (t 25699 64426 514826 692000) nil (92 . 109) ("st" . -92) 94 nil (91 . 94) nil ("L" . -91) 92 nil (87 . 92) nil ("o" . -87) 88 nil (85 . 88) (t 25699 64407 408186 994000) nil (183 . 184) nil (179 . 183) nil (171 . 179) (t 25699 64403 294859 502000) nil (166 . 168) nil ("ndex" . 166) nil (165 . 170) ("index):" . 165) (172 . 174) nil ("):" . 172) (165 . 172) ("index" . -165) 170 nil (166 . 170) nil ("d" . -166) ("x" . -167) 168 nil (147 . 170) nil (143 . 147) nil (139 . 143) ("    " . 138) (142 . 143) nil (137 . 142) nil (133 . 137) ("p" . -133) (133 . 134) ("pass" . -133) 137 nil (133 . 137) nil (124 . 133) nil (110 . 124) nil (106 . 110) nil (102 . 106) ("    " . 101) (100 . 106) nil (96 . 100) ("pass" . -96) (96 . 100) ("pass" . -96) 100 nil (96 . 100) nil (87 . 96) nil ("," . -85) (" " . -86) ("d" . -87) ("a" . -88) ("t" . -89) ("a" . -90) 91 nil (72 . 93) nil (68 . 72) (t 25699 64342 514947 382000) nil (63 . 68) (t 25699 64334 868291 989000) nil (6 . 37) ("torch" . -6) 11 nil (1 . 11) nil (1 . 2) (t 25699 64326 634970 851000) nil (1 . 2) nil (24 . 25) (t 25699 64322 888309 754000) nil (18 . 23) nil (16 . 18) nil ("d" . -16) ("a" . -17) ("t" . -18) ("a" . -19) ("s" . -20) ("e" . -21) ("t" . -22) 23 (t 25699 64318 501649 623000) nil (24 . 25) 23 nil (16 . 23) (15 . 17) ("(" . -15) (15 . 16) nil ("t" . -15) 16 nil (7 . 16) nil (2 . 7) nil (";" . -2) ("a" . -3) 4 nil (1 . 4) (t 25699 64304 948336 597000)) (emacs-undo-equiv-table (-226 . -232) (-227 . -231) (-228 . -230)))