((buffer-size . 2684) (buffer-checksum . "ddfc475c20fc3ff2c65c035385ad087ffe5f1252"))
((emacs-buffer-undo-list nil ("
sudo pacman -S picom" . 81) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker . 81) . -21) ((marker) . -21) (t 25753 37231 4431 758000) nil (1071 . 1076) nil ("s" . -1071) ((marker . 81) . -1) 1072 nil (1070 . 1072) nil ("0" . -1070) ((marker . 81) . -1) 1071 nil (1067 . 1071) nil ("n" . -1067) ((marker . 81) . -1) ("a" . -1068) ((marker . 81) . -1) (" " . -1069) ((marker . 81) . -1) 1070 nil (1062 . 1070) nil (" " . -1062) ((marker . 81) . -1) ((marker . 1041) . -1) ("p" . -1063) ((marker . 81) . -1) ("a" . -1064) ((marker . 81) . -1) ("c" . -1065) ((marker . 81) . -1) ("m" . -1066) ((marker . 81) . -1) ("a" . -1067) ((marker . 81) . -1) ("n" . -1068) ((marker . 81) . -1) 1069 nil (1068 . 1069) nil ("s" . -1068) ((marker . 81) . -1) 1069 nil (1068 . 1069) nil (" " . -1068) ((marker . 81) . -1) 1069 nil (1068 . 1069) nil ("n" . -1068) ((marker . 81) . -1) (" " . -1069) ((marker . 81) . -1) 1070 nil (1063 . 1070) nil ("p" . -1063) ((marker . 81) . -1) 1064 nil (1063 . 1064) nil (" " . -1063) ((marker . 81) . -1) ((marker . 1041) . -1) 1064 nil (1058 . 1064) nil (1057 . 1058) nil (1054 . 1057) ("torrent" . 1054) ((marker . 81) . -7) nil (1054 . 1061) ("tor" . -1054) ((marker . 81) . -3) 1057 nil (1039 . 1057) (t 25753 37163 919532 868000) nil (1038 . 1039) (t 25753 37138 769195 944000) nil (1027 . 1038) ("thunderbir" . -1027) ((marker . 81) . -10) 1037 nil (1027 . 1037) nil ("T" . -1027) ((marker . 81) . -1) ("h" . -1028) ((marker . 81) . -1) ("t" . -1029) ((marker . 81) . -1) 1030 nil (1029 . 1030) nil ("=" . -1029) ((marker . 81) . -1) 1030 nil (1027 . 1030) nil (1024 . 1027) nil ("0" . -1024) ((marker . 81) . -1) 1025 nil (1012 . 1025) nil (1011 . 1012) (t 25753 37124 425188 366000) nil (1007 . 1011) nil ("f" . -1007) ((marker . 81) . -1) ("u" . -1008) ((marker . 81) . -1) 1009 nil (1007 . 1009) nil (1006 . 1007) nil (997 . 1006) ("pac" . -997) ((marker . 81) . -3) 1000 nil (997 . 1000) nil (992 . 997) nil (992 . 993) (t 25753 37068 761204 286000) nil (812 . 819) ("fire" . -812) ((marker . 81) . -4) 816 nil (809 . 816) nil ("-" . -809) ((marker . 81) . -1) 810 nil (809 . 810) nil ("0" . -809) ((marker . 81) . -1) ("S" . -810) ((marker . 81) . -1) (" " . -811) ((marker . 81) . -1) ("=" . -812) ((marker . 81) . -1) 813 nil (797 . 813) nil (796 . 797) nil (" " . -796) ((marker . 81) . -1) 797 nil (789 . 797) nil (" " . -789) ((marker . 81) . -1) 790 nil (789 . 790) nil (780 . 789) ("pac" . -780) ((marker . 81) . -3) 783 nil (780 . 783) nil ("d" . -780) ((marker . 81) . -1) 781 nil (780 . 781) nil (775 . 780) nil (774 . 775) nil ("
sudo pacman -S vivaldi-ffmpeg-codecs
sudo pacman -S vivaldi" . 774) ((marker . 753) . -55) ((marker . 753) . -55) ((marker . 753) . -55) ((marker . 81) . -60) ((marker . 753) . -60) ((marker) . -60) (t 25704 49885 43608 754000) nil (1001 . 1006) (t 25704 49880 990274 676000) nil (" " . -1001) 1002 nil (998 . 1002) nil ("0" . -998) ("S" . -999) 1000 nil (995 . 1000) nil (" " . -995) 996 nil (987 . 996) nil (986 . 987) nil (986 . 987) (t 25704 49490 314446 223000) nil (2543 . 2544) (t 25704 49404 525084 838000) nil (nil rear-nonsticky nil 2542 . 2543) (nil fontified nil 2517 . 2543) (2517 . 2543) nil (2514 . 2517) nil ("0" . -2514) 2515 nil (2510 . 2515) nil ("picom-simpleanims-next-git" . 2510) (nil rear-nonsticky t 2535 . 2536) nil (nil rear-nonsticky nil 2535 . 2536) (nil fontified nil 2510 . 2536) (2510 . 2536) nil (2509 . 2510) nil ("\\" . -2509) ("
" . -2510) (" " . -2511) (" " . -2512) ("	" . 2513) (2511 . 2513) 2512 nil (" " . -2512) (" " . -2513) ("	" . 2514) (2512 . 2514) 2513 nil (2510 . 2513) nil (2509 . 2510) (t 25704 48394 218400 177000) nil (894 . 901) nil ("d" . 894) nil (894 . 895) nil ("shotcut" . 894) 901 (t 25704 48394 218400 177000) nil (nil rear-nonsticky nil 984 . 985) (nil fontified nil 23 . 985) (23 . 985) nil ("s" . -23) ("u" . -24) ("d" . -25) ("o" . -26) (" " . -27) ("p" . -28) ("a" . -29) ("c" . -30) ("m" . -31) ("a" . -32) ("n" . -33) (" " . -34) ("-" . -35) ("S" . -36) (" " . -37) ("r" . -38) ("o" . -39) ("f" . -40) ("i" . -41) ("
" . -42) 43 nil ("sudo pacman -S acpi
sudo pacman -S feh
sudo pacman -S picom
sudo pacman -S pcmanfm
sudo pacman -S light
sudo pacman -S alsa-utils
sudo pacman -S flameshot
sudo pacman -S neofetch
sudo pacman -S lxappearance
sudo pacman -S alacritty
sudo pacman -S qbittorrent
sudo pacman -S steam
sudo pacman -S discord
sudo pacman -S wine-mono
sudo pacman -S wine
sudo pacman -S mono
sudo pacman -S lmms
sudo pacman -S zip
sudo pacman -S unzip
sudo pacman -S emacs
sudo pacman -S godot
sudo pacman -S easyeffects
sudo pacman -S fish
sudo pacman -S obs-studio
sudo pacman -S fuse
sudo pacman -S file-roller
sudo pacman -S putty
sudo pacman -S peek
sudo pacman -S btop
sudo pacman -S libreoffice-fresh
sudo pacman -S grub-customizer
sudo pacman -S tmux
sudo pacman -S vivaldi-ffmpeg-codecs
sudo pacman -S vivaldi
sudo pacman -S lightdm-gtk-greeter-settings
sudo pacman -S shotcut
sudo pacman -S vlc" . 43) (t 25704 48350 813217 4000) nil (1826 . 1839) nil ("e" . -1826) 1827 nil (1822 . 1827) (t 25704 48286 522154 760000) nil ("
mv i3 $HOME/.config/" . 1384) (t 25704 48283 772254 500000) nil (nil rear-nonsticky nil 1368 . 1369) (nil fontified nil 1364 . 1369) (1364 . 1369) nil ("i3" . 1364) 1366 nil (nil rear-nonsticky nil 1335 . 1336) (nil fontified nil 1331 . 1336) (1331 . 1336) nil ("sxhkd" . 1331) 1336) (emacs-pending-undo-list (1039 . 1057) (t 25753 37163 919532 868000) nil (1038 . 1039) (t 25753 37138 769195 944000) nil (1027 . 1038) ("thunderbir" . -1027) ((marker . 81) . -10) 1037 nil (1027 . 1037) nil ("T" . -1027) ((marker . 81) . -1) ("h" . -1028) ((marker . 81) . -1) ("t" . -1029) ((marker . 81) . -1) 1030 nil (1029 . 1030) nil ("=" . -1029) ((marker . 81) . -1) 1030 nil (1027 . 1030) nil (1024 . 1027) nil ("0" . -1024) ((marker . 81) . -1) 1025 nil (1012 . 1025) nil (1011 . 1012) (t 25753 37124 425188 366000) nil (1007 . 1011) nil ("f" . -1007) ((marker . 81) . -1) ("u" . -1008) ((marker . 81) . -1) 1009 nil (1007 . 1009) nil (1006 . 1007) nil (997 . 1006) ("pac" . -997) ((marker . 81) . -3) 1000 nil (997 . 1000) nil (992 . 997) nil (992 . 993) (t 25753 37068 761204 286000) nil (812 . 819) ("fire" . -812) ((marker . 81) . -4) 816 nil (809 . 816) nil ("-" . -809) ((marker . 81) . -1) 810 nil (809 . 810) nil ("0" . -809) ((marker . 81) . -1) ("S" . -810) ((marker . 81) . -1) (" " . -811) ((marker . 81) . -1) ("=" . -812) ((marker . 81) . -1) 813 nil (797 . 813) nil (796 . 797) nil (" " . -796) ((marker . 81) . -1) 797 nil (789 . 797) nil (" " . -789) ((marker . 81) . -1) 790 nil (789 . 790) nil (780 . 789) ("pac" . -780) ((marker . 81) . -3) 783 nil (780 . 783) nil ("d" . -780) ((marker . 81) . -1) 781 nil (780 . 781) nil (775 . 780) nil (774 . 775) nil ("
sudo pacman -S vivaldi-ffmpeg-codecs
sudo pacman -S vivaldi" . 774) ((marker . 753) . -55) ((marker . 753) . -55) ((marker . 753) . -55) ((marker . 81) . -60) ((marker . 753) . -60) ((marker) . -60) (t 25704 49885 43608 754000) nil (1001 . 1006) (t 25704 49880 990274 676000) nil (" " . -1001) 1002 nil (998 . 1002) nil ("0" . -998) ("S" . -999) 1000 nil (995 . 1000) nil (" " . -995) 996 nil (987 . 996) nil (986 . 987) nil (986 . 987) (t 25704 49490 314446 223000) nil (2543 . 2544) (t 25704 49404 525084 838000) nil (nil rear-nonsticky nil 2542 . 2543) (nil fontified nil 2517 . 2543) (2517 . 2543) nil (2514 . 2517) nil ("0" . -2514) 2515 nil (2510 . 2515) nil ("picom-simpleanims-next-git" . 2510) (nil rear-nonsticky t 2535 . 2536) nil (nil rear-nonsticky nil 2535 . 2536) (nil fontified nil 2510 . 2536) (2510 . 2536) nil (2509 . 2510) nil ("\\" . -2509) ("
" . -2510) (" " . -2511) (" " . -2512) ("	" . 2513) (2511 . 2513) 2512 nil (" " . -2512) (" " . -2513) ("	" . 2514) (2512 . 2514) 2513 nil (2510 . 2513) nil (2509 . 2510) (t 25704 48394 218400 177000) nil (894 . 901) nil ("d" . 894) nil (894 . 895) nil ("shotcut" . 894) 901 (t 25704 48394 218400 177000) nil (nil rear-nonsticky nil 984 . 985) (nil fontified nil 23 . 985) (23 . 985) nil ("s" . -23) ("u" . -24) ("d" . -25) ("o" . -26) (" " . -27) ("p" . -28) ("a" . -29) ("c" . -30) ("m" . -31) ("a" . -32) ("n" . -33) (" " . -34) ("-" . -35) ("S" . -36) (" " . -37) ("r" . -38) ("o" . -39) ("f" . -40) ("i" . -41) ("
" . -42) 43 nil ("sudo pacman -S acpi
sudo pacman -S feh
sudo pacman -S picom
sudo pacman -S pcmanfm
sudo pacman -S light
sudo pacman -S alsa-utils
sudo pacman -S flameshot
sudo pacman -S neofetch
sudo pacman -S lxappearance
sudo pacman -S alacritty
sudo pacman -S qbittorrent
sudo pacman -S steam
sudo pacman -S discord
sudo pacman -S wine-mono
sudo pacman -S wine
sudo pacman -S mono
sudo pacman -S lmms
sudo pacman -S zip
sudo pacman -S unzip
sudo pacman -S emacs
sudo pacman -S godot
sudo pacman -S easyeffects
sudo pacman -S fish
sudo pacman -S obs-studio
sudo pacman -S fuse
sudo pacman -S file-roller
sudo pacman -S putty
sudo pacman -S peek
sudo pacman -S btop
sudo pacman -S libreoffice-fresh
sudo pacman -S grub-customizer
sudo pacman -S tmux
sudo pacman -S vivaldi-ffmpeg-codecs
sudo pacman -S vivaldi
sudo pacman -S lightdm-gtk-greeter-settings
sudo pacman -S shotcut
sudo pacman -S vlc" . 43) (t 25704 48350 813217 4000) nil (1826 . 1839) nil ("e" . -1826) 1827 nil (1822 . 1827) (t 25704 48286 522154 760000) nil ("
mv i3 $HOME/.config/" . 1384) (t 25704 48283 772254 500000) nil (nil rear-nonsticky nil 1368 . 1369) (nil fontified nil 1364 . 1369) (1364 . 1369) nil ("i3" . 1364) 1366 nil (nil rear-nonsticky nil 1335 . 1336) (nil fontified nil 1331 . 1336) (1331 . 1336) nil ("sxhkd" . 1331) 1336) (emacs-undo-equiv-table (22 . -1) (-61 . -63) (-60 . -64) (-53 . -55)))