((buffer-size . 29) (buffer-checksum . "0728e867eb3678af5d7f761746e227121966c026"))
((emacs-buffer-undo-list nil (27 . 28) nil (nil rear-nonsticky nil 19 . 20) (nil fontified nil 15 . 20) (15 . 20) nil ("a" . -15) ((marker . 30) . -1) ((marker . 28) . -1) 16 nil (" " . -16) ((marker . 30) . -1) ((marker . 28) . -1) ("=" . -17) ((marker . 30) . -1) ((marker . 28) . -1) ("b" . -18) ((marker . 30) . -1) ((marker . 28) . -1) 19 nil (" " . -19) ((marker . 30) . -1) 20 nil (19 . 20) nil (15 . 19) nil ("a" . 15) ((marker . 30) . -1) ((marker . 28) . -1) nil (15 . 16) nil ("a = b" . 22) ((marker . 15) . -5) ((marker . 27) . -4) ((marker . 27) . -2) ((marker . 27) . -3) ((marker . 27) . -3) ((marker . 27) . -4) ((marker . 27) . -5) ((marker . 27) . -4) ((marker) . -5) nil ("=" . 25) (t 25707 26260 708136 80000) nil (24 . 25) (t 25707 26237 548322 203000) nil ("cd " . 28) ((marker . 30) . -3) nil (28 . 31) (t 25707 26237 548322 203000) nil (28 . 29) nil (22 . 27) (21 . 23) ("(" . -21) (16 . 22) nil (14 . 16) nil (13 . 14) nil ("0" . -13) ((marker . 30) . -1) ((marker . 28) . -1) ("
" . -14) ((marker . 30) . -1) ((marker . 28) . -1) ("c" . -15) ((marker . 30) . -1) ((marker . 28) . -1) (" " . -16) ((marker . 30) . -1) ((marker . 28) . -1) ("=" . -17) ((marker . 30) . -1) ((marker . 28) . -1) (" " . -18) ((marker . 30) . -1) ((marker . 28) . -1) ("3" . -19) ((marker . 30) . -1) ((marker . 28) . -1) ("0" . -20) ((marker . 30) . -1) ((marker . 28) . -1) ("
" . -21) ((marker . 30) . -1) ((marker . 28) . -1) ("d" . -22) ((marker . 30) . -1) ((marker . 28) . -1) (" " . -23) ((marker . 30) . -1) ((marker . 28) . -1) ("=" . -24) ((marker . 30) . -1) ((marker . 28) . -1) (" " . -25) ((marker . 30) . -1) ((marker . 28) . -1) ("4" . -26) ((marker . 30) . -1) ((marker . 28) . -1) ("0" . -27) ((marker . 30) . -1) ((marker . 28) . -1) ("
" . -28) ((marker . 30) . -1) ("e" . -29) ((marker . 30) . -1) (" " . -30) ((marker . 30) . -1) ("=" . -31) ((marker . 30) . -1) 32 nil (8 . 32) nil ("b" . -8) ((marker . 30) . -1) ((marker . 28) . -1) (" " . -9) ((marker . 30) . -1) ((marker . 28) . -1) ("=" . -10) ((marker . 30) . -1) ((marker . 28) . -1) (" " . -11) ((marker . 30) . -1) ((marker . 28) . -1) ("1" . -12) ((marker . 30) . -1) ((marker . 28) . -1) ("0" . -13) ((marker . 30) . -1) ((marker . 28) . -1) ("
" . -14) ((marker . 30) . -1) 15 nil ("\\" . -15) ((marker . 30) . -1) 16 nil (15 . 16) nil (14 . 15) nil (10 . 14) nil (8 . 10) nil (7 . 8) nil (";" . -7) ((marker . 30) . -1) 8 nil (1 . 8) nil ("import datetime.datetime

def get_datetime():
        return datetime.datetime.now()

def get_number_squared(num):
        return num * num

def get_square_root(num):
        return num ** (1/2)

def create_list(n):
        return [i for i in range(n)]
" . 1) ((marker . 15) . -253) ((marker . 1) . -253) ((marker . 1) . -253) ((marker . 1) . -253) ((marker) . -253) (t 25643 53725 602274 2000)) (emacs-pending-undo-list ("a = b" . 22) ((marker . 15) . -5) ((marker . 27) . -4) ((marker . 27) . -2) ((marker . 27) . -3) ((marker . 27) . -3) ((marker . 27) . -4) ((marker . 27) . -5) ((marker . 27) . -4) ((marker) . -5) nil ("=" . 25) (t 25707 26260 708136 80000) nil (24 . 25) (t 25707 26237 548322 203000) nil ("cd " . 28) ((marker . 30) . -3) nil (28 . 31) (t 25707 26237 548322 203000) nil (28 . 29) nil (22 . 27) (21 . 23) ("(" . -21) (16 . 22) nil (14 . 16) nil (13 . 14) nil ("0" . -13) ((marker . 30) . -1) ((marker . 28) . -1) ("
" . -14) ((marker . 30) . -1) ((marker . 28) . -1) ("c" . -15) ((marker . 30) . -1) ((marker . 28) . -1) (" " . -16) ((marker . 30) . -1) ((marker . 28) . -1) ("=" . -17) ((marker . 30) . -1) ((marker . 28) . -1) (" " . -18) ((marker . 30) . -1) ((marker . 28) . -1) ("3" . -19) ((marker . 30) . -1) ((marker . 28) . -1) ("0" . -20) ((marker . 30) . -1) ((marker . 28) . -1) ("
" . -21) ((marker . 30) . -1) ((marker . 28) . -1) ("d" . -22) ((marker . 30) . -1) ((marker . 28) . -1) (" " . -23) ((marker . 30) . -1) ((marker . 28) . -1) ("=" . -24) ((marker . 30) . -1) ((marker . 28) . -1) (" " . -25) ((marker . 30) . -1) ((marker . 28) . -1) ("4" . -26) ((marker . 30) . -1) ((marker . 28) . -1) ("0" . -27) ((marker . 30) . -1) ((marker . 28) . -1) ("
" . -28) ((marker . 30) . -1) ("e" . -29) ((marker . 30) . -1) (" " . -30) ((marker . 30) . -1) ("=" . -31) ((marker . 30) . -1) 32 nil (8 . 32) nil ("b" . -8) ((marker . 30) . -1) ((marker . 28) . -1) (" " . -9) ((marker . 30) . -1) ((marker . 28) . -1) ("=" . -10) ((marker . 30) . -1) ((marker . 28) . -1) (" " . -11) ((marker . 30) . -1) ((marker . 28) . -1) ("1" . -12) ((marker . 30) . -1) ((marker . 28) . -1) ("0" . -13) ((marker . 30) . -1) ((marker . 28) . -1) ("
" . -14) ((marker . 30) . -1) 15 nil ("\\" . -15) ((marker . 30) . -1) 16 nil (15 . 16) nil (14 . 15) nil (10 . 14) nil (8 . 10) nil (7 . 8) nil (";" . -7) ((marker . 30) . -1) 8 nil (1 . 8) nil ("import datetime.datetime

def get_datetime():
        return datetime.datetime.now()

def get_number_squared(num):
        return num * num

def get_square_root(num):
        return num ** (1/2)

def create_list(n):
        return [i for i in range(n)]
" . 1) ((marker . 15) . -253) ((marker . 1) . -253) ((marker . 1) . -253) ((marker . 1) . -253) ((marker) . -253) (t 25643 53725 602274 2000)) (emacs-undo-equiv-table (8 . -1) (-4 . -6)))