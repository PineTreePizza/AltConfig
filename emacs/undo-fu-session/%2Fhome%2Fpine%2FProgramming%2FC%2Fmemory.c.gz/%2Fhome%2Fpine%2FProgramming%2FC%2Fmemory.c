((buffer-size . 90) (buffer-checksum . "3359673c40fb5a45dbe022c803ca4e2e2e82034f"))
((emacs-buffer-undo-list nil (20 . 40) 48 (t 25608 16574 744838 375000) nil ("'" . 48) ((marker . 85) . -1) nil ("
	" . 49) ((marker . 85) . -2) nil (49 . 51) nil (48 . 49) (t 25608 16574 744838 375000) nil ("#include <stdlib.h>
" . 20) ((marker . 39) . -19) nil (20 . 40) 48 (t 25608 16574 744838 375000)) (emacs-pending-undo-list ("#include <stdlib.h>
" . 20) ((marker . 39) . -19) nil (20 . 40) 48 (t 25608 16574 744838 375000)) (emacs-undo-equiv-table (2 . -1) (-1 . t) (3 . 5)))