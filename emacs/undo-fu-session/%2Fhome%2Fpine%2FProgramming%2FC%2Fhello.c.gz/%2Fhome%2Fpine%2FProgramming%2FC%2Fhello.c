((buffer-size . 72) (buffer-checksum . "74630821044b38da7b1a480a2aaf8a6188337a15"))
((emacs-buffer-undo-list nil (70 . 72) (t 25698 2430 830056 492000) nil ("
" . -70) ((marker . 72) . -1) ("}" . -71) ((marker . 72) . -1) ((marker* . 71) . 1) ((marker . 72) . -1) 72 (t 25597 28625 860442 809000)) (emacs-pending-undo-list . t) (emacs-undo-equiv-table))