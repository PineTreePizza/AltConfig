((buffer-size . 44119) (buffer-checksum . "84da6fd44e88646f9733ffca72a32b3da3311069"))
((emacs-buffer-undo-list nil (23778 . 23787) (t 25707 27865 875010 256000) nil ("
        await bot.send_message(message.chat.id,text=quest.text ,reply_markup=question_create(quest),parse_mode=\"Markdown\")
        
        set_data(\"previous\",message.from_user.id,message.text)
        set_data(\"completed\",message.from_user.id,0)
        set_data(\"attempt\",message.from_user.id,3)
        set_data(\"current\",message.from_user.id,quest.correct_id)
        set_data(\"question\",message.from_user.id,question_array.index(quest))" . 23778) ((marker . 23778) . -443) ((marker . 23778) . -248) ((marker) . -443) (t 25707 27858 735090 447000) nil (nil rear-nonsticky nil 23529 . 23530) (nil fontified nil 23529 . 23530) (nil fontified nil 23520 . 23529) (nil fontified nil 23519 . 23520) (nil fontified nil 23502 . 23519) (nil fontified nil 23497 . 23502) (nil fontified nil 23486 . 23497) (nil fontified nil 23482 . 23486) (nil fontified nil 23481 . 23482) (nil fontified nil 23480 . 23481) (nil fontified nil 23474 . 23480) (nil fontified nil 23473 . 23474) (nil fontified nil 23472 . 23473) (nil fontified nil 23470 . 23472) (nil fontified nil 23451 . 23470) (nil fontified nil 23441 . 23451) (nil fontified nil 23440 . 23441) (nil fontified nil 23432 . 23440) (nil fontified nil 23431 . 23432) (nil fontified nil 23428 . 23431) (nil fontified nil 23427 . 23428) (nil fontified nil 23425 . 23427) (nil fontified nil 23420 . 23425) (nil fontified nil 23416 . 23420) (nil fontified nil 23407 . 23416) (23407 . 23530) nil ("
        quest = question_array[0]" . 23407) ((marker . 23778) . -34) ((marker) . -34) nil ("
        quiz = 1 if(int(get_data(\"question\",message.from_user.id)) <= 10) else 0
        quest = question_array[0+quiz*10]" . 23407) ((marker . 23787) . -123) ((marker*) . 1) ((marker) . -123) ((marker*) . 11) ((marker) . -113) (nil fontified t 23407 . 23408) (nil fontified t 23486 . 23489) (nil rear-nonsticky t 23529 . 23530) nil (nil rear-nonsticky nil 23529 . 23530) (nil fontified nil 23529 . 23530) (nil fontified nil 23520 . 23529) (nil fontified nil 23519 . 23520) (nil fontified nil 23502 . 23519) (nil fontified nil 23497 . 23502) (nil fontified nil 23486 . 23497) (nil fontified nil 23482 . 23486) (nil fontified nil 23481 . 23482) (nil fontified nil 23480 . 23481) (nil fontified nil 23474 . 23480) (nil fontified nil 23473 . 23474) (nil fontified nil 23472 . 23473) (nil fontified nil 23470 . 23472) (nil fontified nil 23451 . 23470) (nil fontified nil 23441 . 23451) (nil fontified nil 23440 . 23441) (nil fontified nil 23432 . 23440) (nil fontified nil 23431 . 23432) (nil fontified nil 23428 . 23431) (nil fontified nil 23427 . 23428) (nil fontified nil 23425 . 23427) (nil fontified nil 23420 . 23425) (nil fontified nil 23416 . 23420) (nil fontified nil 23407 . 23416) (23407 . 23530) nil ("
        quiz = 1 if(int(get_data(\"question\",message.from_user.id)) <= 10) else 0
        quest = question_array[0+quiz*10]" . 23937) ((marker . 23778) . -123) ((marker) . -123) (t 25707 27841 321952 604000) nil ("    " . -23353) ((marker . 23787) . -4) ((marker . 23778) . -4) ((marker . 23353) . -4) ((marker . 23353) . -4) 23357 nil ("        " . -23357) 23353 (t 25707 27838 218654 98000) nil (23824 . 23833) nil (nil rear-nonsticky nil 23823 . 23824) (nil fontified nil 23823 . 23824) (nil fontified nil 23813 . 23823) (nil fontified nil 23801 . 23813) (nil fontified nil 23800 . 23801) (nil fontified nil 23795 . 23800) (nil fontified nil 23794 . 23795) (nil fontified nil 23748 . 23794) (nil fontified nil 23746 . 23748) (nil fontified nil 23733 . 23746) (nil fontified nil 23732 . 23733) (nil fontified nil 23715 . 23732) (nil fontified nil 23710 . 23715) (nil fontified nil 23701 . 23710) (nil fontified nil 23700 . 23701) (nil fontified nil 23699 . 23700) (nil fontified nil 23694 . 23699) (nil fontified nil 23693 . 23694) (nil fontified nil 23672 . 23693) (nil fontified nil 23670 . 23672) (nil fontified nil 23651 . 23670) (nil fontified nil 23641 . 23651) (nil fontified nil 23640 . 23641) (nil fontified nil 23623 . 23640) (nil fontified nil 23622 . 23623) (nil fontified nil 23605 . 23622) (nil fontified nil 23603 . 23605) (nil fontified nil 23584 . 23603) (nil fontified nil 23575 . 23584) (nil fontified nil 23574 . 23575) (nil fontified nil 23557 . 23574) (nil fontified nil 23556 . 23557) (nil fontified nil 23554 . 23556) (nil fontified nil 23552 . 23554) (nil fontified nil 23533 . 23552) (nil fontified nil 23522 . 23533) (nil fontified nil 23521 . 23522) (nil fontified nil 23504 . 23521) (nil fontified nil 23503 . 23504) (nil fontified nil 23501 . 23503) (nil fontified nil 23499 . 23501) (nil fontified nil 23480 . 23499) (nil fontified nil 23471 . 23480) (nil fontified nil 23470 . 23471) (nil fontified nil 23453 . 23470) (nil fontified nil 23452 . 23453) (nil fontified nil 23451 . 23452) (nil fontified nil 23450 . 23451) (nil fontified nil 23433 . 23450) (nil fontified nil 23428 . 23433) (nil fontified nil 23420 . 23428) (nil fontified nil 23419 . 23420) (nil fontified nil 23418 . 23419) (nil fontified nil 23405 . 23418) (nil fontified nil 23403 . 23405) (nil fontified nil 23384 . 23403) (nil fontified nil 23374 . 23384) (nil fontified nil 23373 . 23374) (nil fontified nil 23365 . 23373) (nil fontified nil 23357 . 23365) (23357 . 23824) nil ("        set_data(\"previous\",message.from_user.id,message.text)
        quest = question_array[0]
        set_data(\"attempt\",message.from_user.id,3)
        set_data(\"completed\",message.from_user.id,0)
        set_data(\"current\",message.from_user.id,quest.correct_id)
        set_data(\"question\",message.from_user.id,question_array.index(quest))
        await bot.send_message(message.chat.id,text=quest.text ,reply_markup=question_create(quest),parse_mode=\"Markdown\")" . 23357) ((marker . 23787) . -467) ((marker*) . 1) ((marker) . -467) ((marker*) . 92) ((marker) . -376) (nil fontified t 23419 . 23420) (nil fontified t 23453 . 23454) (nil fontified t 23504 . 23505) (nil fontified t 23557 . 23558) (nil fontified t 23623 . 23624) (nil fontified t 23701 . 23702) (nil rear-nonsticky t 23823 . 23824) nil (nil rear-nonsticky nil 23823 . 23824) (nil fontified nil 23823 . 23824) (nil fontified nil 23813 . 23823) (nil fontified nil 23801 . 23813) (nil fontified nil 23800 . 23801) (nil fontified nil 23795 . 23800) (nil fontified nil 23794 . 23795) (nil fontified nil 23748 . 23794) (nil fontified nil 23746 . 23748) (nil fontified nil 23733 . 23746) (nil fontified nil 23732 . 23733) (nil fontified nil 23715 . 23732) (nil fontified nil 23710 . 23715) (nil fontified nil 23701 . 23710) (nil fontified nil 23700 . 23701) (nil fontified nil 23699 . 23700) (nil fontified nil 23694 . 23699) (nil fontified nil 23693 . 23694) (nil fontified nil 23672 . 23693) (nil fontified nil 23670 . 23672) (nil fontified nil 23651 . 23670) (nil fontified nil 23641 . 23651) (nil fontified nil 23640 . 23641) (nil fontified nil 23623 . 23640) (nil fontified nil 23622 . 23623) (nil fontified nil 23605 . 23622) (nil fontified nil 23603 . 23605) (nil fontified nil 23584 . 23603) (nil fontified nil 23575 . 23584) (nil fontified nil 23574 . 23575) (nil fontified nil 23557 . 23574) (nil fontified nil 23556 . 23557) (nil fontified nil 23554 . 23556) (nil fontified nil 23552 . 23554) (nil fontified nil 23533 . 23552) (nil fontified nil 23522 . 23533) (nil fontified nil 23521 . 23522) (nil fontified nil 23504 . 23521) (nil fontified nil 23503 . 23504) (nil fontified nil 23501 . 23503) (nil fontified nil 23499 . 23501) (nil fontified nil 23480 . 23499) (nil fontified nil 23471 . 23480) (nil fontified nil 23470 . 23471) (nil fontified nil 23453 . 23470) (nil fontified nil 23452 . 23453) (nil fontified nil 23451 . 23452) (nil fontified nil 23450 . 23451) (nil fontified nil 23433 . 23450) (nil fontified nil 23428 . 23433) (nil fontified nil 23420 . 23428) (nil fontified nil 23419 . 23420) (nil fontified nil 23418 . 23419) (nil fontified nil 23405 . 23418) (nil fontified nil 23403 . 23405) (nil fontified nil 23384 . 23403) (nil fontified nil 23374 . 23384) (nil fontified nil 23373 . 23374) (nil fontified nil 23365 . 23373) (nil fontified nil 23357 . 23365) (23357 . 23824) nil (23345 . 23357) ("        " . 23344) ((marker . 23787) . -8) ((marker . 23344) . -8) (23352 . 23353) nil ("    " . -23352) ((marker . 23787) . -4) 23356 nil (23344 . 23356) ("        " . 23344) ((marker . 23787) . -8) ((marker . 23778) . -8) ((marker . 23344) . -8) 23352 nil ("    " . -23352) ((marker . 23787) . -4) ((marker . 23778) . -4) ((marker . 23344) . -4) 23356 nil ("
        set_data(\"previous-post\",message.from_user.id,message.text)
        " . 23356) ((marker . 23778) . -77) ((marker . 23344) . -77) ((marker) . -77) nil (23344 . 23356) (t 25707 26803 626373 743000) nil (18237 . 18704) nil ("        set_data(\"previous\",message.from_user.id,message.text)
        quest = question_array[0]
        set_data(\"attempt\",message.from_user.id,3)
        set_data(\"completed\",message.from_user.id,0)
        set_data(\"current\",message.from_user.id,quest.correct_id)
        set_data(\"question\",message.from_user.id,question_array.index(quest))
        await bot.send_message(message.chat.id,text=quest.text ,reply_markup=question_create(quest),parse_mode=\"Markdown\")" . 18237) ((marker . 23778) . -467) ((marker . 18704) . -467) ((marker . 18246) . -9) ((marker . 18704) . -467) ((marker . 18247) . -10) ((marker . 18246) . -9) ((marker . 18704) . -467) ((marker . 18247) . -10) ((marker) . -467) (t 25707 26803 626373 743000) nil (18237 . 18245) ("            " . 18237) ((marker . 23787) . -12) ((marker . 23353) . -12) nil (18237 . 18249) ("        " . 18237) (t 25707 26803 626373 743000) nil (nil rear-nonsticky nil 44124 . 44125) (nil fontified nil 44099 . 44125) (44099 . 44125) nil ("bot.polling()" . 44099) ((marker . 23778) . -13) ((marker . 44031) . -13) (t 25704 47290 427507 746000) nil ("bot.infinity_polling(True)" . 1) ((marker . 23787) . -26) ((marker*) . 1) ((marker) . -26) ((marker*) . 6) ((marker) . -21) (nil rear-nonsticky t 26 . 27) nil (nil rear-nonsticky nil 26 . 27) (nil fontified nil 1 . 27) (1 . 27) (t 25704 47290 427507 746000) nil (10416 . 10417) nil ("
" . -10333) 10334 nil ("        " . -10334) 10342 nil (nil rear-nonsticky nil 10424 . 10425) (nil fontified nil 10424 . 10425) (nil fontified nil 10420 . 10424) (nil fontified nil 10405 . 10420) (nil fontified nil 10404 . 10405) (nil fontified nil 10397 . 10404) (nil fontified nil 10395 . 10397) (nil fontified nil 10385 . 10395) (nil fontified nil 10383 . 10385) (nil fontified nil 10375 . 10383) (nil fontified nil 10374 . 10375) (nil fontified nil 10372 . 10374) (nil fontified nil 10365 . 10372) (nil fontified nil 10360 . 10365) (nil fontified nil 10359 . 10360) (nil fontified nil 10350 . 10359) (nil fontified nil 10343 . 10350) (nil fontified nil 10342 . 10343) (10342 . 10425) nil (10333 . 10342) (t 25704 47128 91611 927000) nil (10333 . 10416) nil ("
        question(\"10) Отпуск\", [\"Resort\", \"Vacation\", \"Route\"], 1, randomize=True)" . 10333) (t 25704 47128 91611 927000) nil (23524 . 23526) nil ("9" . -23524) 23525 (t 25704 47116 977386 950000) nil ("                                " . -23701) nil ("                                " . -23635) nil ("                                " . -23584) nil ("                                " . -23542) nil ("                                " . -23462) nil ("                                " . -23409) nil ("                                      " . -23346) nil (nil rear-nonsticky nil 23999 . 24000) (nil fontified nil 23999 . 24000) (nil fontified nil 23998 . 23999) (nil fontified nil 23993 . 23998) (nil fontified nil 23992 . 23993) (nil fontified nil 23971 . 23992) (nil fontified nil 23969 . 23971) (nil fontified nil 23950 . 23969) (nil fontified nil 23940 . 23950) (nil fontified nil 23939 . 23940) (nil fontified nil 23931 . 23939) (nil fontified nil 23891 . 23931) (nil fontified nil 23890 . 23891) (nil fontified nil 23889 . 23890) (nil fontified nil 23872 . 23889) (nil fontified nil 23870 . 23872) (nil fontified nil 23851 . 23870) (nil fontified nil 23842 . 23851) (nil fontified nil 23841 . 23842) (nil fontified nil 23833 . 23841) (nil fontified nil 23793 . 23833) (nil fontified nil 23792 . 23793) (nil fontified nil 23791 . 23792) (nil fontified nil 23789 . 23791) (nil fontified nil 23787 . 23789) (nil fontified nil 23775 . 23787) (nil fontified nil 23768 . 23775) (nil fontified nil 23759 . 23768) (nil fontified nil 23758 . 23759) (nil fontified nil 23750 . 23758) (nil fontified nil 23710 . 23750) (nil fontified nil 23709 . 23710) (nil fontified nil 23708 . 23709) (nil fontified nil 23699 . 23708) (nil fontified nil 23698 . 23699) (nil fontified nil 23681 . 23698) (nil fontified nil 23676 . 23681) (nil fontified nil 23652 . 23676) (nil fontified nil 23636 . 23652) (nil fontified nil 23633 . 23636) (nil fontified nil 23629 . 23633) (nil fontified nil 23628 . 23629) (nil fontified nil 23627 . 23628) (nil fontified nil 23622 . 23627) (nil fontified nil 23621 . 23622) (nil fontified nil 23620 . 23621) (nil fontified nil 23618 . 23620) (nil fontified nil 23599 . 23618) (nil fontified nil 23589 . 23599) (nil fontified nil 23588 . 23589) (nil fontified nil 23580 . 23588) (nil fontified nil 23579 . 23580) (nil fontified nil 23576 . 23579) (nil fontified nil 23575 . 23576) (nil fontified nil 23573 . 23575) (nil fontified nil 23568 . 23573) (nil fontified nil 23564 . 23568) (nil fontified nil 23524 . 23564) (nil fontified nil 23523 . 23524) (nil fontified nil 23522 . 23523) (nil fontified nil 23520 . 23522) (nil fontified nil 23518 . 23520) (nil fontified nil 23499 . 23518) (nil fontified nil 23488 . 23499) (nil fontified nil 23487 . 23488) (nil fontified nil 23479 . 23487) (nil fontified nil 23439 . 23479) (nil fontified nil 23438 . 23439) (nil fontified nil 23437 . 23438) (nil fontified nil 23424 . 23437) (nil fontified nil 23422 . 23424) (nil fontified nil 23403 . 23422) (nil fontified nil 23393 . 23403) (nil fontified nil 23392 . 23393) (nil fontified nil 23384 . 23392) (nil fontified nil 23344 . 23384) (23344 . 24000) nil ("  set_data(\"previous\",message.from_user.id,message.text)
        set_data(\"completed\",message.from_user.id,0)
        quiz = 1 if(int(get_data(\"question\",message.from_user.id)) <= 9) else 0
        quest = question_array[0+quiz*10]
        set_data(\"attempt\",message.from_user.id,2)
        set_data(\"current\",message.from_user.id,quest.correct_id)
        set_data(\"question\",message.from_user.id,question_array.index(quest))" . 23344) (t 25704 46765 500132 425000) nil (23269 . 23770) nil ("set_data(\"previous-post\",message.from_user.id,message.text)
        
        set_data(\"previous\",message.from_user.id,message.text)
        set_data(\"completed\",message.from_user.id,0)
        quiz = 1 if(int(get_data(\"question\",message.from_user.id)) <= 9) else 0
        quest = question_array[0+quiz*10]
        set_data(\"attempt\",message.from_user.id,2)
        set_data(\"current\",message.from_user.id,quest.correct_id)
        set_data(\"question\",message.from_user.id,question_array.index(quest))" . 23269) (t 25704 46765 500132 425000) nil (24378 . 24387) nil ("        " . -24273) 24287 nil (nil rear-nonsticky nil 24385 . 24386) (nil fontified nil 24385 . 24386) (nil fontified nil 24383 . 24385) (nil fontified nil 24381 . 24383) (nil fontified nil 24362 . 24381) (nil fontified nil 24346 . 24362) (nil fontified nil 24345 . 24346) (nil fontified nil 24329 . 24345) (nil fontified nil 24328 . 24329) (nil fontified nil 24327 . 24328) (nil fontified nil 24325 . 24327) (nil fontified nil 24323 . 24325) (nil fontified nil 24315 . 24323) (nil fontified nil 24304 . 24315) (nil fontified nil 24290 . 24304) (nil fontified nil 24289 . 24290) (nil fontified nil 24273 . 24289) (24273 . 24386) (t 25704 46609 569041 114000) nil (nil rear-nonsticky nil 34817 . 34818) (nil fontified nil 34808 . 34818) (nil fontified nil 34804 . 34808) (nil fontified nil 34803 . 34804) (nil fontified nil 34801 . 34803) (nil fontified nil 34782 . 34801) (nil fontified nil 34767 . 34782) (nil fontified nil 34766 . 34767) (nil fontified nil 34757 . 34766) (nil fontified nil 34754 . 34757) (34754 . 34818) nil (34753 . 34754) (t 25704 46157 680328 450000) nil (33994 . 34058) nil ("and get_data(\"previous-post\",message.from_user.id) == \"Grammar✏\"" . 33994) (t 25704 46157 680328 450000) nil (36805 . 36863) (t 25704 46146 697358 969000) nil ("
        user_name = get_data(\"name\",message.from_user.id)" . 36805) (t 25704 46138 658519 621000) nil ("    " . -36524) 36528 nil (36516 . 36528) (t 25704 46055 239453 560000) nil (nil fontified nil 38144 . 38145) (nil fontified nil 38136 . 38144) (nil fontified nil 38135 . 38136) (nil fontified nil 38134 . 38135) (nil fontified nil 38120 . 38134) (nil fontified nil 38086 . 38120) (nil fontified nil 38070 . 38086) (nil fontified nil 38069 . 38070) (nil fontified nil 38068 . 38069) (nil fontified nil 38024 . 38068) (nil fontified nil 38021 . 38024) (nil fontified nil 38006 . 38021) (nil fontified nil 38005 . 38006) (nil fontified nil 38004 . 38005) (nil fontified nil 38003 . 38004) (nil fontified nil 37955 . 38003) (nil fontified nil 37939 . 37955) (nil fontified nil 37937 . 37939) (nil fontified nil 37893 . 37937) (nil fontified nil 37877 . 37893) (nil fontified nil 37876 . 37877) (nil fontified nil 37875 . 37876) (nil fontified nil 37832 . 37875) (nil fontified nil 37816 . 37832) (nil fontified nil 37815 . 37816) (nil fontified nil 37814 . 37815) (nil fontified nil 37811 . 37814) (nil fontified nil 37807 . 37811) (nil fontified nil 37799 . 37807) (nil fontified nil 37798 . 37799) (nil fontified nil 37797 . 37798) (nil fontified nil 37789 . 37797) (nil fontified nil 37788 . 37789) (nil fontified nil 37787 . 37788) (nil fontified nil 37754 . 37787) (nil fontified nil 37738 . 37754) (nil fontified nil 37737 . 37738) (nil fontified nil 37736 . 37737) (nil fontified nil 37699 . 37736) (nil fontified nil 37683 . 37699) (nil fontified nil 37682 . 37683) (nil fontified nil 37681 . 37682) (nil fontified nil 37649 . 37681) (nil fontified nil 37633 . 37649) (nil fontified nil 37632 . 37633) (nil fontified nil 37631 . 37632) (nil fontified nil 37597 . 37631) (nil fontified nil 37581 . 37597) (nil fontified nil 37580 . 37581) (nil fontified nil 37579 . 37580) (nil fontified nil 37540 . 37579) (nil fontified nil 37524 . 37540) (nil fontified nil 37522 . 37524) (nil fontified nil 37491 . 37522) (nil fontified nil 37475 . 37491) (nil fontified nil 37473 . 37475) (nil fontified nil 37437 . 37473) (nil fontified nil 37421 . 37437) (nil fontified nil 37419 . 37421) (nil fontified nil 37397 . 37419) (nil fontified nil 37381 . 37397) (nil fontified nil 37380 . 37381) (nil fontified nil 37379 . 37380) (nil fontified nil 37359 . 37379) (nil fontified nil 37343 . 37359) (nil fontified nil 37341 . 37343) (nil fontified nil 37317 . 37341) (nil fontified nil 37301 . 37317) (nil fontified nil 37299 . 37301) (nil fontified nil 37283 . 37299) (nil fontified nil 37267 . 37283) (nil fontified nil 37266 . 37267) (nil fontified nil 37265 . 37266) (nil fontified nil 37262 . 37265) (nil fontified nil 37253 . 37262) (nil fontified nil 37249 . 37253) (nil fontified nil 37245 . 37249) (nil fontified nil 37244 . 37245) (nil fontified nil 37243 . 37244) (nil fontified nil 37214 . 37243) (nil fontified nil 37212 . 37214) (nil fontified nil 37189 . 37212) (nil fontified nil 37187 . 37189) (nil fontified nil 37169 . 37187) (nil fontified nil 37167 . 37169) (nil fontified nil 37145 . 37167) (nil fontified nil 37143 . 37145) (nil fontified nil 37127 . 37143) (nil fontified nil 37125 . 37127) (nil fontified nil 37107 . 37125) (nil fontified nil 37105 . 37107) (nil fontified nil 37081 . 37105) (nil fontified nil 37079 . 37081) (nil fontified nil 37058 . 37079) (nil fontified nil 37056 . 37058) (nil fontified nil 37043 . 37056) (nil fontified nil 37041 . 37043) (nil fontified nil 37031 . 37041) (nil fontified nil 37029 . 37031) (nil fontified nil 37022 . 37029) (nil fontified nil 37020 . 37022) (nil fontified nil 37009 . 37020) (nil fontified nil 37007 . 37009) (nil fontified nil 36993 . 37007) (nil fontified nil 36991 . 36993) (nil fontified nil 36975 . 36991) (nil fontified nil 36973 . 36975) (nil fontified nil 36959 . 36973) (nil fontified nil 36957 . 36959) (nil fontified nil 36947 . 36957) (nil fontified nil 36945 . 36947) (nil fontified nil 36932 . 36945) (nil fontified nil 36930 . 36932) (nil fontified nil 36919 . 36930) (nil fontified nil 36917 . 36919) (nil fontified nil 36911 . 36917) (nil fontified nil 36909 . 36911) (nil fontified nil 36898 . 36909) (nil fontified nil 36896 . 36898) (nil fontified nil 36891 . 36896) (nil fontified nil 36889 . 36891) (nil fontified nil 36882 . 36889) (nil fontified nil 36880 . 36882) (nil fontified nil 36876 . 36880) (nil fontified nil 36875 . 36876) (nil fontified nil 36872 . 36875) (nil fontified nil 36864 . 36872) (nil fontified nil 36856 . 36864) (36856 . 38145) nil ("        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [
                \"Where are you?\",
                \"Do you plan to travel?\",
                \"Are you traveling?\",
                \"Where are you going?\",
                \"Have you been on any recent trips?\",
                \"Are you exploring new places?\",
                \"What's your dream travel destination?\",
                \"Have you ever traveled for work?\",
                \"Are you an adventure traveler?\",
                \"What's your best travel packing tip?\",
                \"What's your favorite way to travel?\",
                \"Do you have any upcoming trips?\",
                \"Do you keep a travel journal?\",
        ]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"I've heard you've become quite the globetrotter.\",
                \"I've heard whispers of your travel escapades.\",
                \"I've heard tales of your travel adventures.\",
                \"Seems like you're on a quest to see the world.\",
        ]" . 36856) (t 25704 12483 824423 655000) nil (40016 . 41305) nil ("        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [
                \"Where are you?\",
                \"Do you plan to travel?\",
                \"Are you traveling?\",
                \"Where are you going?\",
                \"Have you been on any recent trips?\",
                \"Are you exploring new places?\",
                \"What's your dream travel destination?\",
                \"Have you ever traveled for work?\",
                \"Are you an adventure traveler?\",
                \"What's your favorite way to travel?\",
                \"Do you have any upcoming trips?\",
        ]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"I've heard stories of your travel adventures.\",
                \"Seems like you're on a quest to see the world.\",
        ]" . 40016) (t 25704 12483 824423 655000) nil ("resize_keyboard=True" . 41486) (t 25704 12467 84456 985000) nil ("
                \"Do you keep a travel journal?\"," . 40948) (t 25704 12417 387896 526000) nil (nil rear-nonsticky nil 41581 . 41582) (nil fontified nil 41577 . 41582) (nil fontified nil 41573 . 41577) (41573 . 41582) nil ("\"Greet\"" . 41573) (t 25704 12376 591325 755000) nil (41363 . 41372) nil ("usr_start" . 41363) (t 25704 12376 591325 755000) nil (41242 . 41249) nil ("x" . -41242) ("\\" . -41243) ("s" . -41244) 41245 nil (41242 . 41245) nil ("tales" . 41242) 41247 (t 25704 12369 418010 147000) nil ("
                \"I've heard you've become quite the globetrotter.\",
                \"I've heard whispers of your travel escapades.\"," . 41213) ("\\" . -41213) 41214 nil (41213 . 41214) (t 25704 12345 691404 43000) nil ("\\" . 41213) nil (36525 . 41214) (36525 . 36593) nil ("
                \"I've heard you've become quite the globetrotter.\"," . 36525) ("clear_data(\"past\",message.from_user.id)
        clear_data(\"generated\",message.from_user.id)
        set_data(\"previous-post\",message.from_user.id,\"Chat🗣\")
        send=start_prompt
        name_list = generate_names()
        user_name, bot_name = select_names(name_list)
        user_name = get_data(\"name\",message.from_user.id)
        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [
                \"Where are you?\",
                \"Do you plan to travel?\",
                \"Are you traveling?\",
                \"Where are you going?\",
                \"Have you been on any recent trips?\",
                \"Are you exploring new places?\",
                \"What's your dream travel destination?\",
                \"Have you ever traveled for work?\",
                \"Are you an adventure traveler?\",
                \"What's your best travel packing tip?\",
                \"What's your favorite way to travel?\",
                \"Do you have any upcoming trips?\",
                \"Do you keep a travel journal?\",
        ]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"I've heard you've become quite the globetrotter.\",
                \"I've heard whispers of your travel escapades.\",
                \"I've heard tales of your travel adventures.\",
                \"Seems like you're on a quest to see the world.\",
        ]
        usr_start = f\"{random.choice(greeting)} {bot_name}! It's me, {user_name}! {random.choice(conv)} {random.choice(questions)}\"
        kbd = telebot.types.ReplyKeyboardMarkup()
        kbd.row(usr_start)
        kbd.row(\"!Go back\")
        await bot.send_message(message.chat.id, text=send,reply_markup=kbd,parse_mode=\"Markdown\")
    elif(prevmess == \"complete\" and get_data(\"previous-post\",message.from_user.id) == \"Chat🗣\" and message.text != \"!Go back\" and message.text != \"!Reset\"):
        print(format_data(get_data(\"generated\",message.from_user.id)))
        print(type(format_data(get_data(\"generated\",message.from_user.id))))
        output = prompt(format_data(get_data(\"past\",message.from_user.id)),format_data(get_data(\"generated\",message.from_user.id)),message.text)
        print(output)
        add_data(\"past\",message.from_user.id,message.text)
        add_data(\"generated\",message.from_user.id,output[\"generated_text\"])
        send = output[\"generated_text\"]
        kbd=types.ReplyKeyboardMarkup()
        kbd.row(\"!Reset\")
        kbd.row(\"!Go back\")
        await bot.send_message(message.chat.id, send, reply_markup=kbd, parse_mode=\"Markdown\")
    elif(prevmess == \"complete\" and get_data(\"previous-post\",message.from_user.id) == \"Chat🗣\" and message.text == \"!Reset\"):
        clear_data(\"past\",message.from_user.id)
        clear_data(\"generated\",message.from_user.id)
        set_data(\"previous-post\",message.from_user.id,\"Chat🗣\")
        send=start_prompt
        name_list = generate_names()
        user_name, bot_name = select_names(name_list)
        user_name = get_data(\"name\",message.from_user.id)
        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [
                \"Where are you?\",
                \"Do you plan to travel?\",
                \"Are you traveling?\",
                \"Where are you going?\",
                \"Have you been on any recent trips?\",
                \"Are you exploring new places?\",
                \"What's your dream travel destination?\",
                \"Have you ever traveled for work?\",
                \"Are you an adventure traveler?\",
                \"What's your favorite way to travel?\",
                \"Do you have any upcoming trips?\",
                \"Do you keep a travel journal?\",
        ]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",\\" . 36525) nil (36525 . 41214) (36525 . 36593) nil ("
                \"I've heard you've become quite the globetrotter.\"," . 36525) ("clear_data(\"past\",message.from_user.id)
        clear_data(\"generated\",message.from_user.id)
        set_data(\"previous-post\",message.from_user.id,\"Chat🗣\")
        send=start_prompt
        name_list = generate_names()
        user_name, bot_name = select_names(name_list)
        user_name = get_data(\"name\",message.from_user.id)
        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [
                \"Where are you?\",
                \"Do you plan to travel?\",
                \"Are you traveling?\",
                \"Where are you going?\",
                \"Have you been on any recent trips?\",
                \"Are you exploring new places?\",
                \"What's your dream travel destination?\",
                \"Have you ever traveled for work?\",
                \"Are you an adventure traveler?\",
                \"What's your best travel packing tip?\",
                \"What's your favorite way to travel?\",
                \"Do you have any upcoming trips?\",
                \"Do you keep a travel journal?\",
        ]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"I've heard you've become quite the globetrotter.\",
                \"I've heard whispers of your travel escapades.\",
                \"I've heard tales of your travel adventures.\",
                \"Seems like you're on a quest to see the world.\",
        ]
        usr_start = f\"{random.choice(greeting)} {bot_name}! It's me, {user_name}! {random.choice(conv)} {random.choice(questions)}\"
        kbd = telebot.types.ReplyKeyboardMarkup()
        kbd.row(usr_start)
        kbd.row(\"!Go back\")
        await bot.send_message(message.chat.id, text=send,reply_markup=kbd,parse_mode=\"Markdown\")
    elif(prevmess == \"complete\" and get_data(\"previous-post\",message.from_user.id) == \"Chat🗣\" and message.text != \"!Go back\" and message.text != \"!Reset\"):
        print(format_data(get_data(\"generated\",message.from_user.id)))
        print(type(format_data(get_data(\"generated\",message.from_user.id))))
        output = prompt(format_data(get_data(\"past\",message.from_user.id)),format_data(get_data(\"generated\",message.from_user.id)),message.text)
        print(output)
        add_data(\"past\",message.from_user.id,message.text)
        add_data(\"generated\",message.from_user.id,output[\"generated_text\"])
        send = output[\"generated_text\"]
        kbd=types.ReplyKeyboardMarkup()
        kbd.row(\"!Reset\")
        kbd.row(\"!Go back\")
        await bot.send_message(message.chat.id, send, reply_markup=kbd, parse_mode=\"Markdown\")
    elif(prevmess == \"complete\" and get_data(\"previous-post\",message.from_user.id) == \"Chat🗣\" and message.text == \"!Reset\"):
        clear_data(\"past\",message.from_user.id)
        clear_data(\"generated\",message.from_user.id)
        set_data(\"previous-post\",message.from_user.id,\"Chat🗣\")
        send=start_prompt
        name_list = generate_names()
        user_name, bot_name = select_names(name_list)
        user_name = get_data(\"name\",message.from_user.id)
        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [
                \"Where are you?\",
                \"Do you plan to travel?\",
                \"Are you traveling?\",
                \"Where are you going?\",
                \"Have you been on any recent trips?\",
                \"Are you exploring new places?\",
                \"What's your dream travel destination?\",
                \"Have you ever traveled for work?\",
                \"Are you an adventure traveler?\",
                \"What's your favorite way to travel?\",
                \"Do you have any upcoming trips?\",
                \"Do you keep a travel journal?\",
        ]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",\\" . -36525) 41214 nil (41213 . 41214) (t 25704 12345 691404 43000) nil ("
                \"What's your best travel packing tip?\"," . 40842) (t 25704 12272 868276 405000) nil ("    " . -39875) 39878 (t 25704 12268 78291 54000) nil (nil fontified nil 41676 . 41677) (nil fontified nil 41675 . 41676) (nil fontified nil 41674 . 41675) (nil fontified nil 41665 . 41674) (nil fontified nil 41664 . 41665) (nil fontified nil 41651 . 41664) (nil fontified nil 41650 . 41651) (nil fontified nil 41649 . 41650) (nil fontified nil 41629 . 41649) (nil fontified nil 41628 . 41629) (nil fontified nil 41627 . 41628) (nil fontified nil 41626 . 41627) (nil fontified nil 41615 . 41626) (nil fontified nil 41606 . 41615) (nil fontified nil 41604 . 41606) (nil fontified nil 41595 . 41604) (nil fontified nil 41594 . 41595) (nil fontified nil 41593 . 41594) (nil fontified nil 41587 . 41593) (nil fontified nil 41582 . 41587) (nil fontified nil 41569 . 41582) (nil fontified nil 41568 . 41569) (nil fontified nil 41567 . 41568) (nil fontified nil 41563 . 41567) (nil fontified nil 41558 . 41563) (nil fontified nil 41554 . 41558) (nil fontified nil 41546 . 41554) (nil fontified nil 41545 . 41546) (nil fontified nil 41544 . 41545) (nil fontified nil 41536 . 41544) (nil fontified nil 41535 . 41536) (nil fontified nil 41534 . 41535) (nil fontified nil 41520 . 41534) (nil fontified nil 41486 . 41520) (nil fontified nil 41470 . 41486) (nil fontified nil 41469 . 41470) (nil fontified nil 41468 . 41469) (nil fontified nil 41423 . 41468) (nil fontified nil 41407 . 41423) (nil fontified nil 41406 . 41407) (nil fontified nil 41405 . 41406) (nil fontified nil 41358 . 41405) (nil fontified nil 41342 . 41358) (nil fontified nil 41341 . 41342) (nil fontified nil 41340 . 41341) (nil fontified nil 41290 . 41340) (nil fontified nil 41274 . 41290) (nil fontified nil 41273 . 41274) (nil fontified nil 41272 . 41273) (nil fontified nil 41224 . 41272) (nil fontified nil 41208 . 41224) (nil fontified nil 41206 . 41208) (nil fontified nil 41162 . 41206) (nil fontified nil 41146 . 41162) (nil fontified nil 41145 . 41146) (nil fontified nil 41144 . 41145) (nil fontified nil 41101 . 41144) (nil fontified nil 41085 . 41101) (nil fontified nil 41084 . 41085) (nil fontified nil 41083 . 41084) (nil fontified nil 41080 . 41083) (nil fontified nil 41076 . 41080) (nil fontified nil 41068 . 41076) (nil fontified nil 41067 . 41068) (nil fontified nil 41066 . 41067) (nil fontified nil 41058 . 41066) (nil fontified nil 41057 . 41058) (nil fontified nil 41056 . 41057) (nil fontified nil 41025 . 41056) (nil fontified nil 41009 . 41025) (nil fontified nil 41008 . 41009) (nil fontified nil 41007 . 41008) (nil fontified nil 40974 . 41007) (nil fontified nil 40958 . 40974) (nil fontified nil 40957 . 40958) (nil fontified nil 40956 . 40957) (nil fontified nil 40919 . 40956) (nil fontified nil 40903 . 40919) (nil fontified nil 40902 . 40903) (nil fontified nil 40901 . 40902) (nil fontified nil 40863 . 40901) (nil fontified nil 40847 . 40863) (nil fontified nil 40845 . 40847) (nil fontified nil 40813 . 40845) (nil fontified nil 40797 . 40813) (nil fontified nil 40796 . 40797) (nil fontified nil 40795 . 40796) (nil fontified nil 40761 . 40795) (nil fontified nil 40745 . 40761) (nil fontified nil 40744 . 40745) (nil fontified nil 40743 . 40744) (nil fontified nil 40704 . 40743) (nil fontified nil 40688 . 40704) (nil fontified nil 40686 . 40688) (nil fontified nil 40655 . 40686) (nil fontified nil 40639 . 40655) (nil fontified nil 40637 . 40639) (nil fontified nil 40601 . 40637) (nil fontified nil 40585 . 40601) (nil fontified nil 40583 . 40585) (nil fontified nil 40561 . 40583) (nil fontified nil 40545 . 40561) (nil fontified nil 40544 . 40545) (nil fontified nil 40543 . 40544) (nil fontified nil 40523 . 40543) (nil fontified nil 40507 . 40523) (nil fontified nil 40505 . 40507) (nil fontified nil 40481 . 40505) (nil fontified nil 40465 . 40481) (nil fontified nil 40463 . 40465) (nil fontified nil 40447 . 40463) (nil fontified nil 40431 . 40447) (nil fontified nil 40430 . 40431) (nil fontified nil 40429 . 40430) (nil fontified nil 40426 . 40429) (nil fontified nil 40417 . 40426) (nil fontified nil 40413 . 40417) (nil fontified nil 40409 . 40413) (nil fontified nil 40408 . 40409) (nil fontified nil 40407 . 40408) (nil fontified nil 40378 . 40407) (nil fontified nil 40376 . 40378) (nil fontified nil 40353 . 40376) (nil fontified nil 40351 . 40353) (nil fontified nil 40333 . 40351) (nil fontified nil 40331 . 40333) (nil fontified nil 40309 . 40331) (nil fontified nil 40307 . 40309) (nil fontified nil 40291 . 40307) (nil fontified nil 40289 . 40291) (nil fontified nil 40271 . 40289) (nil fontified nil 40269 . 40271) (nil fontified nil 40245 . 40269) (nil fontified nil 40243 . 40245) (nil fontified nil 40222 . 40243) (nil fontified nil 40220 . 40222) (nil fontified nil 40207 . 40220) (nil fontified nil 40205 . 40207) (nil fontified nil 40195 . 40205) (nil fontified nil 40193 . 40195) (nil fontified nil 40186 . 40193) (nil fontified nil 40184 . 40186) (nil fontified nil 40173 . 40184) (nil fontified nil 40171 . 40173) (nil fontified nil 40157 . 40171) (nil fontified nil 40155 . 40157) (nil fontified nil 40139 . 40155) (nil fontified nil 40137 . 40139) (nil fontified nil 40123 . 40137) (nil fontified nil 40121 . 40123) (nil fontified nil 40111 . 40121) (nil fontified nil 40109 . 40111) (nil fontified nil 40096 . 40109) (nil fontified nil 40094 . 40096) (nil fontified nil 40083 . 40094) (nil fontified nil 40081 . 40083) (nil fontified nil 40075 . 40081) (nil fontified nil 40073 . 40075) (nil fontified nil 40062 . 40073) (nil fontified nil 40060 . 40062) (nil fontified nil 40055 . 40060) (nil fontified nil 40053 . 40055) (nil fontified nil 40046 . 40053) (nil fontified nil 40044 . 40046) (nil fontified nil 40040 . 40044) (nil fontified nil 40039 . 40040) (nil fontified nil 40036 . 40039) (nil fontified nil 40028 . 40036) (nil fontified nil 40020 . 40028) (nil fontified nil 40019 . 40020) (nil fontified nil 40018 . 40019) (nil fontified nil 40016 . 40018) (nil fontified nil 39997 . 40016) (nil fontified nil 39996 . 39997) (nil fontified nil 39991 . 39996) (nil fontified nil 39990 . 39991) (nil fontified nil 39979 . 39990) (nil fontified nil 39970 . 39979) (nil fontified nil 39962 . 39970) (nil fontified nil 39961 . 39962) (nil fontified nil 39960 . 39961) (nil fontified nil 39951 . 39960) (nil fontified nil 39950 . 39951) (nil fontified nil 39935 . 39950) (nil fontified nil 39927 . 39935) (nil fontified nil 39925 . 39927) (nil fontified nil 39916 . 39925) (nil fontified nil 39908 . 39916) (nil fontified nil 39907 . 39908) (nil fontified nil 39906 . 39907) (nil fontified nil 39905 . 39906) (nil fontified nil 39888 . 39905) (nil fontified nil 39879 . 39888) (nil fontified nil 39871 . 39879) (39871 . 41677) nil ("    name_list = generate_names()
        user_name, bot_name = select_names(name_list)
        user_name = get_data(\"name\",message.from_user.id)
        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [
                \"Where are you?\",
                \"Do you plan to travel?\",
                \"Are you traveling?\",
                \"What was your favorite place to visit?\",
                \"Where are you going?\",
                \"Have you been on any recent trips?\",
                \"Are you exploring new places?\",
                \"What's your dream travel destination?\",
                \"Do you prefer solo travel or with companions?\",
                \"Have you ever traveled for work?\",
                \"What's your most memorable travel experience?\",
                \"Are you an adventure traveler?\",
                \"What's your best travel packing tip?\",
                \"Have you ever experienced culture shock?\",
                \"Do you like to try local food when you travel?\",
                \"What's your favorite way to travel?\",
                \"Have you ever traveled off the beaten path?\",
                \"Do you prefer hotels or alternative accommodations?\",
                \"What's the longest trip you've ever taken?\",
                \"Do you have any upcoming trips?\",
                \"What's the most beautiful place you've seen?\",
                \"Have you ever traveled for a special occasion?\",
                \"Do you keep a travel journal?\",
                \"What's the most challenging part of travel for you?\",
                \"Do you have any tips for saving money on travel?\",
        ]
        conv = [
                \"I've heard you're getting into traveling.\",        ]
        usr_start = f\"{random.choice(greeting)} {bot_name}! It's me, {user_name}! {random.choice(conv)} {random.choice(questions)}\"" . 39871) 40461 (t 25704 12224 828430 90000) nil (36707 . 38513) nil ("        name_list = generate_names()
        user_name, bot_name = select_names(name_list)
        user_name = get_data(\"name\",message.from_user.id)
        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [
                \"Where are you?\",
                \"Do you plan to travel?\",
                \"Are you traveling?\",
                \"Where are you going?\",
                \"Have you been on any recent trips?\",
                \"Are you exploring new places?\",
                \"What's your dream travel destination?\",
                \"Have you ever traveled for work?\",
                \"Are you an adventure traveler?\",
                \"What's your best travel packing tip?\",
                \"What's your favorite way to travel?\",
                \"Do you have any upcoming trips?\",
                \"Do you keep a travel journal?\",
        ]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"I've heard you've become quite the globetrotter.\",
                \"I've heard whispers of your travel escapades.\",
                \"I've heard tales of your travel adventures.\",
                \"Seems like you're on a quest to see the world.\",
        ]
        usr_start = f\"{random.choice(greeting)} {bot_name}! It's me, {user_name}! {random.choice(conv)} {random.choice(questions)}\"" . 36707) (t 25704 12224 828430 90000) nil (36856 . 38513) nil ("        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [
                \"Where are you?\",
                \"Do you plan to travel?\",
                \"Are you traveling?\",
                \"Where are you going?\",
                \"Have you been on any recent trips?\",
                \"Are you exploring new places?\",
                \"What's your dream travel destination?\",
                \"Have you ever traveled for work?\",
                \"Are you an adventure traveler?\",
                \"What's your best travel packing tip?\",
                \"What's your favorite way to travel?\",
                \"Do you have any upcoming trips?\",
                \"Do you keep a travel journal?\",
        ]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"I've heard you've become quite the globetrotter.\",
                \"I've heard whispers of your travel escapades.\",
                \"I've heard tales of your travel adventures.\",
                \"Seems like you're on a quest to see the world.\",
        ]
        usr_start = f\"{random.choice(greeting)} {bot_name}! It's me, {user_name}! {random.choice(conv)} {random.choice(questions)}\"" . 36856) (t 25704 12224 828430 90000) nil ("
                \"Have you ever experienced culture shock?\"," . 37738) (t 25704 12190 385216 677000) nil ("
                \"What's the longest trip you've ever taken?\"," . 37853) ("\\" . -37853) 37854 nil (37853 . 37854) nil ("
                \"Have you ever traveled off the beaten path?\"," . 37853) (t 25704 12158 825334 244000) nil ("
                \"Do you like to try local food when you travel?\"," . 37798) (t 25704 12138 692079 973000) nil ("
                \"What was your favorite place to visit?\"," . 37380) (t 25704 12134 642096 273000) nil ("
                \"Do you prefer solo travel or with companions?\"," . 37638) (t 25704 12132 425438 585000) nil ("
                \"What's your most memorable travel experience?\"," . 37755) (t 25704 12130 485446 476000) nil ("
                \"Do you prefer hotels or alternative accommodations?\"," . 38170) nil ("
                \"What's the most beautiful place you've seen?\",
                \"Have you ever traveled for a special occasion?\"," . 38354) (t 25704 12120 432154 541000) nil ("
                \"What's the most challenging part of travel for you?\",
                \"Do you have any tips for saving money on travel?\"," . 38533) (t 25704 12117 848831 983000) nil (39149 . 39150) nil ("," . -39149) 39150 nil ("
                \"I've heard you're collecting memories from around the globe.\",
                \"I've been told you're creating a travel story worth sharing.\",
                \"So, I hear you're embarking on a journey of a lifetime.\"" . 39150) nil ("
                \"I've been informed you're venturing into uncharted territories.\"," . 39084) nil ("
                \"Word has it that you're exploring the unknown.\"," . 39021) nil ("
                \"So, I hear you're filling your passport with stamps.\"," . 39021) nil ("
                \"I've been told you're discovering the beauty of travel.\"," . 39021) nil ("
                \"I've been informed you're jetting off to new destinations.\",
                \"Seems like you're diving headfirst into the world of travel.\",
                \"I've heard you're immersing yourself in different cultures.\"," . 39021) nil ("
                \"Word on the street is you're embracing the wanderlust.\"," . 38956) nil ("
                \"Rumor has it that you're embarking on new adventures.\"," . 38888) ("\\" . -38888) 38889 nil (38888 . 38889) nil ("
                \"I've heard you're planning some exciting trips.\"," . 38760) (t 25704 12060 822153 688000) nil (40201 . 40202) nil (" Long time no see, " . 40201) (t 25704 12039 58789 691000) nil ("        " . -37253) (t 25704 12037 155453 658000) nil (nil fontified nil 38689 . 38690) (nil fontified nil 38681 . 38689) (nil fontified nil 38679 . 38681) (nil fontified nil 38629 . 38679) (nil fontified nil 38613 . 38629) (nil fontified nil 38611 . 38613) (nil fontified nil 38558 . 38611) (nil fontified nil 38542 . 38558) (nil fontified nil 38540 . 38542) (nil fontified nil 38509 . 38540) (nil fontified nil 38493 . 38509) (nil fontified nil 38491 . 38493) (nil fontified nil 38443 . 38491) (nil fontified nil 38427 . 38443) (nil fontified nil 38425 . 38427) (nil fontified nil 38379 . 38425) (nil fontified nil 38363 . 38379) (nil fontified nil 38361 . 38363) (nil fontified nil 38328 . 38361) (nil fontified nil 38312 . 38328) (nil fontified nil 38310 . 38312) (nil fontified nil 38266 . 38310) (nil fontified nil 38250 . 38266) (nil fontified nil 38248 . 38250) (nil fontified nil 38195 . 38248) (nil fontified nil 38179 . 38195) (nil fontified nil 38177 . 38179) (nil fontified nil 38132 . 38177) (nil fontified nil 38116 . 38132) (nil fontified nil 38114 . 38116) (nil fontified nil 38077 . 38114) (nil fontified nil 38061 . 38077) (nil fontified nil 38059 . 38061) (nil fontified nil 38011 . 38059) (nil fontified nil 37995 . 38011) (nil fontified nil 37993 . 37995) (nil fontified nil 37951 . 37993) (nil fontified nil 37935 . 37951) (nil fontified nil 37933 . 37935) (nil fontified nil 37895 . 37933) (nil fontified nil 37879 . 37895) (nil fontified nil 37877 . 37879) (nil fontified nil 37845 . 37877) (nil fontified nil 37829 . 37845) (nil fontified nil 37827 . 37829) (nil fontified nil 37780 . 37827) (nil fontified nil 37764 . 37780) (nil fontified nil 37762 . 37764) (nil fontified nil 37728 . 37762) (nil fontified nil 37712 . 37728) (nil fontified nil 37710 . 37712) (nil fontified nil 37663 . 37710) (nil fontified nil 37647 . 37663) (nil fontified nil 37645 . 37647) (nil fontified nil 37606 . 37645) (nil fontified nil 37590 . 37606) (nil fontified nil 37588 . 37590) (nil fontified nil 37557 . 37588) (nil fontified nil 37541 . 37557) (nil fontified nil 37539 . 37541) (nil fontified nil 37503 . 37539) (nil fontified nil 37487 . 37503) (nil fontified nil 37485 . 37487) (nil fontified nil 37463 . 37485) (nil fontified nil 37447 . 37463) (nil fontified nil 37445 . 37447) (nil fontified nil 37405 . 37445) (nil fontified nil 37389 . 37405) (nil fontified nil 37387 . 37389) (nil fontified nil 37367 . 37387) (nil fontified nil 37351 . 37367) (nil fontified nil 37349 . 37351) (nil fontified nil 37325 . 37349) (nil fontified nil 37309 . 37325) (nil fontified nil 37307 . 37309) (nil fontified nil 37291 . 37307) (nil fontified nil 37275 . 37291) (nil fontified nil 37274 . 37275) (nil fontified nil 37273 . 37274) (nil fontified nil 37270 . 37273) (nil fontified nil 37261 . 37270) (nil fontified nil 37257 . 37261) (nil fontified nil 37253 . 37257) (37253 . 38690) nil ("questions = [\"Where are you now?\", \"Do you have any plans to travel?\", \"Are you currently traveling?\", \"What was your favorite place to travel?\", \"Where are you headed?\", \"Have you been on any recent trips?\", \"Are you exploring any new destinations?\", \"What's your dream travel destination?\", \"Do you prefer solo travel or traveling with companions?\", \"Have you ever traveled for work?\", \"What's the most memorable travel experience you've had?\", \"Are you a fan of adventure travel?\", \"What's your go-to travel packing tip?\", \"Have you ever experienced culture shock while traveling?\", \"Do you enjoy trying local cuisines while on a trip?\", \"What's your favorite mode of transportation when traveling?\", \"Have you ever traveled off the beaten path?\", \"Do you prefer staying in hotels or using alternative accommodations?\", \"What's the longest trip you've ever taken?\", \"Do you have any upcoming travel plans?\", \"What's the most beautiful place you've visited?\", \"Have you ever traveled for a special occasion?\", \"Do you keep a travel journal or document your trips in any way?\", \"What's the most challenging aspect of travel for you?\", \"Do you have any tips for saving money while traveling?\"]" . 37253) (t 25704 11991 975388 703000) nil (38447 . 39905) nil ("        questions = [
                \"Where are you?\",
                \"Do you plan to travel?\",
                \"Are you traveling?\",
                \"What was your favorite place to visit?\",
                \"Where are you going?\",
                \"Have you been on any recent trips?\",
                \"Are you exploring new places?\",
                \"What's your dream travel destination?\",
                \"Do you prefer solo travel or with companions?\",
                \"Have you ever traveled for work?\",
                \"What's your most memorable travel experience?\",
                \"Are you an adventure traveler?\",
                \"What's your best travel packing tip?\",
                \"Have you ever experienced culture shock?\",
                \"Do you like to try local food when you travel?\",
                \"What's your favorite way to travel?\",
                \"Have you ever traveled off the beaten path?\",
                \"Do you prefer hotels or alternative accommodations?\",
                \"What's the longest trip you've ever taken?\",
                \"Do you have any upcoming trips?\",
                \"What's the most beautiful place you've seen?\",
                \"Have you ever traveled for a special occasion?\",
                \"Do you keep a travel journal?\",
                \"What's the most challenging part of travel for you?\",
                \"Do you have any tips for saving money on travel?\",
        ]" . 38447) (nil fontified t 38468 . 38469) (nil fontified t 38501 . 38503) (nil fontified t 38543 . 38545) (nil fontified t 38581 . 38583) (nil fontified t 38639 . 38641) (nil fontified t 38679 . 38681) (nil fontified t 38733 . 38735) (nil fontified t 38782 . 38784) (nil fontified t 38839 . 38841) (nil fontified t 38904 . 38906) (nil fontified t 38956 . 38958) (nil fontified t 39021 . 39023) (nil fontified t 39071 . 39073) (nil fontified t 39127 . 39129) (nil fontified t 39187 . 39189) (nil fontified t 39253 . 39255) (nil fontified t 39308 . 39310) (nil fontified t 39371 . 39373) (nil fontified t 39442 . 39444) (nil fontified t 39504 . 39506) (nil fontified t 39555 . 39557) (nil fontified t 39619 . 39621) (nil fontified t 39685 . 39687) (nil fontified t 39734 . 39736) (nil fontified t 39805 . 39807) (nil fontified t 39873 . 39875) (nil fontified t 39883 . 39884) nil (nil fontified nil 39883 . 39884) (nil fontified nil 39875 . 39883) (nil fontified nil 39873 . 39875) (nil fontified nil 39823 . 39873) (nil fontified nil 39807 . 39823) (nil fontified nil 39805 . 39807) (nil fontified nil 39752 . 39805) (nil fontified nil 39736 . 39752) (nil fontified nil 39734 . 39736) (nil fontified nil 39703 . 39734) (nil fontified nil 39687 . 39703) (nil fontified nil 39685 . 39687) (nil fontified nil 39637 . 39685) (nil fontified nil 39621 . 39637) (nil fontified nil 39619 . 39621) (nil fontified nil 39573 . 39619) (nil fontified nil 39557 . 39573) (nil fontified nil 39555 . 39557) (nil fontified nil 39522 . 39555) (nil fontified nil 39506 . 39522) (nil fontified nil 39504 . 39506) (nil fontified nil 39460 . 39504) (nil fontified nil 39444 . 39460) (nil fontified nil 39442 . 39444) (nil fontified nil 39389 . 39442) (nil fontified nil 39373 . 39389) (nil fontified nil 39371 . 39373) (nil fontified nil 39326 . 39371) (nil fontified nil 39310 . 39326) (nil fontified nil 39308 . 39310) (nil fontified nil 39271 . 39308) (nil fontified nil 39255 . 39271) (nil fontified nil 39253 . 39255) (nil fontified nil 39205 . 39253) (nil fontified nil 39189 . 39205) (nil fontified nil 39187 . 39189) (nil fontified nil 39145 . 39187) (nil fontified nil 39129 . 39145) (nil fontified nil 39127 . 39129) (nil fontified nil 39089 . 39127) (nil fontified nil 39073 . 39089) (nil fontified nil 39071 . 39073) (nil fontified nil 39039 . 39071) (nil fontified nil 39023 . 39039) (nil fontified nil 39021 . 39023) (nil fontified nil 38974 . 39021) (nil fontified nil 38958 . 38974) (nil fontified nil 38956 . 38958) (nil fontified nil 38922 . 38956) (nil fontified nil 38906 . 38922) (nil fontified nil 38904 . 38906) (nil fontified nil 38857 . 38904) (nil fontified nil 38841 . 38857) (nil fontified nil 38839 . 38841) (nil fontified nil 38800 . 38839) (nil fontified nil 38784 . 38800) (nil fontified nil 38782 . 38784) (nil fontified nil 38751 . 38782) (nil fontified nil 38735 . 38751) (nil fontified nil 38733 . 38735) (nil fontified nil 38697 . 38733) (nil fontified nil 38681 . 38697) (nil fontified nil 38679 . 38681) (nil fontified nil 38657 . 38679) (nil fontified nil 38641 . 38657) (nil fontified nil 38639 . 38641) (nil fontified nil 38599 . 38639) (nil fontified nil 38583 . 38599) (nil fontified nil 38581 . 38583) (nil fontified nil 38561 . 38581) (nil fontified nil 38545 . 38561) (nil fontified nil 38543 . 38545) (nil fontified nil 38519 . 38543) (nil fontified nil 38503 . 38519) (nil fontified nil 38501 . 38503) (nil fontified nil 38485 . 38501) (nil fontified nil 38469 . 38485) (nil fontified nil 38468 . 38469) (nil fontified nil 38467 . 38468) (nil fontified nil 38464 . 38467) (nil fontified nil 38455 . 38464) (nil fontified nil 38451 . 38455) (nil fontified nil 38447 . 38451) (38447 . 39884) nil ("        conv = [
                \"I've heard you're getting into traveling.\",
                \"I've heard you're planning some exciting trips.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"Rumor has it that you're embarking on new adventures.\",
                \"I've heard you've become quite the globetrotter.\",
                \"Word on the street is you're embracing the wanderlust.\",
                \"I've heard whispers of your travel escapades.\",
                \"I've been informed you're jetting off to new destinations.\",
                \"Seems like you're diving headfirst into the world of travel.\",
                \"I've heard you're immersing yourself in different cultures.\",
                \"I've been told you're discovering the beauty of travel.\",
                \"So, I hear you're filling your passport with stamps.\",
                \"Word has it that you're exploring the unknown.\",
                \"I've heard tales of your travel adventures.\",
                \"I've been informed you're venturing into uncharted territories.\",
                \"Seems like you're on a quest to see the world.\",
                \"I've heard you're collecting memories from around the globe.\",
                \"I've been told you're creating a travel story worth sharing.\",
                \"So, I hear you're embarking on a journey of a lifetime.\"
        ]" . 38447) (t 25704 11991 975388 703000) nil (41947 . 43384) nil ("        questions = [
                \"Where are you?\",
                \"Do you plan to travel?\",
                \"Are you traveling?\",
                \"What was your favorite place to visit?\",
                \"Where are you going?\",
                \"Have you been on any recent trips?\",
                \"Are you exploring new places?\",
                \"What's your dream travel destination?\",
                \"Do you prefer solo travel or with companions?\",
                \"Have you ever traveled for work?\",
                \"What's your most memorable travel experience?\",
                \"Are you an adventure traveler?\",
                \"What's your best travel packing tip?\",
                \"Have you ever experienced culture shock?\",
                \"Do you like to try local food when you travel?\",
                \"What's your favorite way to travel?\",
                \"Have you ever traveled off the beaten path?\",
                \"Do you prefer hotels or alternative accommodations?\",
                \"What's the longest trip you've ever taken?\",
                \"Do you have any upcoming trips?\",
                \"What's the most beautiful place you've seen?\",
                \"Have you ever traveled for a special occasion?\",
                \"Do you keep a travel journal?\",
                \"What's the most challenging part of travel for you?\",
                \"Do you have any tips for saving money on travel?\",
        ]" . 41947) (t 25704 11991 975388 703000) nil (43375 . 43383) 43376 nil (43307 . 43323) ("  " . 43307) 43360 nil (43236 . 43252) ("  " . 43236) 43284 nil (43187 . 43203) ("  " . 43187) 43221 nil (43121 . 43137) ("  " . 43121) 43172 nil (43057 . 43073) ("  " . 43057) 43106 nil (43006 . 43022) ("  " . 43006) 43042 nil (42944 . 42960) ("  " . 42944) 42991 nil (42873 . 42889) ("  " . 42873) 42929 nil (42810 . 42826) ("  " . 42810) 42858 nil (42755 . 42771) ("  " . 42755) 42795 nil (42689 . 42705) ("  " . 42689) 42740 nil (42629 . 42645) ("  " . 42629) 42674 nil (42573 . 42589) ("  " . 42573) 42614 nil (42523 . 42539) ("  " . 42523) 42558 nil (42458 . 42474) ("  " . 42458) 42508 nil (42406 . 42422) ("  " . 42406) 42443 nil (42341 . 42357) ("  " . 42341) 42391 nil (42284 . 42300) ("  " . 42284) 42326 nil (42235 . 42251) ("  " . 42235) 42269 nil (42181 . 42197) ("  " . 42181) 42220 nil (42141 . 42157) ("  " . 42141) 42166 nil (42083 . 42099) ("  " . 42083) 42120 nil (42045 . 42061) ("  " . 42045) 42068 nil (42003 . 42019) ("  " . 42003) 42025 nil (41969 . 41985) ("  " . 41969) 41976 nil (nil rear-nonsticky nil 43025 . 43026) (nil fontified nil 41955 . 43026) (41955 . 43026) nil ("questions = [\"Where are you now?\", \"Do you have any plans to travel?\", \"Are you currently traveling?\", \"What was your favorite place to travel?\", \"Where are you headed?\", \"Have you been on any recent trips?\", \"Are you exploring any new destinations?\", \"What's your dream travel destination?\", \"Do you prefer solo travel or traveling with companions?\", \"Have you ever traveled for work?\", \"What's the most memorable travel experience you've had?\", \"Are you a fan of adventure travel?\", \"What's your go-to travel packing tip?\", \"Have you ever experienced culture shock while traveling?\", \"Do you enjoy trying local cuisines while on a trip?\", \"What's your favorite mode of transportation when traveling?\", \"Have you ever traveled off the beaten path?\", \"Do you prefer staying in hotels or using alternative accommodations?\", \"What's the longest trip you've ever taken?\", \"Do you have any upcoming travel plans?\", \"What's the most beautiful place you've visited?\", \"Have you ever traveled for a special occasion?\", \"Do you keep a travel journal or document your trips in any way?\", \"What's the most challenging aspect of travel for you?\", \"Do you have any tips for saving money while traveling?\"]" . 41955) (t 25704 11936 88639 198000) nil (" " . -43296) 43297 nil ("," . -43296) 43297 nil ("Long time no see" . 43296) (t 25704 11892 445239 69000) nil ("
                \"I've heard you're planning some exciting trips.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"Rumor has it that you're embarking on new adventures.\",
                \"I've heard you've become quite the globetrotter.\",
                \"Word on the street is you're embracing the wanderlust.\",
                \"I've heard whispers of your travel escapades.\",
                \"I've been informed you're jetting off to new destinations.\",
                \"Seems like you're diving headfirst into the world of travel.\",
                \"I've heard you're immersing yourself in different cultures.\",
                \"I've been told you're discovering the beauty of travel.\",
                \"So, I hear you're filling your passport with stamps.\",
                \"Word has it that you're exploring the unknown.\",
                \"I've heard tales of your travel adventures.\",
                \"I've been informed you're venturing into uncharted territories.\",
                \"Seems like you're on a quest to see the world.\",
                \"I've heard you're collecting memories from around the globe.\",
                \"I've been told you're creating a travel story worth sharing.\",
                \"So, I hear you're embarking on a journey of a lifetime.\"
" . 43226) (t 25704 11871 11872 201000) nil ("!" . 44845) nil (41409 . 44757) nil (41408 . 41409) nil ("
        " . 41630) nil ("elif(" . 41639) (41643 . 41644) ("()" . 41643) nil ("prevmess == \"complete\" and get_data(\"previous-post\",message.from)" . 41644) nil (")" . 41708) (41708 . 41709) nil (41708 . 41709) nil (")" . 41708) (41708 . 41709) (" " . 41708) (41708 . 41709) (")" . 41708) (41709 . 41710) (")" . 41709) nil ("z" . 41709) nil (41709 . 41710) nil (41709 . 41710) (")" . 41709) (41708 . 41709) (" " . 41708) (41708 . 41709) (")" . 41708) (41708 . 41709) nil (")" . 41708) nil (")" . 41708) (41708 . 41709) nil (41644 . 41709) nil (41643 . 41645) ("(" . 41643) (41639 . 41644) nil (41630 . 41639) nil ("
" . 41408) nil ("        name_list = generate_names()
        user_name, bot_name = select_names(name_list)
        user_name = get_data(\"name\",message.from_user.id)
        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [\"Where are you now?\", \"Do you have any plans to travel?\", \"Are you currently traveling?\", \"What was your favorite place to travel?\", \"Where are you headed?\", \"Have you been on any recent trips?\", \"Are you exploring any new destinations?\", \"What's your dream travel destination?\", \"Do you prefer solo travel or traveling with companions?\", \"Have you ever traveled for work?\", \"What's the most memorable travel experience you've had?\", \"Are you a fan of adventure travel?\", \"What's your go-to travel packing tip?\", \"Have you ever experienced culture shock while traveling?\", \"Do you enjoy trying local cuisines while on a trip?\", \"What's your favorite mode of transportation when traveling?\", \"Have you ever traveled off the beaten path?\", \"Do you prefer staying in hotels or using alternative accommodations?\", \"What's the longest trip you've ever taken?\", \"Do you have any upcoming travel plans?\", \"What's the most beautiful place you've visited?\", \"Have you ever traveled for a special occasion?\", \"Do you keep a travel journal or document your trips in any way?\", \"What's the most challenging aspect of travel for you?\", \"Do you have any tips for saving money while traveling?\"]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"I've heard you're planning some exciting trips.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"Rumor has it that you're embarking on new adventures.\",
                \"I've heard you've become quite the globetrotter.\",
                \"Word on the street is you're embracing the wanderlust.\",
                \"I've heard whispers of your travel escapades.\",
                \"I've been informed you're jetting off to new destinations.\",
                \"Seems like you're diving headfirst into the world of travel.\",
                \"I've heard you're immersing yourself in different cultures.\",
                \"I've been told you're discovering the beauty of travel.\",
                \"So, I hear you're filling your passport with stamps.\",
                \"Word has it that you're exploring the unknown.\",
                \"I've heard tales of your travel adventures.\",
                \"I've been informed you're venturing into uncharted territories.\",
                \"Seems like you're on a quest to see the world.\",
                \"I've heard you're collecting memories from around the globe.\",
                \"I've been told you're creating a travel story worth sharing.\",
                \"So, I hear you're embarking on a journey of a lifetime.\"
        ]
        usr_start = f\"{random.choice(greeting)} {bot_name}! Long time no see, It's me, {user_name}! {random.choice(conv)} {random.choice(questions)}\"" . 41409) nil (44845 . 44846) nil (44845 . 44850) (44844 . 44846) ("\"" . 44844) (44844 . 44845) nil (41409 . 44971) nil ("
name_list = generate_names()
user_name, bot_name = select_names(name_list)
greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\"]
conv = [
\"I've heard you're getting into traveling.\",
\"So, I hear you're exploring the world now.\",
\"Rumor has it that you're embarking on new adventures.\",
\"I've heard you've become quite the globetrotter.\",
\"Word on the street is you're embracing the wanderlust.\",
\"I've heard whispers of your travel escapades.\",
\"Seems like you're diving headfirst into the world of travel.\",
\"I've heard you're immersing yourself in different cultures.\",
\"I've been told you're discovering the beauty of travel.\",
\"So, I hear you're filling your passport with stamps.\",
\"Word has it that you're exploring the unknown.\",
\"I've heard tales of your travel adventures.\",
\"I've been informed you're venturing into uncharted territories.\",
\"Seems like you're on a quest to see the world.\",
\"I've heard you're collecting memories from around the globe.\",
\"I've been told you're creating a travel story worth sharing.\",
\"So, I hear you're embarking on a journey of a lifetime.\"
]

usr_start = f\"{random.choice(greeting)}, {bot_name}! It's me, {user_name}! {random.choice(conv)}\"
kbd = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True)
kbd.row(\"!Go back\")
await bot.send_message(message.chat.id, text=usr_start, reply_markup=kbd, parse_mode=\"Markdown\")" . 41409) (nil fontified t 42764 . 42765) (nil fontified t 42763 . 42764) (nil fontified t 42753 . 42763) (nil fontified t 42752 . 42753) (nil fontified t 42745 . 42752) (nil fontified t 42744 . 42745) (nil fontified t 42743 . 42744) (nil fontified t 42739 . 42743) (nil fontified t 42723 . 42739) (nil fontified t 42722 . 42723) (nil fontified t 42700 . 42722) (nil fontified t 42686 . 42700) (nil fontified t 42683 . 42686) (nil fontified t 42682 . 42683) (nil fontified t 42681 . 42682) (nil fontified t 42660 . 42681) (nil fontified t 42658 . 42660) (nil fontified t 42647 . 42658) (nil fontified t 42636 . 42647) (nil fontified t 42626 . 42636) (nil fontified t 42624 . 42626) (nil fontified t 42599 . 42624) (nil fontified t 42598 . 42599) (nil fontified t 42594 . 42598) (nil fontified t 42585 . 42594) (nil fontified t 42584 . 42585) (nil fontified t 42583 . 42584) (nil fontified t 42582 . 42583) (nil fontified t 42581 . 42582) (nil fontified t 42524 . 42581) (nil fontified t 42522 . 42524) (nil fontified t 42460 . 42522) (nil fontified t 42458 . 42460) (nil fontified t 42453 . 42458) (nil fontified t 42396 . 42453) (nil fontified t 42395 . 42396) (nil fontified t 42394 . 42395) (nil fontified t 42346 . 42394) (nil fontified t 42344 . 42346) (nil fontified t 42341 . 42344) (nil fontified t 42279 . 42341) (nil fontified t 42278 . 42279) (nil fontified t 42277 . 42278) (nil fontified t 42273 . 42277) (nil fontified t 42265 . 42273) (nil fontified t 42232 . 42265) (nil fontified t 42231 . 42232) (nil fontified t 42230 . 42231) (nil fontified t 42182 . 42230) (nil fontified t 42181 . 42182) (nil fontified t 42180 . 42181) (nil fontified t 42126 . 42180) (nil fontified t 42125 . 42126) (nil fontified t 42124 . 42125) (nil fontified t 42067 . 42124) (nil fontified t 42066 . 42067) (nil fontified t 42065 . 42066) (nil fontified t 42004 . 42065) (nil fontified t 42003 . 42004) (nil fontified t 42002 . 42003) (nil fontified t 41940 . 42002) (nil fontified t 41938 . 41940) (nil fontified t 41891 . 41938) (nil fontified t 41889 . 41891) (nil fontified t 41833 . 41889) (nil fontified t 41832 . 41833) (nil fontified t 41831 . 41832) (nil fontified t 41781 . 41831) (nil fontified t 41779 . 41781) (nil fontified t 41772 . 41779) (nil fontified t 41724 . 41772) (nil fontified t 41722 . 41724) (nil fontified t 41710 . 41722) (nil fontified t 41678 . 41710) (nil fontified t 41676 . 41678) (nil fontified t 41649 . 41676) (nil fontified t 41633 . 41649) (nil fontified t 41632 . 41633) (nil fontified t 41631 . 41632) (nil fontified t 41628 . 41631) (nil fontified t 41624 . 41628) (nil fontified t 41623 . 41624) (nil fontified t 41622 . 41623) (nil fontified t 41615 . 41622) (nil fontified t 41613 . 41615) (nil fontified t 41602 . 41613) (nil fontified t 41600 . 41602) (nil fontified t 41586 . 41600) (nil fontified t 41584 . 41586) (nil fontified t 41568 . 41584) (nil fontified t 41566 . 41568) (nil fontified t 41552 . 41566) (nil fontified t 41550 . 41552) (nil fontified t 41540 . 41550) (nil fontified t 41538 . 41540) (nil fontified t 41532 . 41538) (nil fontified t 41530 . 41532) (nil fontified t 41519 . 41530) (nil fontified t 41517 . 41519) (nil fontified t 41512 . 41517) (nil fontified t 41510 . 41512) (nil fontified t 41503 . 41510) (nil fontified t 41501 . 41503) (nil fontified t 41497 . 41501) (nil fontified t 41496 . 41497) (nil fontified t 41493 . 41496) (nil fontified t 41485 . 41493) (nil fontified t 41484 . 41485) (nil fontified t 41483 . 41484) (nil fontified t 41474 . 41483) (nil fontified t 41473 . 41474) (nil fontified t 41458 . 41473) (nil fontified t 41450 . 41458) (nil fontified t 41448 . 41450) (nil fontified t 41447 . 41448) (nil fontified t 41439 . 41447) (nil fontified t 41438 . 41439) (nil fontified t 41437 . 41438) (nil fontified t 41436 . 41437) (nil fontified t 41419 . 41436) (nil fontified t 41410 . 41419) (nil fontified t 41409 . 41410) (nil rear-nonsticky t 42860 . 42861) nil ("        " . 41410) nil ("        " . 41447) nil ("        " . 41501) nil (41501 . 41509) nil ("        " . 41501) nil ("        " . 41648) nil ("                " . 41665) nil ("                " . 41726) nil ("                " . 41788) nil ("                " . 41861) nil (41869 . 41877) nil ("                " . 41979) nil ("                " . 41921) nil (41861 . 41869) ("                " . 41861) nil ("                " . 42068) nil ("                " . 42148) nil ("                " . 42227) nil ("                " . 42302) nil ("                " . 42374) nil (42382 . 42390) nil (42374 . 42382) nil ("                " . 42374) nil ("                " . 42440) nil ("                " . 42503) nil ("                " . 42586) nil (42594 . 42602) nil (42448 . 42456) nil (42503 . 42511) nil (42440 . 42448) ("                " . 42440) nil (42448 . 42456) nil (42440 . 42448) nil (42487 . 42495) ("                " . 42487) nil (42495 . 42503) nil (42487 . 42495) nil ("                " . 42487) nil ("                " . 42440) nil ("                " . 42644) nil ("                " . 42724) nil (42586 . 42594) ("                " . 42586) nil ("                " . 42812) nil ("        " . 42886) nil ("        " . 42897) nil ("        " . 43003) nil ("        " . 43073) nil ("        " . 43101) (t 25704 11818 721788 206000) nil (43101 . 43109) 43128 nil (43073 . 43081) 43092 nil (43003 . 43011) 43020 nil (42897 . 42905) 42906 nil (42886 . 42894) 42887 nil (42812 . 42828) 42869 nil (42586 . 42602) ("        " . 42586) 42643 nil (42724 . 42740) 42787 nil (42644 . 42660) 42701 nil (42440 . 42456) 42481 nil (42487 . 42503) 42512 nil ("        " . -42487) 42520 nil ("        " . -42495) 42528 nil (42487 . 42503) ("        " . 42487) 42520 nil ("        " . -42440) 42481 nil ("        " . -42448) 42489 nil (42440 . 42456) ("        " . 42440) 42481 nil ("        " . -42503) 42544 nil ("        " . -42448) 42497 nil ("        " . -42594) 42651 nil (42586 . 42602) 42635 nil (42503 . 42519) 42565 nil (42440 . 42456) 42486 nil (42374 . 42390) 42423 nil ("        " . -42374) 42431 nil ("        " . -42382) 42439 nil (42374 . 42390) 42423 nil (42302 . 42318) 42357 nil (42227 . 42243) 42285 nil (42148 . 42164) 42210 nil (42068 . 42084) 42131 nil (41861 . 41877) ("        " . 41861) 41920 nil (41921 . 41937) 41978 nil (41979 . 41995) 42027 nil ("        " . -41869) 41928 nil (41861 . 41877) 41912 nil (41788 . 41804) 41836 nil (41726 . 41742) 41758 nil (41665 . 41681) 41681 nil (41648 . 41656) 41656 nil (41501 . 41509) 41509 nil ("        " . -41501) 41525 nil (41501 . 41509) 41517 nil (41447 . 41455) 41455 nil (41410 . 41418) nil (nil rear-nonsticky nil 42860 . 42861) (nil fontified nil 41409 . 42861) (41409 . 42861) nil ("        name_list = generate_names()
        user_name, bot_name = select_names(name_list)
        user_name = get_data(\"name\",message.from_user.id)
        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [\"Where are you now?\", \"Do you have any plans to travel?\", \"Are you currently traveling?\", \"What was your favorite place to travel?\", \"Where are you headed?\", \"Have you been on any recent trips?\", \"Are you exploring any new destinations?\", \"What's your dream travel destination?\", \"Do you prefer solo travel or traveling with companions?\", \"Have you ever traveled for work?\", \"What's the most memorable travel experience you've had?\", \"Are you a fan of adventure travel?\", \"What's your go-to travel packing tip?\", \"Have you ever experienced culture shock while traveling?\", \"Do you enjoy trying local cuisines while on a trip?\", \"What's your favorite mode of transportation when traveling?\", \"Have you ever traveled off the beaten path?\", \"Do you prefer staying in hotels or using alternative accommodations?\", \"What's the longest trip you've ever taken?\", \"Do you have any upcoming travel plans?\", \"What's the most beautiful place you've visited?\", \"Have you ever traveled for a special occasion?\", \"Do you keep a travel journal or document your trips in any way?\", \"What's the most challenging aspect of travel for you?\", \"Do you have any tips for saving money while traveling?\"]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"I've heard you're planning some exciting trips.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"Rumor has it that you're embarking on new adventures.\",
                \"I've heard you've become quite the globetrotter.\",
                \"Word on the street is you're embracing the wanderlust.\",
                \"I've heard whispers of your travel escapades.\",
                \"I've been informed you're jetting off to new destinations.\",
                \"Seems like you're diving headfirst into the world of travel.\",
                \"I've heard you're immersing yourself in different cultures.\",
                \"I've been told you're discovering the beauty of travel.\",
                \"So, I hear you're filling your passport with stamps.\",
                \"Word has it that you're exploring the unknown.\",
                \"I've heard tales of your travel adventures.\",
                \"I've been informed you're venturing into uncharted territories.\",
                \"Seems like you're on a quest to see the world.\",
                \"I've heard you're collecting memories from around the globe.\",
                \"I've been told you're creating a travel story worth sharing.\",
                \"So, I hear you're embarking on a journey of a lifetime.\"
        ]
        usr_start = f\"{random.choice(greeting)} {bot_name}! Long time no see, It's me, {user_name}! {random.choice(conv)} {random.choice(questions)}\"
        kbd = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True)
        kbd.row()
        kbd.row(\"!Go back\")
        await bot.send_message(message.chat.id, text=send,reply_markup=kbd,parse_mode=\"Markdown\")" . 41409) (t 25704 11560 254649 442000) nil ("\"" . 44844) (44844 . 44845) ("\"\"" . 44844) ("Greet" . 44845) nil ("!" . 44845) nil (41409 . 44757) nil (41408 . 41409) nil ("
        " . 41630) nil ("elif(" . 41639) (41643 . 41644) ("()" . 41643) nil ("prevmess == \"complete\" and get_data(\"previous-post\",message.from)" . 41644) nil (")" . 41708) (41708 . 41709) nil (41708 . 41709) nil (")" . 41708) (41708 . 41709) (" " . 41708) (41708 . 41709) (")" . 41708) (41709 . 41710) (")" . 41709) nil ("_u" . 41708) nil (41704 . 41710) ("from_user.id) == \"Chat���\" and message.text == \"!Greet\"):" . 41704) (41761 . 41763) nil ("
                " . 41761) nil ("        name_list = generate_names()
        user_name, bot_name = select_names(name_list)
        user_name = get_data(\"name\",message.from_user.id)
        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [\"Where are you now?\", \"Do you have any plans to travel?\", \"Are you currently traveling?\", \"What was your favorite place to travel?\", \"Where are you headed?\", \"Have you been on any recent trips?\", \"Are you exploring any new destinations?\", \"What's your dream travel destination?\", \"Do you prefer solo travel or traveling with companions?\", \"Have you ever traveled for work?\", \"What's the most memorable travel experience you've had?\", \"Are you a fan of adventure travel?\", \"What's your go-to travel packing tip?\", \"Have you ever experienced culture shock while traveling?\", \"Do you enjoy trying local cuisines while on a trip?\", \"What's your favorite mode of transportation when traveling?\", \"Have you ever traveled off the beaten path?\", \"Do you prefer staying in hotels or using alternative accommodations?\", \"What's the longest trip you've ever taken?\", \"Do you have any upcoming travel plans?\", \"What's the most beautiful place you've visited?\", \"Have you ever traveled for a special occasion?\", \"Do you keep a travel journal or document your trips in any way?\", \"What's the most challenging aspect of travel for you?\", \"Do you have any tips for saving money while traveling?\"]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"I've heard you're planning some exciting trips.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"Rumor has it that you're embarking on new adventures.\",
                \"I've heard you've become quite the globetrotter.\",
                \"Word on the street is you're embracing the wanderlust.\",
                \"I've heard whispers of your travel escapades.\",
                \"I've been informed you're jetting off to new destinations.\",
                \"Seems like you're diving headfirst into the world of travel.\",
                \"I've heard you're immersing yourself in different cultures.\",
                \"I've been told you're discovering the beauty of travel.\",
                \"So, I hear you're filling your passport with stamps.\",
                \"Word has it that you're exploring the unknown.\",
                \"I've heard tales of your travel adventures.\",
                \"I've been informed you're venturing into uncharted territories.\",
                \"Seems like you're on a quest to see the world.\",
                \"I've heard you're collecting memories from around the globe.\",
                \"I've been told you're creating a travel story worth sharing.\",
                \"So, I hear you're embarking on a journey of a lifetime.\"
        ]
        usr_start = f\"{random.choice(greeting)} {bot_name}! Long time no see, It's me, {user_name}! {random.choice(conv)} {random.choice(questions)}\"" . 41778) (nil fontified t 41814 . 41815) (nil fontified t 41868 . 41869) (nil fontified t 41926 . 41927) (nil fontified t 42315 . 42316) (nil fontified t 43517 . 43518) (nil fontified t 43534 . 43535) (nil fontified t 43594 . 43596) (nil fontified t 43661 . 43663) (nil fontified t 43723 . 43725) (nil fontified t 43789 . 43791) (nil fontified t 43862 . 43864) (nil fontified t 43930 . 43932) (nil fontified t 44004 . 44006) (nil fontified t 44069 . 44071) (nil fontified t 44147 . 44149) (nil fontified t 44227 . 44229) (nil fontified t 44306 . 44308) (nil fontified t 44381 . 44383) (nil fontified t 44453 . 44455) (nil fontified t 44519 . 44521) (nil fontified t 44582 . 44584) (nil fontified t 44665 . 44667) (nil fontified t 44731 . 44733) (nil fontified t 44811 . 44813) (nil fontified t 44891 . 44893) (nil fontified t 44966 . 44967) (nil fontified t 44976 . 44977) (nil fontified t 45125 . 45126) nil (41635 . 41639) nil (41770 . 41782) nil (41766 . 41770) (t 25704 11515 461222 164000) nil ("    " . -41766) 41773 nil ("            " . -41770) 41785 nil ("    " . -41635) 41662 nil (nil fontified nil 45125 . 45126) (nil fontified nil 45124 . 45125) (nil fontified nil 45123 . 45124) (nil fontified nil 45114 . 45123) (nil fontified nil 45113 . 45114) (nil fontified nil 45100 . 45113) (nil fontified nil 45099 . 45100) (nil fontified nil 45098 . 45099) (nil fontified nil 45078 . 45098) (nil fontified nil 45077 . 45078) (nil fontified nil 45076 . 45077) (nil fontified nil 45075 . 45076) (nil fontified nil 45064 . 45075) (nil fontified nil 45036 . 45064) (nil fontified nil 45035 . 45036) (nil fontified nil 45026 . 45035) (nil fontified nil 45025 . 45026) (nil fontified nil 45024 . 45025) (nil fontified nil 45018 . 45024) (nil fontified nil 45013 . 45018) (nil fontified nil 45000 . 45013) (nil fontified nil 44999 . 45000) (nil fontified nil 44998 . 44999) (nil fontified nil 44994 . 44998) (nil fontified nil 44989 . 44994) (nil fontified nil 44985 . 44989) (nil fontified nil 44977 . 44985) (nil fontified nil 44976 . 44977) (nil fontified nil 44975 . 44976) (nil fontified nil 44967 . 44975) (nil fontified nil 44966 . 44967) (nil fontified nil 44909 . 44966) (nil fontified nil 44893 . 44909) (nil fontified nil 44891 . 44893) (nil fontified nil 44829 . 44891) (nil fontified nil 44813 . 44829) (nil fontified nil 44811 . 44813) (nil fontified nil 44749 . 44811) (nil fontified nil 44733 . 44749) (nil fontified nil 44731 . 44733) (nil fontified nil 44683 . 44731) (nil fontified nil 44667 . 44683) (nil fontified nil 44665 . 44667) (nil fontified nil 44600 . 44665) (nil fontified nil 44584 . 44600) (nil fontified nil 44582 . 44584) (nil fontified nil 44537 . 44582) (nil fontified nil 44521 . 44537) (nil fontified nil 44519 . 44521) (nil fontified nil 44471 . 44519) (nil fontified nil 44455 . 44471) (nil fontified nil 44453 . 44455) (nil fontified nil 44399 . 44453) (nil fontified nil 44383 . 44399) (nil fontified nil 44381 . 44383) (nil fontified nil 44324 . 44381) (nil fontified nil 44308 . 44324) (nil fontified nil 44306 . 44308) (nil fontified nil 44245 . 44306) (nil fontified nil 44229 . 44245) (nil fontified nil 44227 . 44229) (nil fontified nil 44165 . 44227) (nil fontified nil 44149 . 44165) (nil fontified nil 44147 . 44149) (nil fontified nil 44087 . 44147) (nil fontified nil 44071 . 44087) (nil fontified nil 44069 . 44071) (nil fontified nil 44022 . 44069) (nil fontified nil 44006 . 44022) (nil fontified nil 44004 . 44006) (nil fontified nil 43948 . 44004) (nil fontified nil 43932 . 43948) (nil fontified nil 43930 . 43932) (nil fontified nil 43880 . 43930) (nil fontified nil 43864 . 43880) (nil fontified nil 43862 . 43864) (nil fontified nil 43807 . 43862) (nil fontified nil 43791 . 43807) (nil fontified nil 43789 . 43791) (nil fontified nil 43741 . 43789) (nil fontified nil 43725 . 43741) (nil fontified nil 43723 . 43725) (nil fontified nil 43679 . 43723) (nil fontified nil 43663 . 43679) (nil fontified nil 43661 . 43663) (nil fontified nil 43612 . 43661) (nil fontified nil 43596 . 43612) (nil fontified nil 43594 . 43596) (nil fontified nil 43551 . 43594) (nil fontified nil 43535 . 43551) (nil fontified nil 43534 . 43535) (nil fontified nil 43533 . 43534) (nil fontified nil 43530 . 43533) (nil fontified nil 43526 . 43530) (nil fontified nil 43518 . 43526) (nil fontified nil 43517 . 43518) (nil fontified nil 43516 . 43517) (nil fontified nil 43460 . 43516) (nil fontified nil 43458 . 43460) (nil fontified nil 43427 . 43458) (nil fontified nil 43403 . 43427) (nil fontified nil 43401 . 43403) (nil fontified nil 43336 . 43401) (nil fontified nil 43334 . 43336) (nil fontified nil 43286 . 43334) (nil fontified nil 43284 . 43286) (nil fontified nil 43235 . 43284) (nil fontified nil 43233 . 43235) (nil fontified nil 43193 . 43233) (nil fontified nil 43191 . 43193) (nil fontified nil 43147 . 43191) (nil fontified nil 43145 . 43147) (nil fontified nil 43075 . 43145) (nil fontified nil 43073 . 43075) (nil fontified nil 43028 . 43073) (nil fontified nil 43026 . 43028) (nil fontified nil 42965 . 43026) (nil fontified nil 42963 . 42965) (nil fontified nil 42910 . 42963) (nil fontified nil 42908 . 42910) (nil fontified nil 42850 . 42908) (nil fontified nil 42848 . 42850) (nil fontified nil 42809 . 42848) (nil fontified nil 42807 . 42809) (nil fontified nil 42771 . 42807) (nil fontified nil 42769 . 42771) (nil fontified nil 42712 . 42769) (nil fontified nil 42710 . 42712) (nil fontified nil 42676 . 42710) (nil fontified nil 42674 . 42676) (nil fontified nil 42617 . 42674) (nil fontified nil 42615 . 42617) (nil fontified nil 42576 . 42615) (nil fontified nil 42574 . 42576) (nil fontified nil 42533 . 42574) (nil fontified nil 42531 . 42533) (nil fontified nil 42495 . 42531) (nil fontified nil 42493 . 42495) (nil fontified nil 42470 . 42493) (nil fontified nil 42468 . 42470) (nil fontified nil 42427 . 42468) (nil fontified nil 42425 . 42427) (nil fontified nil 42395 . 42425) (nil fontified nil 42393 . 42395) (nil fontified nil 42359 . 42393) (nil fontified nil 42357 . 42359) (nil fontified nil 42355 . 42357) (nil fontified nil 42337 . 42355) (nil fontified nil 42336 . 42337) (nil fontified nil 42333 . 42336) (nil fontified nil 42324 . 42333) (nil fontified nil 42320 . 42324) (nil fontified nil 42316 . 42320) (nil fontified nil 42315 . 42316) (nil fontified nil 42314 . 42315) (nil fontified nil 42285 . 42314) (nil fontified nil 42283 . 42285) (nil fontified nil 42260 . 42283) (nil fontified nil 42258 . 42260) (nil fontified nil 42240 . 42258) (nil fontified nil 42238 . 42240) (nil fontified nil 42216 . 42238) (nil fontified nil 42214 . 42216) (nil fontified nil 42198 . 42214) (nil fontified nil 42196 . 42198) (nil fontified nil 42178 . 42196) (nil fontified nil 42176 . 42178) (nil fontified nil 42152 . 42176) (nil fontified nil 42150 . 42152) (nil fontified nil 42129 . 42150) (nil fontified nil 42127 . 42129) (nil fontified nil 42114 . 42127) (nil fontified nil 42112 . 42114) (nil fontified nil 42102 . 42112) (nil fontified nil 42100 . 42102) (nil fontified nil 42093 . 42100) (nil fontified nil 42091 . 42093) (nil fontified nil 42080 . 42091) (nil fontified nil 42078 . 42080) (nil fontified nil 42064 . 42078) (nil fontified nil 42062 . 42064) (nil fontified nil 42046 . 42062) (nil fontified nil 42044 . 42046) (nil fontified nil 42030 . 42044) (nil fontified nil 42028 . 42030) (nil fontified nil 42018 . 42028) (nil fontified nil 42016 . 42018) (nil fontified nil 42003 . 42016) (nil fontified nil 42001 . 42003) (nil fontified nil 41990 . 42001) (nil fontified nil 41988 . 41990) (nil fontified nil 41982 . 41988) (nil fontified nil 41980 . 41982) (nil fontified nil 41969 . 41980) (nil fontified nil 41967 . 41969) (nil fontified nil 41962 . 41967) (nil fontified nil 41960 . 41962) (nil fontified nil 41953 . 41960) (nil fontified nil 41951 . 41953) (nil fontified nil 41947 . 41951) (nil fontified nil 41946 . 41947) (nil fontified nil 41943 . 41946) (nil fontified nil 41935 . 41943) (nil fontified nil 41927 . 41935) (nil fontified nil 41926 . 41927) (nil fontified nil 41925 . 41926) (nil fontified nil 41923 . 41925) (nil fontified nil 41904 . 41923) (nil fontified nil 41903 . 41904) (nil fontified nil 41898 . 41903) (nil fontified nil 41897 . 41898) (nil fontified nil 41886 . 41897) (nil fontified nil 41877 . 41886) (nil fontified nil 41869 . 41877) (nil fontified nil 41868 . 41869) (nil fontified nil 41867 . 41868) (nil fontified nil 41858 . 41867) (nil fontified nil 41857 . 41858) (nil fontified nil 41842 . 41857) (nil fontified nil 41834 . 41842) (nil fontified nil 41832 . 41834) (nil fontified nil 41823 . 41832) (nil fontified nil 41815 . 41823) (nil fontified nil 41814 . 41815) (nil fontified nil 41813 . 41814) (nil fontified nil 41812 . 41813) (nil fontified nil 41795 . 41812) (nil fontified nil 41786 . 41795) (nil fontified nil 41778 . 41786) (41778 . 45126) nil (41761 . 41778) nil ("))" . 41761) (41704 . 41761) ("from_u" . -41704) 41710 nil (41708 . 41710) nil (41709 . 41710) (")" . 41709) (41708 . 41709) (" " . -41708) (41708 . 41709) (")" . -41708) (41708 . 41709) nil (")" . -41708) 41709 nil (")" . -41708) (41708 . 41709) nil (41644 . 41709) nil (41643 . 41645) ("(" . -41643) (41639 . 41644) nil (41630 . 41639) (t 25704 11489 214498 403000) nil ("
" . -41408) 41409 nil ("        name_list = generate_names()
        user_name, bot_name = select_names(name_list)
        user_name = get_data(\"name\",message.from_user.id)
        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [\"Where are you now?\", \"Do you have any plans to travel?\", \"Are you currently traveling?\", \"What was your favorite place to travel?\", \"Where are you headed?\", \"Have you been on any recent trips?\", \"Are you exploring any new destinations?\", \"What's your dream travel destination?\", \"Do you prefer solo travel or traveling with companions?\", \"Have you ever traveled for work?\", \"What's the most memorable travel experience you've had?\", \"Are you a fan of adventure travel?\", \"What's your go-to travel packing tip?\", \"Have you ever experienced culture shock while traveling?\", \"Do you enjoy trying local cuisines while on a trip?\", \"What's your favorite mode of transportation when traveling?\", \"Have you ever traveled off the beaten path?\", \"Do you prefer staying in hotels or using alternative accommodations?\", \"What's the longest trip you've ever taken?\", \"Do you have any upcoming travel plans?\", \"What's the most beautiful place you've visited?\", \"Have you ever traveled for a special occasion?\", \"Do you keep a travel journal or document your trips in any way?\", \"What's the most challenging aspect of travel for you?\", \"Do you have any tips for saving money while traveling?\"]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"I've heard you're planning some exciting trips.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"Rumor has it that you're embarking on new adventures.\",
                \"I've heard you've become quite the globetrotter.\",
                \"Word on the street is you're embracing the wanderlust.\",
                \"I've heard whispers of your travel escapades.\",
                \"I've been informed you're jetting off to new destinations.\",
                \"Seems like you're diving headfirst into the world of travel.\",
                \"I've heard you're immersing yourself in different cultures.\",
                \"I've been told you're discovering the beauty of travel.\",
                \"So, I hear you're filling your passport with stamps.\",
                \"Word has it that you're exploring the unknown.\",
                \"I've heard tales of your travel adventures.\",
                \"I've been informed you're venturing into uncharted territories.\",
                \"Seems like you're on a quest to see the world.\",
                \"I've heard you're collecting memories from around the globe.\",
                \"I've been told you're creating a travel story worth sharing.\",
                \"So, I hear you're embarking on a journey of a lifetime.\"
        ]
        usr_start = f\"{random.choice(greeting)} {bot_name}! Long time no see, It's me, {user_name}! {random.choice(conv)} {random.choice(questions)}\"" . 41409) 44757 (t 25704 11456 721092 146000) nil (44845 . 44846) nil (44845 . 44850) (44844 . 44846) ("\"" . -44844) (44844 . 44845) nil ("!" . -44844) ("G" . -44845) 44846 nil (44844 . 44846) nil ("usr_start" . 44844) (t 25704 11407 637643 610000) nil (nil rear-nonsticky nil 44825 . 44826) (nil fontified nil 44822 . 44826) (nil fontified nil 44806 . 44822) (44806 . 44826) (t 25704 11282 103983 958000) nil (45728 . 45748) nil ("resize_keyboard=True" . 45728) 45748 (t 25704 11282 103983 958000) nil (nil fontified nil 40054 . 40055) (nil fontified nil 40053 . 40054) (nil fontified nil 40052 . 40053) (nil fontified nil 40043 . 40052) (nil fontified nil 40042 . 40043) (nil fontified nil 40029 . 40042) (nil fontified nil 40028 . 40029) (nil fontified nil 40027 . 40028) (nil fontified nil 40007 . 40027) (nil fontified nil 40006 . 40007) (nil fontified nil 40005 . 40006) (nil fontified nil 40004 . 40005) (nil fontified nil 39993 . 40004) (nil fontified nil 39965 . 39993) (nil fontified nil 39964 . 39965) (nil fontified nil 39955 . 39964) (nil fontified nil 39954 . 39955) (nil fontified nil 39953 . 39954) (nil fontified nil 39942 . 39953) (nil fontified nil 39929 . 39942) (nil fontified nil 39928 . 39929) (nil fontified nil 39927 . 39928) (nil fontified nil 39923 . 39927) (nil fontified nil 39918 . 39923) (nil fontified nil 39914 . 39918) (nil fontified nil 39906 . 39914) (nil fontified nil 39905 . 39906) (nil fontified nil 39904 . 39905) (nil fontified nil 39896 . 39904) (nil fontified nil 39895 . 39896) (nil fontified nil 39838 . 39895) (nil fontified nil 39822 . 39838) (nil fontified nil 39820 . 39822) (nil fontified nil 39758 . 39820) (nil fontified nil 39742 . 39758) (nil fontified nil 39740 . 39742) (nil fontified nil 39678 . 39740) (nil fontified nil 39662 . 39678) (nil fontified nil 39660 . 39662) (nil fontified nil 39612 . 39660) (nil fontified nil 39596 . 39612) (nil fontified nil 39594 . 39596) (nil fontified nil 39529 . 39594) (nil fontified nil 39513 . 39529) (nil fontified nil 39511 . 39513) (nil fontified nil 39466 . 39511) (nil fontified nil 39450 . 39466) (nil fontified nil 39448 . 39450) (nil fontified nil 39400 . 39448) (nil fontified nil 39384 . 39400) (nil fontified nil 39382 . 39384) (nil fontified nil 39328 . 39382) (nil fontified nil 39312 . 39328) (nil fontified nil 39310 . 39312) (nil fontified nil 39253 . 39310) (nil fontified nil 39237 . 39253) (nil fontified nil 39235 . 39237) (nil fontified nil 39174 . 39235) (nil fontified nil 39158 . 39174) (nil fontified nil 39156 . 39158) (nil fontified nil 39094 . 39156) (nil fontified nil 39078 . 39094) (nil fontified nil 39076 . 39078) (nil fontified nil 39016 . 39076) (nil fontified nil 39000 . 39016) (nil fontified nil 38998 . 39000) (nil fontified nil 38951 . 38998) (nil fontified nil 38935 . 38951) (nil fontified nil 38933 . 38935) (nil fontified nil 38877 . 38933) (nil fontified nil 38861 . 38877) (nil fontified nil 38859 . 38861) (nil fontified nil 38809 . 38859) (nil fontified nil 38793 . 38809) (nil fontified nil 38791 . 38793) (nil fontified nil 38736 . 38791) (nil fontified nil 38720 . 38736) (nil fontified nil 38718 . 38720) (nil fontified nil 38670 . 38718) (nil fontified nil 38654 . 38670) (nil fontified nil 38652 . 38654) (nil fontified nil 38608 . 38652) (nil fontified nil 38592 . 38608) (nil fontified nil 38590 . 38592) (nil fontified nil 38541 . 38590) (nil fontified nil 38525 . 38541) (nil fontified nil 38523 . 38525) (nil fontified nil 38480 . 38523) (nil fontified nil 38464 . 38480) (nil fontified nil 38463 . 38464) (nil fontified nil 38462 . 38463) (nil fontified nil 38459 . 38462) (nil fontified nil 38455 . 38459) (nil fontified nil 38447 . 38455) (nil fontified nil 38446 . 38447) (nil fontified nil 38445 . 38446) (nil fontified nil 38389 . 38445) (nil fontified nil 38387 . 38389) (nil fontified nil 38332 . 38387) (nil fontified nil 38330 . 38332) (nil fontified nil 38265 . 38330) (nil fontified nil 38263 . 38265) (nil fontified nil 38215 . 38263) (nil fontified nil 38213 . 38215) (nil fontified nil 38164 . 38213) (nil fontified nil 38162 . 38164) (nil fontified nil 38122 . 38162) (nil fontified nil 38120 . 38122) (nil fontified nil 38076 . 38120) (nil fontified nil 38074 . 38076) (nil fontified nil 38004 . 38074) (nil fontified nil 38002 . 38004) (nil fontified nil 37957 . 38002) (nil fontified nil 37955 . 37957) (nil fontified nil 37894 . 37955) (nil fontified nil 37892 . 37894) (nil fontified nil 37839 . 37892) (nil fontified nil 37837 . 37839) (nil fontified nil 37779 . 37837) (nil fontified nil 37777 . 37779) (nil fontified nil 37738 . 37777) (nil fontified nil 37736 . 37738) (nil fontified nil 37700 . 37736) (nil fontified nil 37698 . 37700) (nil fontified nil 37641 . 37698) (nil fontified nil 37639 . 37641) (nil fontified nil 37605 . 37639) (nil fontified nil 37603 . 37605) (nil fontified nil 37546 . 37603) (nil fontified nil 37544 . 37546) (nil fontified nil 37505 . 37544) (nil fontified nil 37503 . 37505) (nil fontified nil 37462 . 37503) (nil fontified nil 37460 . 37462) (nil fontified nil 37424 . 37460) (nil fontified nil 37422 . 37424) (nil fontified nil 37399 . 37422) (nil fontified nil 37397 . 37399) (nil fontified nil 37356 . 37397) (nil fontified nil 37354 . 37356) (nil fontified nil 37324 . 37354) (nil fontified nil 37322 . 37324) (nil fontified nil 37288 . 37322) (nil fontified nil 37286 . 37288) (nil fontified nil 37284 . 37286) (nil fontified nil 37266 . 37284) (nil fontified nil 37265 . 37266) (nil fontified nil 37262 . 37265) (nil fontified nil 37253 . 37262) (nil fontified nil 37249 . 37253) (nil fontified nil 37245 . 37249) (nil fontified nil 37244 . 37245) (nil fontified nil 37243 . 37244) (nil fontified nil 37214 . 37243) (nil fontified nil 37212 . 37214) (nil fontified nil 37189 . 37212) (nil fontified nil 37187 . 37189) (nil fontified nil 37169 . 37187) (nil fontified nil 37167 . 37169) (nil fontified nil 37145 . 37167) (nil fontified nil 37143 . 37145) (nil fontified nil 37127 . 37143) (nil fontified nil 37125 . 37127) (nil fontified nil 37107 . 37125) (nil fontified nil 37105 . 37107) (nil fontified nil 37081 . 37105) (nil fontified nil 37079 . 37081) (nil fontified nil 37058 . 37079) (nil fontified nil 37056 . 37058) (nil fontified nil 37043 . 37056) (nil fontified nil 37041 . 37043) (nil fontified nil 37031 . 37041) (nil fontified nil 37029 . 37031) (nil fontified nil 37022 . 37029) (nil fontified nil 37020 . 37022) (nil fontified nil 37009 . 37020) (nil fontified nil 37007 . 37009) (nil fontified nil 36993 . 37007) (nil fontified nil 36991 . 36993) (nil fontified nil 36975 . 36991) (nil fontified nil 36973 . 36975) (nil fontified nil 36959 . 36973) (nil fontified nil 36957 . 36959) (nil fontified nil 36947 . 36957) (nil fontified nil 36945 . 36947) (nil fontified nil 36932 . 36945) (nil fontified nil 36930 . 36932) (nil fontified nil 36919 . 36930) (nil fontified nil 36917 . 36919) (nil fontified nil 36911 . 36917) (nil fontified nil 36909 . 36911) (nil fontified nil 36898 . 36909) (nil fontified nil 36896 . 36898) (nil fontified nil 36891 . 36896) (nil fontified nil 36889 . 36891) (nil fontified nil 36882 . 36889) (nil fontified nil 36880 . 36882) (nil fontified nil 36876 . 36880) (nil fontified nil 36875 . 36876) (nil fontified nil 36872 . 36875) (nil fontified nil 36864 . 36872) (nil fontified nil 36856 . 36864) (36856 . 40055) nil ("        greeting = [\"Hi\", \"Hello\", \"Hey\", \"How are you\", \"How are you doing\", \"Heya\", \"What's up\"]
        questions = [\"Where are you now?\", \"Do you have any plans to travel?\", \"Are you currently traveling?\", \"What was your favorite place to travel?\"]
        usr_start = f\"{random.choice(greeting)} {bot_name}! Long time no see, It's me, {user_name}! I’ve heard you’re getting into travelling. {random.choice(questions)}\"" . 36856) (t 25704 11233 693844 44000) nil (38782 . 41981) nil ("        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [\"Where are you now?\", \"Do you have any plans to travel?\", \"Are you currently traveling?\", \"What was your favorite place to travel?\", \"Where are you headed?\", \"Have you been on any recent trips?\", \"Are you exploring any new destinations?\", \"What's your dream travel destination?\", \"Do you prefer solo travel or traveling with companions?\", \"Have you ever traveled for work?\", \"What's the most memorable travel experience you've had?\", \"Are you a fan of adventure travel?\", \"What's your go-to travel packing tip?\", \"Have you ever experienced culture shock while traveling?\", \"Do you enjoy trying local cuisines while on a trip?\", \"What's your favorite mode of transportation when traveling?\", \"Have you ever traveled off the beaten path?\", \"Do you prefer staying in hotels or using alternative accommodations?\", \"What's the longest trip you've ever taken?\", \"Do you have any upcoming travel plans?\", \"What's the most beautiful place you've visited?\", \"Have you ever traveled for a special occasion?\", \"Do you keep a travel journal or document your trips in any way?\", \"What's the most challenging aspect of travel for you?\", \"Do you have any tips for saving money while traveling?\"]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"I've heard you're planning some exciting trips.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"Rumor has it that you're embarking on new adventures.\",
                \"I've heard you've become quite the globetrotter.\",
                \"Word on the street is you're embracing the wanderlust.\",
                \"I've heard whispers of your travel escapades.\",
                \"I've been informed you're jetting off to new destinations.\",
                \"Seems like you're diving headfirst into the world of travel.\",
                \"I've heard you're immersing yourself in different cultures.\",
                \"I've been told you're discovering the beauty of travel.\",
                \"So, I hear you're filling your passport with stamps.\",
                \"Word has it that you're exploring the unknown.\",
                \"I've heard tales of your travel adventures.\",
                \"I've been informed you're venturing into uncharted territories.\",
                \"Seems like you're on a quest to see the world.\",
                \"I've heard you're collecting memories from around the globe.\",
                \"I've been told you're creating a travel story worth sharing.\",
                \"So, I hear you're embarking on a journey of a lifetime.\"
        ]
        usr_start = f\"{random.choice(greeting)} {bot_name}! Long time no see, It's me, {user_name}! {random.choice(conv)} {random.choice(questions)}\"" . 38782) (t 25704 11233 693844 44000)) (emacs-pending-undo-list ("
        quiz = 1 if(int(get_data(\"question\",message.from_user.id)) <= 10) else 0
        quest = question_array[0+quiz*10]" . 23937) ((marker . 23778) . -123) ((marker) . -123) (t 25707 27841 321952 604000) nil ("    " . -23353) ((marker . 23787) . -4) ((marker . 23778) . -4) ((marker . 23353) . -4) ((marker . 23353) . -4) 23357 nil ("        " . -23357) 23353 (t 25707 27838 218654 98000) nil (23824 . 23833) nil (nil rear-nonsticky nil 23823 . 23824) (nil fontified nil 23823 . 23824) (nil fontified nil 23813 . 23823) (nil fontified nil 23801 . 23813) (nil fontified nil 23800 . 23801) (nil fontified nil 23795 . 23800) (nil fontified nil 23794 . 23795) (nil fontified nil 23748 . 23794) (nil fontified nil 23746 . 23748) (nil fontified nil 23733 . 23746) (nil fontified nil 23732 . 23733) (nil fontified nil 23715 . 23732) (nil fontified nil 23710 . 23715) (nil fontified nil 23701 . 23710) (nil fontified nil 23700 . 23701) (nil fontified nil 23699 . 23700) (nil fontified nil 23694 . 23699) (nil fontified nil 23693 . 23694) (nil fontified nil 23672 . 23693) (nil fontified nil 23670 . 23672) (nil fontified nil 23651 . 23670) (nil fontified nil 23641 . 23651) (nil fontified nil 23640 . 23641) (nil fontified nil 23623 . 23640) (nil fontified nil 23622 . 23623) (nil fontified nil 23605 . 23622) (nil fontified nil 23603 . 23605) (nil fontified nil 23584 . 23603) (nil fontified nil 23575 . 23584) (nil fontified nil 23574 . 23575) (nil fontified nil 23557 . 23574) (nil fontified nil 23556 . 23557) (nil fontified nil 23554 . 23556) (nil fontified nil 23552 . 23554) (nil fontified nil 23533 . 23552) (nil fontified nil 23522 . 23533) (nil fontified nil 23521 . 23522) (nil fontified nil 23504 . 23521) (nil fontified nil 23503 . 23504) (nil fontified nil 23501 . 23503) (nil fontified nil 23499 . 23501) (nil fontified nil 23480 . 23499) (nil fontified nil 23471 . 23480) (nil fontified nil 23470 . 23471) (nil fontified nil 23453 . 23470) (nil fontified nil 23452 . 23453) (nil fontified nil 23451 . 23452) (nil fontified nil 23450 . 23451) (nil fontified nil 23433 . 23450) (nil fontified nil 23428 . 23433) (nil fontified nil 23420 . 23428) (nil fontified nil 23419 . 23420) (nil fontified nil 23418 . 23419) (nil fontified nil 23405 . 23418) (nil fontified nil 23403 . 23405) (nil fontified nil 23384 . 23403) (nil fontified nil 23374 . 23384) (nil fontified nil 23373 . 23374) (nil fontified nil 23365 . 23373) (nil fontified nil 23357 . 23365) (23357 . 23824) nil ("        set_data(\"previous\",message.from_user.id,message.text)
        quest = question_array[0]
        set_data(\"attempt\",message.from_user.id,3)
        set_data(\"completed\",message.from_user.id,0)
        set_data(\"current\",message.from_user.id,quest.correct_id)
        set_data(\"question\",message.from_user.id,question_array.index(quest))
        await bot.send_message(message.chat.id,text=quest.text ,reply_markup=question_create(quest),parse_mode=\"Markdown\")" . 23357) ((marker . 23787) . -467) ((marker*) . 1) ((marker) . -467) ((marker*) . 92) ((marker) . -376) (nil fontified t 23419 . 23420) (nil fontified t 23453 . 23454) (nil fontified t 23504 . 23505) (nil fontified t 23557 . 23558) (nil fontified t 23623 . 23624) (nil fontified t 23701 . 23702) (nil rear-nonsticky t 23823 . 23824) nil (nil rear-nonsticky nil 23823 . 23824) (nil fontified nil 23823 . 23824) (nil fontified nil 23813 . 23823) (nil fontified nil 23801 . 23813) (nil fontified nil 23800 . 23801) (nil fontified nil 23795 . 23800) (nil fontified nil 23794 . 23795) (nil fontified nil 23748 . 23794) (nil fontified nil 23746 . 23748) (nil fontified nil 23733 . 23746) (nil fontified nil 23732 . 23733) (nil fontified nil 23715 . 23732) (nil fontified nil 23710 . 23715) (nil fontified nil 23701 . 23710) (nil fontified nil 23700 . 23701) (nil fontified nil 23699 . 23700) (nil fontified nil 23694 . 23699) (nil fontified nil 23693 . 23694) (nil fontified nil 23672 . 23693) (nil fontified nil 23670 . 23672) (nil fontified nil 23651 . 23670) (nil fontified nil 23641 . 23651) (nil fontified nil 23640 . 23641) (nil fontified nil 23623 . 23640) (nil fontified nil 23622 . 23623) (nil fontified nil 23605 . 23622) (nil fontified nil 23603 . 23605) (nil fontified nil 23584 . 23603) (nil fontified nil 23575 . 23584) (nil fontified nil 23574 . 23575) (nil fontified nil 23557 . 23574) (nil fontified nil 23556 . 23557) (nil fontified nil 23554 . 23556) (nil fontified nil 23552 . 23554) (nil fontified nil 23533 . 23552) (nil fontified nil 23522 . 23533) (nil fontified nil 23521 . 23522) (nil fontified nil 23504 . 23521) (nil fontified nil 23503 . 23504) (nil fontified nil 23501 . 23503) (nil fontified nil 23499 . 23501) (nil fontified nil 23480 . 23499) (nil fontified nil 23471 . 23480) (nil fontified nil 23470 . 23471) (nil fontified nil 23453 . 23470) (nil fontified nil 23452 . 23453) (nil fontified nil 23451 . 23452) (nil fontified nil 23450 . 23451) (nil fontified nil 23433 . 23450) (nil fontified nil 23428 . 23433) (nil fontified nil 23420 . 23428) (nil fontified nil 23419 . 23420) (nil fontified nil 23418 . 23419) (nil fontified nil 23405 . 23418) (nil fontified nil 23403 . 23405) (nil fontified nil 23384 . 23403) (nil fontified nil 23374 . 23384) (nil fontified nil 23373 . 23374) (nil fontified nil 23365 . 23373) (nil fontified nil 23357 . 23365) (23357 . 23824) nil (23345 . 23357) ("        " . 23344) ((marker . 23787) . -8) ((marker . 23344) . -8) (23352 . 23353) nil ("    " . -23352) ((marker . 23787) . -4) 23356 nil (23344 . 23356) ("        " . 23344) ((marker . 23787) . -8) ((marker . 23778) . -8) ((marker . 23344) . -8) 23352 nil ("    " . -23352) ((marker . 23787) . -4) ((marker . 23778) . -4) ((marker . 23344) . -4) 23356 nil ("
        set_data(\"previous-post\",message.from_user.id,message.text)
        " . 23356) ((marker . 23778) . -77) ((marker . 23344) . -77) ((marker) . -77) nil (23344 . 23356) (t 25707 26803 626373 743000) nil (18237 . 18704) nil ("        set_data(\"previous\",message.from_user.id,message.text)
        quest = question_array[0]
        set_data(\"attempt\",message.from_user.id,3)
        set_data(\"completed\",message.from_user.id,0)
        set_data(\"current\",message.from_user.id,quest.correct_id)
        set_data(\"question\",message.from_user.id,question_array.index(quest))
        await bot.send_message(message.chat.id,text=quest.text ,reply_markup=question_create(quest),parse_mode=\"Markdown\")" . 18237) ((marker . 23778) . -467) ((marker . 18704) . -467) ((marker . 18246) . -9) ((marker . 18704) . -467) ((marker . 18247) . -10) ((marker . 18246) . -9) ((marker . 18704) . -467) ((marker . 18247) . -10) ((marker) . -467) (t 25707 26803 626373 743000) nil (18237 . 18245) ("            " . 18237) ((marker . 23787) . -12) ((marker . 23353) . -12) nil (18237 . 18249) ("        " . 18237) (t 25707 26803 626373 743000) nil (nil rear-nonsticky nil 44124 . 44125) (nil fontified nil 44099 . 44125) (44099 . 44125) nil ("bot.polling()" . 44099) ((marker . 23778) . -13) ((marker . 44031) . -13) (t 25704 47290 427507 746000) nil ("bot.infinity_polling(True)" . 1) ((marker . 23787) . -26) ((marker*) . 1) ((marker) . -26) ((marker*) . 6) ((marker) . -21) (nil rear-nonsticky t 26 . 27) nil (nil rear-nonsticky nil 26 . 27) (nil fontified nil 1 . 27) (1 . 27) (t 25704 47290 427507 746000) nil (10416 . 10417) nil ("
" . -10333) 10334 nil ("        " . -10334) 10342 nil (nil rear-nonsticky nil 10424 . 10425) (nil fontified nil 10424 . 10425) (nil fontified nil 10420 . 10424) (nil fontified nil 10405 . 10420) (nil fontified nil 10404 . 10405) (nil fontified nil 10397 . 10404) (nil fontified nil 10395 . 10397) (nil fontified nil 10385 . 10395) (nil fontified nil 10383 . 10385) (nil fontified nil 10375 . 10383) (nil fontified nil 10374 . 10375) (nil fontified nil 10372 . 10374) (nil fontified nil 10365 . 10372) (nil fontified nil 10360 . 10365) (nil fontified nil 10359 . 10360) (nil fontified nil 10350 . 10359) (nil fontified nil 10343 . 10350) (nil fontified nil 10342 . 10343) (10342 . 10425) nil (10333 . 10342) (t 25704 47128 91611 927000) nil (10333 . 10416) nil ("
        question(\"10) Отпуск\", [\"Resort\", \"Vacation\", \"Route\"], 1, randomize=True)" . 10333) (t 25704 47128 91611 927000) nil (23524 . 23526) nil ("9" . -23524) 23525 (t 25704 47116 977386 950000) nil ("                                " . -23701) nil ("                                " . -23635) nil ("                                " . -23584) nil ("                                " . -23542) nil ("                                " . -23462) nil ("                                " . -23409) nil ("                                      " . -23346) nil (nil rear-nonsticky nil 23999 . 24000) (nil fontified nil 23999 . 24000) (nil fontified nil 23998 . 23999) (nil fontified nil 23993 . 23998) (nil fontified nil 23992 . 23993) (nil fontified nil 23971 . 23992) (nil fontified nil 23969 . 23971) (nil fontified nil 23950 . 23969) (nil fontified nil 23940 . 23950) (nil fontified nil 23939 . 23940) (nil fontified nil 23931 . 23939) (nil fontified nil 23891 . 23931) (nil fontified nil 23890 . 23891) (nil fontified nil 23889 . 23890) (nil fontified nil 23872 . 23889) (nil fontified nil 23870 . 23872) (nil fontified nil 23851 . 23870) (nil fontified nil 23842 . 23851) (nil fontified nil 23841 . 23842) (nil fontified nil 23833 . 23841) (nil fontified nil 23793 . 23833) (nil fontified nil 23792 . 23793) (nil fontified nil 23791 . 23792) (nil fontified nil 23789 . 23791) (nil fontified nil 23787 . 23789) (nil fontified nil 23775 . 23787) (nil fontified nil 23768 . 23775) (nil fontified nil 23759 . 23768) (nil fontified nil 23758 . 23759) (nil fontified nil 23750 . 23758) (nil fontified nil 23710 . 23750) (nil fontified nil 23709 . 23710) (nil fontified nil 23708 . 23709) (nil fontified nil 23699 . 23708) (nil fontified nil 23698 . 23699) (nil fontified nil 23681 . 23698) (nil fontified nil 23676 . 23681) (nil fontified nil 23652 . 23676) (nil fontified nil 23636 . 23652) (nil fontified nil 23633 . 23636) (nil fontified nil 23629 . 23633) (nil fontified nil 23628 . 23629) (nil fontified nil 23627 . 23628) (nil fontified nil 23622 . 23627) (nil fontified nil 23621 . 23622) (nil fontified nil 23620 . 23621) (nil fontified nil 23618 . 23620) (nil fontified nil 23599 . 23618) (nil fontified nil 23589 . 23599) (nil fontified nil 23588 . 23589) (nil fontified nil 23580 . 23588) (nil fontified nil 23579 . 23580) (nil fontified nil 23576 . 23579) (nil fontified nil 23575 . 23576) (nil fontified nil 23573 . 23575) (nil fontified nil 23568 . 23573) (nil fontified nil 23564 . 23568) (nil fontified nil 23524 . 23564) (nil fontified nil 23523 . 23524) (nil fontified nil 23522 . 23523) (nil fontified nil 23520 . 23522) (nil fontified nil 23518 . 23520) (nil fontified nil 23499 . 23518) (nil fontified nil 23488 . 23499) (nil fontified nil 23487 . 23488) (nil fontified nil 23479 . 23487) (nil fontified nil 23439 . 23479) (nil fontified nil 23438 . 23439) (nil fontified nil 23437 . 23438) (nil fontified nil 23424 . 23437) (nil fontified nil 23422 . 23424) (nil fontified nil 23403 . 23422) (nil fontified nil 23393 . 23403) (nil fontified nil 23392 . 23393) (nil fontified nil 23384 . 23392) (nil fontified nil 23344 . 23384) (23344 . 24000) nil ("  set_data(\"previous\",message.from_user.id,message.text)
        set_data(\"completed\",message.from_user.id,0)
        quiz = 1 if(int(get_data(\"question\",message.from_user.id)) <= 9) else 0
        quest = question_array[0+quiz*10]
        set_data(\"attempt\",message.from_user.id,2)
        set_data(\"current\",message.from_user.id,quest.correct_id)
        set_data(\"question\",message.from_user.id,question_array.index(quest))" . 23344) (t 25704 46765 500132 425000) nil (23269 . 23770) nil ("set_data(\"previous-post\",message.from_user.id,message.text)
        
        set_data(\"previous\",message.from_user.id,message.text)
        set_data(\"completed\",message.from_user.id,0)
        quiz = 1 if(int(get_data(\"question\",message.from_user.id)) <= 9) else 0
        quest = question_array[0+quiz*10]
        set_data(\"attempt\",message.from_user.id,2)
        set_data(\"current\",message.from_user.id,quest.correct_id)
        set_data(\"question\",message.from_user.id,question_array.index(quest))" . 23269) (t 25704 46765 500132 425000) nil (24378 . 24387) nil ("        " . -24273) 24287 nil (nil rear-nonsticky nil 24385 . 24386) (nil fontified nil 24385 . 24386) (nil fontified nil 24383 . 24385) (nil fontified nil 24381 . 24383) (nil fontified nil 24362 . 24381) (nil fontified nil 24346 . 24362) (nil fontified nil 24345 . 24346) (nil fontified nil 24329 . 24345) (nil fontified nil 24328 . 24329) (nil fontified nil 24327 . 24328) (nil fontified nil 24325 . 24327) (nil fontified nil 24323 . 24325) (nil fontified nil 24315 . 24323) (nil fontified nil 24304 . 24315) (nil fontified nil 24290 . 24304) (nil fontified nil 24289 . 24290) (nil fontified nil 24273 . 24289) (24273 . 24386) (t 25704 46609 569041 114000) nil (nil rear-nonsticky nil 34817 . 34818) (nil fontified nil 34808 . 34818) (nil fontified nil 34804 . 34808) (nil fontified nil 34803 . 34804) (nil fontified nil 34801 . 34803) (nil fontified nil 34782 . 34801) (nil fontified nil 34767 . 34782) (nil fontified nil 34766 . 34767) (nil fontified nil 34757 . 34766) (nil fontified nil 34754 . 34757) (34754 . 34818) nil (34753 . 34754) (t 25704 46157 680328 450000) nil (33994 . 34058) nil ("and get_data(\"previous-post\",message.from_user.id) == \"Grammar✏\"" . 33994) (t 25704 46157 680328 450000) nil (36805 . 36863) (t 25704 46146 697358 969000) nil ("
        user_name = get_data(\"name\",message.from_user.id)" . 36805) (t 25704 46138 658519 621000) nil ("    " . -36524) 36528 nil (36516 . 36528) (t 25704 46055 239453 560000) nil (nil fontified nil 38144 . 38145) (nil fontified nil 38136 . 38144) (nil fontified nil 38135 . 38136) (nil fontified nil 38134 . 38135) (nil fontified nil 38120 . 38134) (nil fontified nil 38086 . 38120) (nil fontified nil 38070 . 38086) (nil fontified nil 38069 . 38070) (nil fontified nil 38068 . 38069) (nil fontified nil 38024 . 38068) (nil fontified nil 38021 . 38024) (nil fontified nil 38006 . 38021) (nil fontified nil 38005 . 38006) (nil fontified nil 38004 . 38005) (nil fontified nil 38003 . 38004) (nil fontified nil 37955 . 38003) (nil fontified nil 37939 . 37955) (nil fontified nil 37937 . 37939) (nil fontified nil 37893 . 37937) (nil fontified nil 37877 . 37893) (nil fontified nil 37876 . 37877) (nil fontified nil 37875 . 37876) (nil fontified nil 37832 . 37875) (nil fontified nil 37816 . 37832) (nil fontified nil 37815 . 37816) (nil fontified nil 37814 . 37815) (nil fontified nil 37811 . 37814) (nil fontified nil 37807 . 37811) (nil fontified nil 37799 . 37807) (nil fontified nil 37798 . 37799) (nil fontified nil 37797 . 37798) (nil fontified nil 37789 . 37797) (nil fontified nil 37788 . 37789) (nil fontified nil 37787 . 37788) (nil fontified nil 37754 . 37787) (nil fontified nil 37738 . 37754) (nil fontified nil 37737 . 37738) (nil fontified nil 37736 . 37737) (nil fontified nil 37699 . 37736) (nil fontified nil 37683 . 37699) (nil fontified nil 37682 . 37683) (nil fontified nil 37681 . 37682) (nil fontified nil 37649 . 37681) (nil fontified nil 37633 . 37649) (nil fontified nil 37632 . 37633) (nil fontified nil 37631 . 37632) (nil fontified nil 37597 . 37631) (nil fontified nil 37581 . 37597) (nil fontified nil 37580 . 37581) (nil fontified nil 37579 . 37580) (nil fontified nil 37540 . 37579) (nil fontified nil 37524 . 37540) (nil fontified nil 37522 . 37524) (nil fontified nil 37491 . 37522) (nil fontified nil 37475 . 37491) (nil fontified nil 37473 . 37475) (nil fontified nil 37437 . 37473) (nil fontified nil 37421 . 37437) (nil fontified nil 37419 . 37421) (nil fontified nil 37397 . 37419) (nil fontified nil 37381 . 37397) (nil fontified nil 37380 . 37381) (nil fontified nil 37379 . 37380) (nil fontified nil 37359 . 37379) (nil fontified nil 37343 . 37359) (nil fontified nil 37341 . 37343) (nil fontified nil 37317 . 37341) (nil fontified nil 37301 . 37317) (nil fontified nil 37299 . 37301) (nil fontified nil 37283 . 37299) (nil fontified nil 37267 . 37283) (nil fontified nil 37266 . 37267) (nil fontified nil 37265 . 37266) (nil fontified nil 37262 . 37265) (nil fontified nil 37253 . 37262) (nil fontified nil 37249 . 37253) (nil fontified nil 37245 . 37249) (nil fontified nil 37244 . 37245) (nil fontified nil 37243 . 37244) (nil fontified nil 37214 . 37243) (nil fontified nil 37212 . 37214) (nil fontified nil 37189 . 37212) (nil fontified nil 37187 . 37189) (nil fontified nil 37169 . 37187) (nil fontified nil 37167 . 37169) (nil fontified nil 37145 . 37167) (nil fontified nil 37143 . 37145) (nil fontified nil 37127 . 37143) (nil fontified nil 37125 . 37127) (nil fontified nil 37107 . 37125) (nil fontified nil 37105 . 37107) (nil fontified nil 37081 . 37105) (nil fontified nil 37079 . 37081) (nil fontified nil 37058 . 37079) (nil fontified nil 37056 . 37058) (nil fontified nil 37043 . 37056) (nil fontified nil 37041 . 37043) (nil fontified nil 37031 . 37041) (nil fontified nil 37029 . 37031) (nil fontified nil 37022 . 37029) (nil fontified nil 37020 . 37022) (nil fontified nil 37009 . 37020) (nil fontified nil 37007 . 37009) (nil fontified nil 36993 . 37007) (nil fontified nil 36991 . 36993) (nil fontified nil 36975 . 36991) (nil fontified nil 36973 . 36975) (nil fontified nil 36959 . 36973) (nil fontified nil 36957 . 36959) (nil fontified nil 36947 . 36957) (nil fontified nil 36945 . 36947) (nil fontified nil 36932 . 36945) (nil fontified nil 36930 . 36932) (nil fontified nil 36919 . 36930) (nil fontified nil 36917 . 36919) (nil fontified nil 36911 . 36917) (nil fontified nil 36909 . 36911) (nil fontified nil 36898 . 36909) (nil fontified nil 36896 . 36898) (nil fontified nil 36891 . 36896) (nil fontified nil 36889 . 36891) (nil fontified nil 36882 . 36889) (nil fontified nil 36880 . 36882) (nil fontified nil 36876 . 36880) (nil fontified nil 36875 . 36876) (nil fontified nil 36872 . 36875) (nil fontified nil 36864 . 36872) (nil fontified nil 36856 . 36864) (36856 . 38145) nil ("        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [
                \"Where are you?\",
                \"Do you plan to travel?\",
                \"Are you traveling?\",
                \"Where are you going?\",
                \"Have you been on any recent trips?\",
                \"Are you exploring new places?\",
                \"What's your dream travel destination?\",
                \"Have you ever traveled for work?\",
                \"Are you an adventure traveler?\",
                \"What's your best travel packing tip?\",
                \"What's your favorite way to travel?\",
                \"Do you have any upcoming trips?\",
                \"Do you keep a travel journal?\",
        ]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"I've heard you've become quite the globetrotter.\",
                \"I've heard whispers of your travel escapades.\",
                \"I've heard tales of your travel adventures.\",
                \"Seems like you're on a quest to see the world.\",
        ]" . 36856) (t 25704 12483 824423 655000) nil (40016 . 41305) nil ("        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [
                \"Where are you?\",
                \"Do you plan to travel?\",
                \"Are you traveling?\",
                \"Where are you going?\",
                \"Have you been on any recent trips?\",
                \"Are you exploring new places?\",
                \"What's your dream travel destination?\",
                \"Have you ever traveled for work?\",
                \"Are you an adventure traveler?\",
                \"What's your favorite way to travel?\",
                \"Do you have any upcoming trips?\",
        ]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"I've heard stories of your travel adventures.\",
                \"Seems like you're on a quest to see the world.\",
        ]" . 40016) (t 25704 12483 824423 655000) nil ("resize_keyboard=True" . 41486) (t 25704 12467 84456 985000) nil ("
                \"Do you keep a travel journal?\"," . 40948) (t 25704 12417 387896 526000) nil (nil rear-nonsticky nil 41581 . 41582) (nil fontified nil 41577 . 41582) (nil fontified nil 41573 . 41577) (41573 . 41582) nil ("\"Greet\"" . 41573) (t 25704 12376 591325 755000) nil (41363 . 41372) nil ("usr_start" . 41363) (t 25704 12376 591325 755000) nil (41242 . 41249) nil ("x" . -41242) ("\\" . -41243) ("s" . -41244) 41245 nil (41242 . 41245) nil ("tales" . 41242) 41247 (t 25704 12369 418010 147000) nil ("
                \"I've heard you've become quite the globetrotter.\",
                \"I've heard whispers of your travel escapades.\"," . 41213) ("\\" . -41213) 41214 nil (41213 . 41214) (t 25704 12345 691404 43000) nil ("\\" . 41213) nil (36525 . 41214) (36525 . 36593) nil ("
                \"I've heard you've become quite the globetrotter.\"," . 36525) ("clear_data(\"past\",message.from_user.id)
        clear_data(\"generated\",message.from_user.id)
        set_data(\"previous-post\",message.from_user.id,\"Chat🗣\")
        send=start_prompt
        name_list = generate_names()
        user_name, bot_name = select_names(name_list)
        user_name = get_data(\"name\",message.from_user.id)
        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [
                \"Where are you?\",
                \"Do you plan to travel?\",
                \"Are you traveling?\",
                \"Where are you going?\",
                \"Have you been on any recent trips?\",
                \"Are you exploring new places?\",
                \"What's your dream travel destination?\",
                \"Have you ever traveled for work?\",
                \"Are you an adventure traveler?\",
                \"What's your best travel packing tip?\",
                \"What's your favorite way to travel?\",
                \"Do you have any upcoming trips?\",
                \"Do you keep a travel journal?\",
        ]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"I've heard you've become quite the globetrotter.\",
                \"I've heard whispers of your travel escapades.\",
                \"I've heard tales of your travel adventures.\",
                \"Seems like you're on a quest to see the world.\",
        ]
        usr_start = f\"{random.choice(greeting)} {bot_name}! It's me, {user_name}! {random.choice(conv)} {random.choice(questions)}\"
        kbd = telebot.types.ReplyKeyboardMarkup()
        kbd.row(usr_start)
        kbd.row(\"!Go back\")
        await bot.send_message(message.chat.id, text=send,reply_markup=kbd,parse_mode=\"Markdown\")
    elif(prevmess == \"complete\" and get_data(\"previous-post\",message.from_user.id) == \"Chat🗣\" and message.text != \"!Go back\" and message.text != \"!Reset\"):
        print(format_data(get_data(\"generated\",message.from_user.id)))
        print(type(format_data(get_data(\"generated\",message.from_user.id))))
        output = prompt(format_data(get_data(\"past\",message.from_user.id)),format_data(get_data(\"generated\",message.from_user.id)),message.text)
        print(output)
        add_data(\"past\",message.from_user.id,message.text)
        add_data(\"generated\",message.from_user.id,output[\"generated_text\"])
        send = output[\"generated_text\"]
        kbd=types.ReplyKeyboardMarkup()
        kbd.row(\"!Reset\")
        kbd.row(\"!Go back\")
        await bot.send_message(message.chat.id, send, reply_markup=kbd, parse_mode=\"Markdown\")
    elif(prevmess == \"complete\" and get_data(\"previous-post\",message.from_user.id) == \"Chat🗣\" and message.text == \"!Reset\"):
        clear_data(\"past\",message.from_user.id)
        clear_data(\"generated\",message.from_user.id)
        set_data(\"previous-post\",message.from_user.id,\"Chat🗣\")
        send=start_prompt
        name_list = generate_names()
        user_name, bot_name = select_names(name_list)
        user_name = get_data(\"name\",message.from_user.id)
        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [
                \"Where are you?\",
                \"Do you plan to travel?\",
                \"Are you traveling?\",
                \"Where are you going?\",
                \"Have you been on any recent trips?\",
                \"Are you exploring new places?\",
                \"What's your dream travel destination?\",
                \"Have you ever traveled for work?\",
                \"Are you an adventure traveler?\",
                \"What's your favorite way to travel?\",
                \"Do you have any upcoming trips?\",
                \"Do you keep a travel journal?\",
        ]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",\\" . 36525) nil (36525 . 41214) (36525 . 36593) nil ("
                \"I've heard you've become quite the globetrotter.\"," . 36525) ("clear_data(\"past\",message.from_user.id)
        clear_data(\"generated\",message.from_user.id)
        set_data(\"previous-post\",message.from_user.id,\"Chat🗣\")
        send=start_prompt
        name_list = generate_names()
        user_name, bot_name = select_names(name_list)
        user_name = get_data(\"name\",message.from_user.id)
        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [
                \"Where are you?\",
                \"Do you plan to travel?\",
                \"Are you traveling?\",
                \"Where are you going?\",
                \"Have you been on any recent trips?\",
                \"Are you exploring new places?\",
                \"What's your dream travel destination?\",
                \"Have you ever traveled for work?\",
                \"Are you an adventure traveler?\",
                \"What's your best travel packing tip?\",
                \"What's your favorite way to travel?\",
                \"Do you have any upcoming trips?\",
                \"Do you keep a travel journal?\",
        ]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"I've heard you've become quite the globetrotter.\",
                \"I've heard whispers of your travel escapades.\",
                \"I've heard tales of your travel adventures.\",
                \"Seems like you're on a quest to see the world.\",
        ]
        usr_start = f\"{random.choice(greeting)} {bot_name}! It's me, {user_name}! {random.choice(conv)} {random.choice(questions)}\"
        kbd = telebot.types.ReplyKeyboardMarkup()
        kbd.row(usr_start)
        kbd.row(\"!Go back\")
        await bot.send_message(message.chat.id, text=send,reply_markup=kbd,parse_mode=\"Markdown\")
    elif(prevmess == \"complete\" and get_data(\"previous-post\",message.from_user.id) == \"Chat🗣\" and message.text != \"!Go back\" and message.text != \"!Reset\"):
        print(format_data(get_data(\"generated\",message.from_user.id)))
        print(type(format_data(get_data(\"generated\",message.from_user.id))))
        output = prompt(format_data(get_data(\"past\",message.from_user.id)),format_data(get_data(\"generated\",message.from_user.id)),message.text)
        print(output)
        add_data(\"past\",message.from_user.id,message.text)
        add_data(\"generated\",message.from_user.id,output[\"generated_text\"])
        send = output[\"generated_text\"]
        kbd=types.ReplyKeyboardMarkup()
        kbd.row(\"!Reset\")
        kbd.row(\"!Go back\")
        await bot.send_message(message.chat.id, send, reply_markup=kbd, parse_mode=\"Markdown\")
    elif(prevmess == \"complete\" and get_data(\"previous-post\",message.from_user.id) == \"Chat🗣\" and message.text == \"!Reset\"):
        clear_data(\"past\",message.from_user.id)
        clear_data(\"generated\",message.from_user.id)
        set_data(\"previous-post\",message.from_user.id,\"Chat🗣\")
        send=start_prompt
        name_list = generate_names()
        user_name, bot_name = select_names(name_list)
        user_name = get_data(\"name\",message.from_user.id)
        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [
                \"Where are you?\",
                \"Do you plan to travel?\",
                \"Are you traveling?\",
                \"Where are you going?\",
                \"Have you been on any recent trips?\",
                \"Are you exploring new places?\",
                \"What's your dream travel destination?\",
                \"Have you ever traveled for work?\",
                \"Are you an adventure traveler?\",
                \"What's your favorite way to travel?\",
                \"Do you have any upcoming trips?\",
                \"Do you keep a travel journal?\",
        ]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",\\" . -36525) 41214 nil (41213 . 41214) (t 25704 12345 691404 43000) nil ("
                \"What's your best travel packing tip?\"," . 40842) (t 25704 12272 868276 405000) nil ("    " . -39875) 39878 (t 25704 12268 78291 54000) nil (nil fontified nil 41676 . 41677) (nil fontified nil 41675 . 41676) (nil fontified nil 41674 . 41675) (nil fontified nil 41665 . 41674) (nil fontified nil 41664 . 41665) (nil fontified nil 41651 . 41664) (nil fontified nil 41650 . 41651) (nil fontified nil 41649 . 41650) (nil fontified nil 41629 . 41649) (nil fontified nil 41628 . 41629) (nil fontified nil 41627 . 41628) (nil fontified nil 41626 . 41627) (nil fontified nil 41615 . 41626) (nil fontified nil 41606 . 41615) (nil fontified nil 41604 . 41606) (nil fontified nil 41595 . 41604) (nil fontified nil 41594 . 41595) (nil fontified nil 41593 . 41594) (nil fontified nil 41587 . 41593) (nil fontified nil 41582 . 41587) (nil fontified nil 41569 . 41582) (nil fontified nil 41568 . 41569) (nil fontified nil 41567 . 41568) (nil fontified nil 41563 . 41567) (nil fontified nil 41558 . 41563) (nil fontified nil 41554 . 41558) (nil fontified nil 41546 . 41554) (nil fontified nil 41545 . 41546) (nil fontified nil 41544 . 41545) (nil fontified nil 41536 . 41544) (nil fontified nil 41535 . 41536) (nil fontified nil 41534 . 41535) (nil fontified nil 41520 . 41534) (nil fontified nil 41486 . 41520) (nil fontified nil 41470 . 41486) (nil fontified nil 41469 . 41470) (nil fontified nil 41468 . 41469) (nil fontified nil 41423 . 41468) (nil fontified nil 41407 . 41423) (nil fontified nil 41406 . 41407) (nil fontified nil 41405 . 41406) (nil fontified nil 41358 . 41405) (nil fontified nil 41342 . 41358) (nil fontified nil 41341 . 41342) (nil fontified nil 41340 . 41341) (nil fontified nil 41290 . 41340) (nil fontified nil 41274 . 41290) (nil fontified nil 41273 . 41274) (nil fontified nil 41272 . 41273) (nil fontified nil 41224 . 41272) (nil fontified nil 41208 . 41224) (nil fontified nil 41206 . 41208) (nil fontified nil 41162 . 41206) (nil fontified nil 41146 . 41162) (nil fontified nil 41145 . 41146) (nil fontified nil 41144 . 41145) (nil fontified nil 41101 . 41144) (nil fontified nil 41085 . 41101) (nil fontified nil 41084 . 41085) (nil fontified nil 41083 . 41084) (nil fontified nil 41080 . 41083) (nil fontified nil 41076 . 41080) (nil fontified nil 41068 . 41076) (nil fontified nil 41067 . 41068) (nil fontified nil 41066 . 41067) (nil fontified nil 41058 . 41066) (nil fontified nil 41057 . 41058) (nil fontified nil 41056 . 41057) (nil fontified nil 41025 . 41056) (nil fontified nil 41009 . 41025) (nil fontified nil 41008 . 41009) (nil fontified nil 41007 . 41008) (nil fontified nil 40974 . 41007) (nil fontified nil 40958 . 40974) (nil fontified nil 40957 . 40958) (nil fontified nil 40956 . 40957) (nil fontified nil 40919 . 40956) (nil fontified nil 40903 . 40919) (nil fontified nil 40902 . 40903) (nil fontified nil 40901 . 40902) (nil fontified nil 40863 . 40901) (nil fontified nil 40847 . 40863) (nil fontified nil 40845 . 40847) (nil fontified nil 40813 . 40845) (nil fontified nil 40797 . 40813) (nil fontified nil 40796 . 40797) (nil fontified nil 40795 . 40796) (nil fontified nil 40761 . 40795) (nil fontified nil 40745 . 40761) (nil fontified nil 40744 . 40745) (nil fontified nil 40743 . 40744) (nil fontified nil 40704 . 40743) (nil fontified nil 40688 . 40704) (nil fontified nil 40686 . 40688) (nil fontified nil 40655 . 40686) (nil fontified nil 40639 . 40655) (nil fontified nil 40637 . 40639) (nil fontified nil 40601 . 40637) (nil fontified nil 40585 . 40601) (nil fontified nil 40583 . 40585) (nil fontified nil 40561 . 40583) (nil fontified nil 40545 . 40561) (nil fontified nil 40544 . 40545) (nil fontified nil 40543 . 40544) (nil fontified nil 40523 . 40543) (nil fontified nil 40507 . 40523) (nil fontified nil 40505 . 40507) (nil fontified nil 40481 . 40505) (nil fontified nil 40465 . 40481) (nil fontified nil 40463 . 40465) (nil fontified nil 40447 . 40463) (nil fontified nil 40431 . 40447) (nil fontified nil 40430 . 40431) (nil fontified nil 40429 . 40430) (nil fontified nil 40426 . 40429) (nil fontified nil 40417 . 40426) (nil fontified nil 40413 . 40417) (nil fontified nil 40409 . 40413) (nil fontified nil 40408 . 40409) (nil fontified nil 40407 . 40408) (nil fontified nil 40378 . 40407) (nil fontified nil 40376 . 40378) (nil fontified nil 40353 . 40376) (nil fontified nil 40351 . 40353) (nil fontified nil 40333 . 40351) (nil fontified nil 40331 . 40333) (nil fontified nil 40309 . 40331) (nil fontified nil 40307 . 40309) (nil fontified nil 40291 . 40307) (nil fontified nil 40289 . 40291) (nil fontified nil 40271 . 40289) (nil fontified nil 40269 . 40271) (nil fontified nil 40245 . 40269) (nil fontified nil 40243 . 40245) (nil fontified nil 40222 . 40243) (nil fontified nil 40220 . 40222) (nil fontified nil 40207 . 40220) (nil fontified nil 40205 . 40207) (nil fontified nil 40195 . 40205) (nil fontified nil 40193 . 40195) (nil fontified nil 40186 . 40193) (nil fontified nil 40184 . 40186) (nil fontified nil 40173 . 40184) (nil fontified nil 40171 . 40173) (nil fontified nil 40157 . 40171) (nil fontified nil 40155 . 40157) (nil fontified nil 40139 . 40155) (nil fontified nil 40137 . 40139) (nil fontified nil 40123 . 40137) (nil fontified nil 40121 . 40123) (nil fontified nil 40111 . 40121) (nil fontified nil 40109 . 40111) (nil fontified nil 40096 . 40109) (nil fontified nil 40094 . 40096) (nil fontified nil 40083 . 40094) (nil fontified nil 40081 . 40083) (nil fontified nil 40075 . 40081) (nil fontified nil 40073 . 40075) (nil fontified nil 40062 . 40073) (nil fontified nil 40060 . 40062) (nil fontified nil 40055 . 40060) (nil fontified nil 40053 . 40055) (nil fontified nil 40046 . 40053) (nil fontified nil 40044 . 40046) (nil fontified nil 40040 . 40044) (nil fontified nil 40039 . 40040) (nil fontified nil 40036 . 40039) (nil fontified nil 40028 . 40036) (nil fontified nil 40020 . 40028) (nil fontified nil 40019 . 40020) (nil fontified nil 40018 . 40019) (nil fontified nil 40016 . 40018) (nil fontified nil 39997 . 40016) (nil fontified nil 39996 . 39997) (nil fontified nil 39991 . 39996) (nil fontified nil 39990 . 39991) (nil fontified nil 39979 . 39990) (nil fontified nil 39970 . 39979) (nil fontified nil 39962 . 39970) (nil fontified nil 39961 . 39962) (nil fontified nil 39960 . 39961) (nil fontified nil 39951 . 39960) (nil fontified nil 39950 . 39951) (nil fontified nil 39935 . 39950) (nil fontified nil 39927 . 39935) (nil fontified nil 39925 . 39927) (nil fontified nil 39916 . 39925) (nil fontified nil 39908 . 39916) (nil fontified nil 39907 . 39908) (nil fontified nil 39906 . 39907) (nil fontified nil 39905 . 39906) (nil fontified nil 39888 . 39905) (nil fontified nil 39879 . 39888) (nil fontified nil 39871 . 39879) (39871 . 41677) nil ("    name_list = generate_names()
        user_name, bot_name = select_names(name_list)
        user_name = get_data(\"name\",message.from_user.id)
        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [
                \"Where are you?\",
                \"Do you plan to travel?\",
                \"Are you traveling?\",
                \"What was your favorite place to visit?\",
                \"Where are you going?\",
                \"Have you been on any recent trips?\",
                \"Are you exploring new places?\",
                \"What's your dream travel destination?\",
                \"Do you prefer solo travel or with companions?\",
                \"Have you ever traveled for work?\",
                \"What's your most memorable travel experience?\",
                \"Are you an adventure traveler?\",
                \"What's your best travel packing tip?\",
                \"Have you ever experienced culture shock?\",
                \"Do you like to try local food when you travel?\",
                \"What's your favorite way to travel?\",
                \"Have you ever traveled off the beaten path?\",
                \"Do you prefer hotels or alternative accommodations?\",
                \"What's the longest trip you've ever taken?\",
                \"Do you have any upcoming trips?\",
                \"What's the most beautiful place you've seen?\",
                \"Have you ever traveled for a special occasion?\",
                \"Do you keep a travel journal?\",
                \"What's the most challenging part of travel for you?\",
                \"Do you have any tips for saving money on travel?\",
        ]
        conv = [
                \"I've heard you're getting into traveling.\",        ]
        usr_start = f\"{random.choice(greeting)} {bot_name}! It's me, {user_name}! {random.choice(conv)} {random.choice(questions)}\"" . 39871) 40461 (t 25704 12224 828430 90000) nil (36707 . 38513) nil ("        name_list = generate_names()
        user_name, bot_name = select_names(name_list)
        user_name = get_data(\"name\",message.from_user.id)
        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [
                \"Where are you?\",
                \"Do you plan to travel?\",
                \"Are you traveling?\",
                \"Where are you going?\",
                \"Have you been on any recent trips?\",
                \"Are you exploring new places?\",
                \"What's your dream travel destination?\",
                \"Have you ever traveled for work?\",
                \"Are you an adventure traveler?\",
                \"What's your best travel packing tip?\",
                \"What's your favorite way to travel?\",
                \"Do you have any upcoming trips?\",
                \"Do you keep a travel journal?\",
        ]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"I've heard you've become quite the globetrotter.\",
                \"I've heard whispers of your travel escapades.\",
                \"I've heard tales of your travel adventures.\",
                \"Seems like you're on a quest to see the world.\",
        ]
        usr_start = f\"{random.choice(greeting)} {bot_name}! It's me, {user_name}! {random.choice(conv)} {random.choice(questions)}\"" . 36707) (t 25704 12224 828430 90000) nil (36856 . 38513) nil ("        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [
                \"Where are you?\",
                \"Do you plan to travel?\",
                \"Are you traveling?\",
                \"Where are you going?\",
                \"Have you been on any recent trips?\",
                \"Are you exploring new places?\",
                \"What's your dream travel destination?\",
                \"Have you ever traveled for work?\",
                \"Are you an adventure traveler?\",
                \"What's your best travel packing tip?\",
                \"What's your favorite way to travel?\",
                \"Do you have any upcoming trips?\",
                \"Do you keep a travel journal?\",
        ]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"I've heard you've become quite the globetrotter.\",
                \"I've heard whispers of your travel escapades.\",
                \"I've heard tales of your travel adventures.\",
                \"Seems like you're on a quest to see the world.\",
        ]
        usr_start = f\"{random.choice(greeting)} {bot_name}! It's me, {user_name}! {random.choice(conv)} {random.choice(questions)}\"" . 36856) (t 25704 12224 828430 90000) nil ("
                \"Have you ever experienced culture shock?\"," . 37738) (t 25704 12190 385216 677000) nil ("
                \"What's the longest trip you've ever taken?\"," . 37853) ("\\" . -37853) 37854 nil (37853 . 37854) nil ("
                \"Have you ever traveled off the beaten path?\"," . 37853) (t 25704 12158 825334 244000) nil ("
                \"Do you like to try local food when you travel?\"," . 37798) (t 25704 12138 692079 973000) nil ("
                \"What was your favorite place to visit?\"," . 37380) (t 25704 12134 642096 273000) nil ("
                \"Do you prefer solo travel or with companions?\"," . 37638) (t 25704 12132 425438 585000) nil ("
                \"What's your most memorable travel experience?\"," . 37755) (t 25704 12130 485446 476000) nil ("
                \"Do you prefer hotels or alternative accommodations?\"," . 38170) nil ("
                \"What's the most beautiful place you've seen?\",
                \"Have you ever traveled for a special occasion?\"," . 38354) (t 25704 12120 432154 541000) nil ("
                \"What's the most challenging part of travel for you?\",
                \"Do you have any tips for saving money on travel?\"," . 38533) (t 25704 12117 848831 983000) nil (39149 . 39150) nil ("," . -39149) 39150 nil ("
                \"I've heard you're collecting memories from around the globe.\",
                \"I've been told you're creating a travel story worth sharing.\",
                \"So, I hear you're embarking on a journey of a lifetime.\"" . 39150) nil ("
                \"I've been informed you're venturing into uncharted territories.\"," . 39084) nil ("
                \"Word has it that you're exploring the unknown.\"," . 39021) nil ("
                \"So, I hear you're filling your passport with stamps.\"," . 39021) nil ("
                \"I've been told you're discovering the beauty of travel.\"," . 39021) nil ("
                \"I've been informed you're jetting off to new destinations.\",
                \"Seems like you're diving headfirst into the world of travel.\",
                \"I've heard you're immersing yourself in different cultures.\"," . 39021) nil ("
                \"Word on the street is you're embracing the wanderlust.\"," . 38956) nil ("
                \"Rumor has it that you're embarking on new adventures.\"," . 38888) ("\\" . -38888) 38889 nil (38888 . 38889) nil ("
                \"I've heard you're planning some exciting trips.\"," . 38760) (t 25704 12060 822153 688000) nil (40201 . 40202) nil (" Long time no see, " . 40201) (t 25704 12039 58789 691000) nil ("        " . -37253) (t 25704 12037 155453 658000) nil (nil fontified nil 38689 . 38690) (nil fontified nil 38681 . 38689) (nil fontified nil 38679 . 38681) (nil fontified nil 38629 . 38679) (nil fontified nil 38613 . 38629) (nil fontified nil 38611 . 38613) (nil fontified nil 38558 . 38611) (nil fontified nil 38542 . 38558) (nil fontified nil 38540 . 38542) (nil fontified nil 38509 . 38540) (nil fontified nil 38493 . 38509) (nil fontified nil 38491 . 38493) (nil fontified nil 38443 . 38491) (nil fontified nil 38427 . 38443) (nil fontified nil 38425 . 38427) (nil fontified nil 38379 . 38425) (nil fontified nil 38363 . 38379) (nil fontified nil 38361 . 38363) (nil fontified nil 38328 . 38361) (nil fontified nil 38312 . 38328) (nil fontified nil 38310 . 38312) (nil fontified nil 38266 . 38310) (nil fontified nil 38250 . 38266) (nil fontified nil 38248 . 38250) (nil fontified nil 38195 . 38248) (nil fontified nil 38179 . 38195) (nil fontified nil 38177 . 38179) (nil fontified nil 38132 . 38177) (nil fontified nil 38116 . 38132) (nil fontified nil 38114 . 38116) (nil fontified nil 38077 . 38114) (nil fontified nil 38061 . 38077) (nil fontified nil 38059 . 38061) (nil fontified nil 38011 . 38059) (nil fontified nil 37995 . 38011) (nil fontified nil 37993 . 37995) (nil fontified nil 37951 . 37993) (nil fontified nil 37935 . 37951) (nil fontified nil 37933 . 37935) (nil fontified nil 37895 . 37933) (nil fontified nil 37879 . 37895) (nil fontified nil 37877 . 37879) (nil fontified nil 37845 . 37877) (nil fontified nil 37829 . 37845) (nil fontified nil 37827 . 37829) (nil fontified nil 37780 . 37827) (nil fontified nil 37764 . 37780) (nil fontified nil 37762 . 37764) (nil fontified nil 37728 . 37762) (nil fontified nil 37712 . 37728) (nil fontified nil 37710 . 37712) (nil fontified nil 37663 . 37710) (nil fontified nil 37647 . 37663) (nil fontified nil 37645 . 37647) (nil fontified nil 37606 . 37645) (nil fontified nil 37590 . 37606) (nil fontified nil 37588 . 37590) (nil fontified nil 37557 . 37588) (nil fontified nil 37541 . 37557) (nil fontified nil 37539 . 37541) (nil fontified nil 37503 . 37539) (nil fontified nil 37487 . 37503) (nil fontified nil 37485 . 37487) (nil fontified nil 37463 . 37485) (nil fontified nil 37447 . 37463) (nil fontified nil 37445 . 37447) (nil fontified nil 37405 . 37445) (nil fontified nil 37389 . 37405) (nil fontified nil 37387 . 37389) (nil fontified nil 37367 . 37387) (nil fontified nil 37351 . 37367) (nil fontified nil 37349 . 37351) (nil fontified nil 37325 . 37349) (nil fontified nil 37309 . 37325) (nil fontified nil 37307 . 37309) (nil fontified nil 37291 . 37307) (nil fontified nil 37275 . 37291) (nil fontified nil 37274 . 37275) (nil fontified nil 37273 . 37274) (nil fontified nil 37270 . 37273) (nil fontified nil 37261 . 37270) (nil fontified nil 37257 . 37261) (nil fontified nil 37253 . 37257) (37253 . 38690) nil ("questions = [\"Where are you now?\", \"Do you have any plans to travel?\", \"Are you currently traveling?\", \"What was your favorite place to travel?\", \"Where are you headed?\", \"Have you been on any recent trips?\", \"Are you exploring any new destinations?\", \"What's your dream travel destination?\", \"Do you prefer solo travel or traveling with companions?\", \"Have you ever traveled for work?\", \"What's the most memorable travel experience you've had?\", \"Are you a fan of adventure travel?\", \"What's your go-to travel packing tip?\", \"Have you ever experienced culture shock while traveling?\", \"Do you enjoy trying local cuisines while on a trip?\", \"What's your favorite mode of transportation when traveling?\", \"Have you ever traveled off the beaten path?\", \"Do you prefer staying in hotels or using alternative accommodations?\", \"What's the longest trip you've ever taken?\", \"Do you have any upcoming travel plans?\", \"What's the most beautiful place you've visited?\", \"Have you ever traveled for a special occasion?\", \"Do you keep a travel journal or document your trips in any way?\", \"What's the most challenging aspect of travel for you?\", \"Do you have any tips for saving money while traveling?\"]" . 37253) (t 25704 11991 975388 703000) nil (38447 . 39905) nil ("        questions = [
                \"Where are you?\",
                \"Do you plan to travel?\",
                \"Are you traveling?\",
                \"What was your favorite place to visit?\",
                \"Where are you going?\",
                \"Have you been on any recent trips?\",
                \"Are you exploring new places?\",
                \"What's your dream travel destination?\",
                \"Do you prefer solo travel or with companions?\",
                \"Have you ever traveled for work?\",
                \"What's your most memorable travel experience?\",
                \"Are you an adventure traveler?\",
                \"What's your best travel packing tip?\",
                \"Have you ever experienced culture shock?\",
                \"Do you like to try local food when you travel?\",
                \"What's your favorite way to travel?\",
                \"Have you ever traveled off the beaten path?\",
                \"Do you prefer hotels or alternative accommodations?\",
                \"What's the longest trip you've ever taken?\",
                \"Do you have any upcoming trips?\",
                \"What's the most beautiful place you've seen?\",
                \"Have you ever traveled for a special occasion?\",
                \"Do you keep a travel journal?\",
                \"What's the most challenging part of travel for you?\",
                \"Do you have any tips for saving money on travel?\",
        ]" . 38447) (nil fontified t 38468 . 38469) (nil fontified t 38501 . 38503) (nil fontified t 38543 . 38545) (nil fontified t 38581 . 38583) (nil fontified t 38639 . 38641) (nil fontified t 38679 . 38681) (nil fontified t 38733 . 38735) (nil fontified t 38782 . 38784) (nil fontified t 38839 . 38841) (nil fontified t 38904 . 38906) (nil fontified t 38956 . 38958) (nil fontified t 39021 . 39023) (nil fontified t 39071 . 39073) (nil fontified t 39127 . 39129) (nil fontified t 39187 . 39189) (nil fontified t 39253 . 39255) (nil fontified t 39308 . 39310) (nil fontified t 39371 . 39373) (nil fontified t 39442 . 39444) (nil fontified t 39504 . 39506) (nil fontified t 39555 . 39557) (nil fontified t 39619 . 39621) (nil fontified t 39685 . 39687) (nil fontified t 39734 . 39736) (nil fontified t 39805 . 39807) (nil fontified t 39873 . 39875) (nil fontified t 39883 . 39884) nil (nil fontified nil 39883 . 39884) (nil fontified nil 39875 . 39883) (nil fontified nil 39873 . 39875) (nil fontified nil 39823 . 39873) (nil fontified nil 39807 . 39823) (nil fontified nil 39805 . 39807) (nil fontified nil 39752 . 39805) (nil fontified nil 39736 . 39752) (nil fontified nil 39734 . 39736) (nil fontified nil 39703 . 39734) (nil fontified nil 39687 . 39703) (nil fontified nil 39685 . 39687) (nil fontified nil 39637 . 39685) (nil fontified nil 39621 . 39637) (nil fontified nil 39619 . 39621) (nil fontified nil 39573 . 39619) (nil fontified nil 39557 . 39573) (nil fontified nil 39555 . 39557) (nil fontified nil 39522 . 39555) (nil fontified nil 39506 . 39522) (nil fontified nil 39504 . 39506) (nil fontified nil 39460 . 39504) (nil fontified nil 39444 . 39460) (nil fontified nil 39442 . 39444) (nil fontified nil 39389 . 39442) (nil fontified nil 39373 . 39389) (nil fontified nil 39371 . 39373) (nil fontified nil 39326 . 39371) (nil fontified nil 39310 . 39326) (nil fontified nil 39308 . 39310) (nil fontified nil 39271 . 39308) (nil fontified nil 39255 . 39271) (nil fontified nil 39253 . 39255) (nil fontified nil 39205 . 39253) (nil fontified nil 39189 . 39205) (nil fontified nil 39187 . 39189) (nil fontified nil 39145 . 39187) (nil fontified nil 39129 . 39145) (nil fontified nil 39127 . 39129) (nil fontified nil 39089 . 39127) (nil fontified nil 39073 . 39089) (nil fontified nil 39071 . 39073) (nil fontified nil 39039 . 39071) (nil fontified nil 39023 . 39039) (nil fontified nil 39021 . 39023) (nil fontified nil 38974 . 39021) (nil fontified nil 38958 . 38974) (nil fontified nil 38956 . 38958) (nil fontified nil 38922 . 38956) (nil fontified nil 38906 . 38922) (nil fontified nil 38904 . 38906) (nil fontified nil 38857 . 38904) (nil fontified nil 38841 . 38857) (nil fontified nil 38839 . 38841) (nil fontified nil 38800 . 38839) (nil fontified nil 38784 . 38800) (nil fontified nil 38782 . 38784) (nil fontified nil 38751 . 38782) (nil fontified nil 38735 . 38751) (nil fontified nil 38733 . 38735) (nil fontified nil 38697 . 38733) (nil fontified nil 38681 . 38697) (nil fontified nil 38679 . 38681) (nil fontified nil 38657 . 38679) (nil fontified nil 38641 . 38657) (nil fontified nil 38639 . 38641) (nil fontified nil 38599 . 38639) (nil fontified nil 38583 . 38599) (nil fontified nil 38581 . 38583) (nil fontified nil 38561 . 38581) (nil fontified nil 38545 . 38561) (nil fontified nil 38543 . 38545) (nil fontified nil 38519 . 38543) (nil fontified nil 38503 . 38519) (nil fontified nil 38501 . 38503) (nil fontified nil 38485 . 38501) (nil fontified nil 38469 . 38485) (nil fontified nil 38468 . 38469) (nil fontified nil 38467 . 38468) (nil fontified nil 38464 . 38467) (nil fontified nil 38455 . 38464) (nil fontified nil 38451 . 38455) (nil fontified nil 38447 . 38451) (38447 . 39884) nil ("        conv = [
                \"I've heard you're getting into traveling.\",
                \"I've heard you're planning some exciting trips.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"Rumor has it that you're embarking on new adventures.\",
                \"I've heard you've become quite the globetrotter.\",
                \"Word on the street is you're embracing the wanderlust.\",
                \"I've heard whispers of your travel escapades.\",
                \"I've been informed you're jetting off to new destinations.\",
                \"Seems like you're diving headfirst into the world of travel.\",
                \"I've heard you're immersing yourself in different cultures.\",
                \"I've been told you're discovering the beauty of travel.\",
                \"So, I hear you're filling your passport with stamps.\",
                \"Word has it that you're exploring the unknown.\",
                \"I've heard tales of your travel adventures.\",
                \"I've been informed you're venturing into uncharted territories.\",
                \"Seems like you're on a quest to see the world.\",
                \"I've heard you're collecting memories from around the globe.\",
                \"I've been told you're creating a travel story worth sharing.\",
                \"So, I hear you're embarking on a journey of a lifetime.\"
        ]" . 38447) (t 25704 11991 975388 703000) nil (41947 . 43384) nil ("        questions = [
                \"Where are you?\",
                \"Do you plan to travel?\",
                \"Are you traveling?\",
                \"What was your favorite place to visit?\",
                \"Where are you going?\",
                \"Have you been on any recent trips?\",
                \"Are you exploring new places?\",
                \"What's your dream travel destination?\",
                \"Do you prefer solo travel or with companions?\",
                \"Have you ever traveled for work?\",
                \"What's your most memorable travel experience?\",
                \"Are you an adventure traveler?\",
                \"What's your best travel packing tip?\",
                \"Have you ever experienced culture shock?\",
                \"Do you like to try local food when you travel?\",
                \"What's your favorite way to travel?\",
                \"Have you ever traveled off the beaten path?\",
                \"Do you prefer hotels or alternative accommodations?\",
                \"What's the longest trip you've ever taken?\",
                \"Do you have any upcoming trips?\",
                \"What's the most beautiful place you've seen?\",
                \"Have you ever traveled for a special occasion?\",
                \"Do you keep a travel journal?\",
                \"What's the most challenging part of travel for you?\",
                \"Do you have any tips for saving money on travel?\",
        ]" . 41947) (t 25704 11991 975388 703000) nil (43375 . 43383) 43376 nil (43307 . 43323) ("  " . 43307) 43360 nil (43236 . 43252) ("  " . 43236) 43284 nil (43187 . 43203) ("  " . 43187) 43221 nil (43121 . 43137) ("  " . 43121) 43172 nil (43057 . 43073) ("  " . 43057) 43106 nil (43006 . 43022) ("  " . 43006) 43042 nil (42944 . 42960) ("  " . 42944) 42991 nil (42873 . 42889) ("  " . 42873) 42929 nil (42810 . 42826) ("  " . 42810) 42858 nil (42755 . 42771) ("  " . 42755) 42795 nil (42689 . 42705) ("  " . 42689) 42740 nil (42629 . 42645) ("  " . 42629) 42674 nil (42573 . 42589) ("  " . 42573) 42614 nil (42523 . 42539) ("  " . 42523) 42558 nil (42458 . 42474) ("  " . 42458) 42508 nil (42406 . 42422) ("  " . 42406) 42443 nil (42341 . 42357) ("  " . 42341) 42391 nil (42284 . 42300) ("  " . 42284) 42326 nil (42235 . 42251) ("  " . 42235) 42269 nil (42181 . 42197) ("  " . 42181) 42220 nil (42141 . 42157) ("  " . 42141) 42166 nil (42083 . 42099) ("  " . 42083) 42120 nil (42045 . 42061) ("  " . 42045) 42068 nil (42003 . 42019) ("  " . 42003) 42025 nil (41969 . 41985) ("  " . 41969) 41976 nil (nil rear-nonsticky nil 43025 . 43026) (nil fontified nil 41955 . 43026) (41955 . 43026) nil ("questions = [\"Where are you now?\", \"Do you have any plans to travel?\", \"Are you currently traveling?\", \"What was your favorite place to travel?\", \"Where are you headed?\", \"Have you been on any recent trips?\", \"Are you exploring any new destinations?\", \"What's your dream travel destination?\", \"Do you prefer solo travel or traveling with companions?\", \"Have you ever traveled for work?\", \"What's the most memorable travel experience you've had?\", \"Are you a fan of adventure travel?\", \"What's your go-to travel packing tip?\", \"Have you ever experienced culture shock while traveling?\", \"Do you enjoy trying local cuisines while on a trip?\", \"What's your favorite mode of transportation when traveling?\", \"Have you ever traveled off the beaten path?\", \"Do you prefer staying in hotels or using alternative accommodations?\", \"What's the longest trip you've ever taken?\", \"Do you have any upcoming travel plans?\", \"What's the most beautiful place you've visited?\", \"Have you ever traveled for a special occasion?\", \"Do you keep a travel journal or document your trips in any way?\", \"What's the most challenging aspect of travel for you?\", \"Do you have any tips for saving money while traveling?\"]" . 41955) (t 25704 11936 88639 198000) nil (" " . -43296) 43297 nil ("," . -43296) 43297 nil ("Long time no see" . 43296) (t 25704 11892 445239 69000) nil ("
                \"I've heard you're planning some exciting trips.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"Rumor has it that you're embarking on new adventures.\",
                \"I've heard you've become quite the globetrotter.\",
                \"Word on the street is you're embracing the wanderlust.\",
                \"I've heard whispers of your travel escapades.\",
                \"I've been informed you're jetting off to new destinations.\",
                \"Seems like you're diving headfirst into the world of travel.\",
                \"I've heard you're immersing yourself in different cultures.\",
                \"I've been told you're discovering the beauty of travel.\",
                \"So, I hear you're filling your passport with stamps.\",
                \"Word has it that you're exploring the unknown.\",
                \"I've heard tales of your travel adventures.\",
                \"I've been informed you're venturing into uncharted territories.\",
                \"Seems like you're on a quest to see the world.\",
                \"I've heard you're collecting memories from around the globe.\",
                \"I've been told you're creating a travel story worth sharing.\",
                \"So, I hear you're embarking on a journey of a lifetime.\"
" . 43226) (t 25704 11871 11872 201000) nil ("!" . 44845) nil (41409 . 44757) nil (41408 . 41409) nil ("
        " . 41630) nil ("elif(" . 41639) (41643 . 41644) ("()" . 41643) nil ("prevmess == \"complete\" and get_data(\"previous-post\",message.from)" . 41644) nil (")" . 41708) (41708 . 41709) nil (41708 . 41709) nil (")" . 41708) (41708 . 41709) (" " . 41708) (41708 . 41709) (")" . 41708) (41709 . 41710) (")" . 41709) nil ("z" . 41709) nil (41709 . 41710) nil (41709 . 41710) (")" . 41709) (41708 . 41709) (" " . 41708) (41708 . 41709) (")" . 41708) (41708 . 41709) nil (")" . 41708) nil (")" . 41708) (41708 . 41709) nil (41644 . 41709) nil (41643 . 41645) ("(" . 41643) (41639 . 41644) nil (41630 . 41639) nil ("
" . 41408) nil ("        name_list = generate_names()
        user_name, bot_name = select_names(name_list)
        user_name = get_data(\"name\",message.from_user.id)
        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [\"Where are you now?\", \"Do you have any plans to travel?\", \"Are you currently traveling?\", \"What was your favorite place to travel?\", \"Where are you headed?\", \"Have you been on any recent trips?\", \"Are you exploring any new destinations?\", \"What's your dream travel destination?\", \"Do you prefer solo travel or traveling with companions?\", \"Have you ever traveled for work?\", \"What's the most memorable travel experience you've had?\", \"Are you a fan of adventure travel?\", \"What's your go-to travel packing tip?\", \"Have you ever experienced culture shock while traveling?\", \"Do you enjoy trying local cuisines while on a trip?\", \"What's your favorite mode of transportation when traveling?\", \"Have you ever traveled off the beaten path?\", \"Do you prefer staying in hotels or using alternative accommodations?\", \"What's the longest trip you've ever taken?\", \"Do you have any upcoming travel plans?\", \"What's the most beautiful place you've visited?\", \"Have you ever traveled for a special occasion?\", \"Do you keep a travel journal or document your trips in any way?\", \"What's the most challenging aspect of travel for you?\", \"Do you have any tips for saving money while traveling?\"]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"I've heard you're planning some exciting trips.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"Rumor has it that you're embarking on new adventures.\",
                \"I've heard you've become quite the globetrotter.\",
                \"Word on the street is you're embracing the wanderlust.\",
                \"I've heard whispers of your travel escapades.\",
                \"I've been informed you're jetting off to new destinations.\",
                \"Seems like you're diving headfirst into the world of travel.\",
                \"I've heard you're immersing yourself in different cultures.\",
                \"I've been told you're discovering the beauty of travel.\",
                \"So, I hear you're filling your passport with stamps.\",
                \"Word has it that you're exploring the unknown.\",
                \"I've heard tales of your travel adventures.\",
                \"I've been informed you're venturing into uncharted territories.\",
                \"Seems like you're on a quest to see the world.\",
                \"I've heard you're collecting memories from around the globe.\",
                \"I've been told you're creating a travel story worth sharing.\",
                \"So, I hear you're embarking on a journey of a lifetime.\"
        ]
        usr_start = f\"{random.choice(greeting)} {bot_name}! Long time no see, It's me, {user_name}! {random.choice(conv)} {random.choice(questions)}\"" . 41409) nil (44845 . 44846) nil (44845 . 44850) (44844 . 44846) ("\"" . 44844) (44844 . 44845) nil (41409 . 44971) nil ("
name_list = generate_names()
user_name, bot_name = select_names(name_list)
greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\"]
conv = [
\"I've heard you're getting into traveling.\",
\"So, I hear you're exploring the world now.\",
\"Rumor has it that you're embarking on new adventures.\",
\"I've heard you've become quite the globetrotter.\",
\"Word on the street is you're embracing the wanderlust.\",
\"I've heard whispers of your travel escapades.\",
\"Seems like you're diving headfirst into the world of travel.\",
\"I've heard you're immersing yourself in different cultures.\",
\"I've been told you're discovering the beauty of travel.\",
\"So, I hear you're filling your passport with stamps.\",
\"Word has it that you're exploring the unknown.\",
\"I've heard tales of your travel adventures.\",
\"I've been informed you're venturing into uncharted territories.\",
\"Seems like you're on a quest to see the world.\",
\"I've heard you're collecting memories from around the globe.\",
\"I've been told you're creating a travel story worth sharing.\",
\"So, I hear you're embarking on a journey of a lifetime.\"
]

usr_start = f\"{random.choice(greeting)}, {bot_name}! It's me, {user_name}! {random.choice(conv)}\"
kbd = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True)
kbd.row(\"!Go back\")
await bot.send_message(message.chat.id, text=usr_start, reply_markup=kbd, parse_mode=\"Markdown\")" . 41409) (nil fontified t 42764 . 42765) (nil fontified t 42763 . 42764) (nil fontified t 42753 . 42763) (nil fontified t 42752 . 42753) (nil fontified t 42745 . 42752) (nil fontified t 42744 . 42745) (nil fontified t 42743 . 42744) (nil fontified t 42739 . 42743) (nil fontified t 42723 . 42739) (nil fontified t 42722 . 42723) (nil fontified t 42700 . 42722) (nil fontified t 42686 . 42700) (nil fontified t 42683 . 42686) (nil fontified t 42682 . 42683) (nil fontified t 42681 . 42682) (nil fontified t 42660 . 42681) (nil fontified t 42658 . 42660) (nil fontified t 42647 . 42658) (nil fontified t 42636 . 42647) (nil fontified t 42626 . 42636) (nil fontified t 42624 . 42626) (nil fontified t 42599 . 42624) (nil fontified t 42598 . 42599) (nil fontified t 42594 . 42598) (nil fontified t 42585 . 42594) (nil fontified t 42584 . 42585) (nil fontified t 42583 . 42584) (nil fontified t 42582 . 42583) (nil fontified t 42581 . 42582) (nil fontified t 42524 . 42581) (nil fontified t 42522 . 42524) (nil fontified t 42460 . 42522) (nil fontified t 42458 . 42460) (nil fontified t 42453 . 42458) (nil fontified t 42396 . 42453) (nil fontified t 42395 . 42396) (nil fontified t 42394 . 42395) (nil fontified t 42346 . 42394) (nil fontified t 42344 . 42346) (nil fontified t 42341 . 42344) (nil fontified t 42279 . 42341) (nil fontified t 42278 . 42279) (nil fontified t 42277 . 42278) (nil fontified t 42273 . 42277) (nil fontified t 42265 . 42273) (nil fontified t 42232 . 42265) (nil fontified t 42231 . 42232) (nil fontified t 42230 . 42231) (nil fontified t 42182 . 42230) (nil fontified t 42181 . 42182) (nil fontified t 42180 . 42181) (nil fontified t 42126 . 42180) (nil fontified t 42125 . 42126) (nil fontified t 42124 . 42125) (nil fontified t 42067 . 42124) (nil fontified t 42066 . 42067) (nil fontified t 42065 . 42066) (nil fontified t 42004 . 42065) (nil fontified t 42003 . 42004) (nil fontified t 42002 . 42003) (nil fontified t 41940 . 42002) (nil fontified t 41938 . 41940) (nil fontified t 41891 . 41938) (nil fontified t 41889 . 41891) (nil fontified t 41833 . 41889) (nil fontified t 41832 . 41833) (nil fontified t 41831 . 41832) (nil fontified t 41781 . 41831) (nil fontified t 41779 . 41781) (nil fontified t 41772 . 41779) (nil fontified t 41724 . 41772) (nil fontified t 41722 . 41724) (nil fontified t 41710 . 41722) (nil fontified t 41678 . 41710) (nil fontified t 41676 . 41678) (nil fontified t 41649 . 41676) (nil fontified t 41633 . 41649) (nil fontified t 41632 . 41633) (nil fontified t 41631 . 41632) (nil fontified t 41628 . 41631) (nil fontified t 41624 . 41628) (nil fontified t 41623 . 41624) (nil fontified t 41622 . 41623) (nil fontified t 41615 . 41622) (nil fontified t 41613 . 41615) (nil fontified t 41602 . 41613) (nil fontified t 41600 . 41602) (nil fontified t 41586 . 41600) (nil fontified t 41584 . 41586) (nil fontified t 41568 . 41584) (nil fontified t 41566 . 41568) (nil fontified t 41552 . 41566) (nil fontified t 41550 . 41552) (nil fontified t 41540 . 41550) (nil fontified t 41538 . 41540) (nil fontified t 41532 . 41538) (nil fontified t 41530 . 41532) (nil fontified t 41519 . 41530) (nil fontified t 41517 . 41519) (nil fontified t 41512 . 41517) (nil fontified t 41510 . 41512) (nil fontified t 41503 . 41510) (nil fontified t 41501 . 41503) (nil fontified t 41497 . 41501) (nil fontified t 41496 . 41497) (nil fontified t 41493 . 41496) (nil fontified t 41485 . 41493) (nil fontified t 41484 . 41485) (nil fontified t 41483 . 41484) (nil fontified t 41474 . 41483) (nil fontified t 41473 . 41474) (nil fontified t 41458 . 41473) (nil fontified t 41450 . 41458) (nil fontified t 41448 . 41450) (nil fontified t 41447 . 41448) (nil fontified t 41439 . 41447) (nil fontified t 41438 . 41439) (nil fontified t 41437 . 41438) (nil fontified t 41436 . 41437) (nil fontified t 41419 . 41436) (nil fontified t 41410 . 41419) (nil fontified t 41409 . 41410) (nil rear-nonsticky t 42860 . 42861) nil ("        " . 41410) nil ("        " . 41447) nil ("        " . 41501) nil (41501 . 41509) nil ("        " . 41501) nil ("        " . 41648) nil ("                " . 41665) nil ("                " . 41726) nil ("                " . 41788) nil ("                " . 41861) nil (41869 . 41877) nil ("                " . 41979) nil ("                " . 41921) nil (41861 . 41869) ("                " . 41861) nil ("                " . 42068) nil ("                " . 42148) nil ("                " . 42227) nil ("                " . 42302) nil ("                " . 42374) nil (42382 . 42390) nil (42374 . 42382) nil ("                " . 42374) nil ("                " . 42440) nil ("                " . 42503) nil ("                " . 42586) nil (42594 . 42602) nil (42448 . 42456) nil (42503 . 42511) nil (42440 . 42448) ("                " . 42440) nil (42448 . 42456) nil (42440 . 42448) nil (42487 . 42495) ("                " . 42487) nil (42495 . 42503) nil (42487 . 42495) nil ("                " . 42487) nil ("                " . 42440) nil ("                " . 42644) nil ("                " . 42724) nil (42586 . 42594) ("                " . 42586) nil ("                " . 42812) nil ("        " . 42886) nil ("        " . 42897) nil ("        " . 43003) nil ("        " . 43073) nil ("        " . 43101) (t 25704 11818 721788 206000) nil (43101 . 43109) 43128 nil (43073 . 43081) 43092 nil (43003 . 43011) 43020 nil (42897 . 42905) 42906 nil (42886 . 42894) 42887 nil (42812 . 42828) 42869 nil (42586 . 42602) ("        " . 42586) 42643 nil (42724 . 42740) 42787 nil (42644 . 42660) 42701 nil (42440 . 42456) 42481 nil (42487 . 42503) 42512 nil ("        " . -42487) 42520 nil ("        " . -42495) 42528 nil (42487 . 42503) ("        " . 42487) 42520 nil ("        " . -42440) 42481 nil ("        " . -42448) 42489 nil (42440 . 42456) ("        " . 42440) 42481 nil ("        " . -42503) 42544 nil ("        " . -42448) 42497 nil ("        " . -42594) 42651 nil (42586 . 42602) 42635 nil (42503 . 42519) 42565 nil (42440 . 42456) 42486 nil (42374 . 42390) 42423 nil ("        " . -42374) 42431 nil ("        " . -42382) 42439 nil (42374 . 42390) 42423 nil (42302 . 42318) 42357 nil (42227 . 42243) 42285 nil (42148 . 42164) 42210 nil (42068 . 42084) 42131 nil (41861 . 41877) ("        " . 41861) 41920 nil (41921 . 41937) 41978 nil (41979 . 41995) 42027 nil ("        " . -41869) 41928 nil (41861 . 41877) 41912 nil (41788 . 41804) 41836 nil (41726 . 41742) 41758 nil (41665 . 41681) 41681 nil (41648 . 41656) 41656 nil (41501 . 41509) 41509 nil ("        " . -41501) 41525 nil (41501 . 41509) 41517 nil (41447 . 41455) 41455 nil (41410 . 41418) nil (nil rear-nonsticky nil 42860 . 42861) (nil fontified nil 41409 . 42861) (41409 . 42861) nil ("        name_list = generate_names()
        user_name, bot_name = select_names(name_list)
        user_name = get_data(\"name\",message.from_user.id)
        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [\"Where are you now?\", \"Do you have any plans to travel?\", \"Are you currently traveling?\", \"What was your favorite place to travel?\", \"Where are you headed?\", \"Have you been on any recent trips?\", \"Are you exploring any new destinations?\", \"What's your dream travel destination?\", \"Do you prefer solo travel or traveling with companions?\", \"Have you ever traveled for work?\", \"What's the most memorable travel experience you've had?\", \"Are you a fan of adventure travel?\", \"What's your go-to travel packing tip?\", \"Have you ever experienced culture shock while traveling?\", \"Do you enjoy trying local cuisines while on a trip?\", \"What's your favorite mode of transportation when traveling?\", \"Have you ever traveled off the beaten path?\", \"Do you prefer staying in hotels or using alternative accommodations?\", \"What's the longest trip you've ever taken?\", \"Do you have any upcoming travel plans?\", \"What's the most beautiful place you've visited?\", \"Have you ever traveled for a special occasion?\", \"Do you keep a travel journal or document your trips in any way?\", \"What's the most challenging aspect of travel for you?\", \"Do you have any tips for saving money while traveling?\"]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"I've heard you're planning some exciting trips.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"Rumor has it that you're embarking on new adventures.\",
                \"I've heard you've become quite the globetrotter.\",
                \"Word on the street is you're embracing the wanderlust.\",
                \"I've heard whispers of your travel escapades.\",
                \"I've been informed you're jetting off to new destinations.\",
                \"Seems like you're diving headfirst into the world of travel.\",
                \"I've heard you're immersing yourself in different cultures.\",
                \"I've been told you're discovering the beauty of travel.\",
                \"So, I hear you're filling your passport with stamps.\",
                \"Word has it that you're exploring the unknown.\",
                \"I've heard tales of your travel adventures.\",
                \"I've been informed you're venturing into uncharted territories.\",
                \"Seems like you're on a quest to see the world.\",
                \"I've heard you're collecting memories from around the globe.\",
                \"I've been told you're creating a travel story worth sharing.\",
                \"So, I hear you're embarking on a journey of a lifetime.\"
        ]
        usr_start = f\"{random.choice(greeting)} {bot_name}! Long time no see, It's me, {user_name}! {random.choice(conv)} {random.choice(questions)}\"
        kbd = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True)
        kbd.row()
        kbd.row(\"!Go back\")
        await bot.send_message(message.chat.id, text=send,reply_markup=kbd,parse_mode=\"Markdown\")" . 41409) (t 25704 11560 254649 442000) nil ("\"" . 44844) (44844 . 44845) ("\"\"" . 44844) ("Greet" . 44845) nil ("!" . 44845) nil (41409 . 44757) nil (41408 . 41409) nil ("
        " . 41630) nil ("elif(" . 41639) (41643 . 41644) ("()" . 41643) nil ("prevmess == \"complete\" and get_data(\"previous-post\",message.from)" . 41644) nil (")" . 41708) (41708 . 41709) nil (41708 . 41709) nil (")" . 41708) (41708 . 41709) (" " . 41708) (41708 . 41709) (")" . 41708) (41709 . 41710) (")" . 41709) nil ("_u" . 41708) nil (41704 . 41710) ("from_user.id) == \"Chat���\" and message.text == \"!Greet\"):" . 41704) (41761 . 41763) nil ("
                " . 41761) nil ("        name_list = generate_names()
        user_name, bot_name = select_names(name_list)
        user_name = get_data(\"name\",message.from_user.id)
        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [\"Where are you now?\", \"Do you have any plans to travel?\", \"Are you currently traveling?\", \"What was your favorite place to travel?\", \"Where are you headed?\", \"Have you been on any recent trips?\", \"Are you exploring any new destinations?\", \"What's your dream travel destination?\", \"Do you prefer solo travel or traveling with companions?\", \"Have you ever traveled for work?\", \"What's the most memorable travel experience you've had?\", \"Are you a fan of adventure travel?\", \"What's your go-to travel packing tip?\", \"Have you ever experienced culture shock while traveling?\", \"Do you enjoy trying local cuisines while on a trip?\", \"What's your favorite mode of transportation when traveling?\", \"Have you ever traveled off the beaten path?\", \"Do you prefer staying in hotels or using alternative accommodations?\", \"What's the longest trip you've ever taken?\", \"Do you have any upcoming travel plans?\", \"What's the most beautiful place you've visited?\", \"Have you ever traveled for a special occasion?\", \"Do you keep a travel journal or document your trips in any way?\", \"What's the most challenging aspect of travel for you?\", \"Do you have any tips for saving money while traveling?\"]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"I've heard you're planning some exciting trips.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"Rumor has it that you're embarking on new adventures.\",
                \"I've heard you've become quite the globetrotter.\",
                \"Word on the street is you're embracing the wanderlust.\",
                \"I've heard whispers of your travel escapades.\",
                \"I've been informed you're jetting off to new destinations.\",
                \"Seems like you're diving headfirst into the world of travel.\",
                \"I've heard you're immersing yourself in different cultures.\",
                \"I've been told you're discovering the beauty of travel.\",
                \"So, I hear you're filling your passport with stamps.\",
                \"Word has it that you're exploring the unknown.\",
                \"I've heard tales of your travel adventures.\",
                \"I've been informed you're venturing into uncharted territories.\",
                \"Seems like you're on a quest to see the world.\",
                \"I've heard you're collecting memories from around the globe.\",
                \"I've been told you're creating a travel story worth sharing.\",
                \"So, I hear you're embarking on a journey of a lifetime.\"
        ]
        usr_start = f\"{random.choice(greeting)} {bot_name}! Long time no see, It's me, {user_name}! {random.choice(conv)} {random.choice(questions)}\"" . 41778) (nil fontified t 41814 . 41815) (nil fontified t 41868 . 41869) (nil fontified t 41926 . 41927) (nil fontified t 42315 . 42316) (nil fontified t 43517 . 43518) (nil fontified t 43534 . 43535) (nil fontified t 43594 . 43596) (nil fontified t 43661 . 43663) (nil fontified t 43723 . 43725) (nil fontified t 43789 . 43791) (nil fontified t 43862 . 43864) (nil fontified t 43930 . 43932) (nil fontified t 44004 . 44006) (nil fontified t 44069 . 44071) (nil fontified t 44147 . 44149) (nil fontified t 44227 . 44229) (nil fontified t 44306 . 44308) (nil fontified t 44381 . 44383) (nil fontified t 44453 . 44455) (nil fontified t 44519 . 44521) (nil fontified t 44582 . 44584) (nil fontified t 44665 . 44667) (nil fontified t 44731 . 44733) (nil fontified t 44811 . 44813) (nil fontified t 44891 . 44893) (nil fontified t 44966 . 44967) (nil fontified t 44976 . 44977) (nil fontified t 45125 . 45126) nil (41635 . 41639) nil (41770 . 41782) nil (41766 . 41770) (t 25704 11515 461222 164000) nil ("    " . -41766) 41773 nil ("            " . -41770) 41785 nil ("    " . -41635) 41662 nil (nil fontified nil 45125 . 45126) (nil fontified nil 45124 . 45125) (nil fontified nil 45123 . 45124) (nil fontified nil 45114 . 45123) (nil fontified nil 45113 . 45114) (nil fontified nil 45100 . 45113) (nil fontified nil 45099 . 45100) (nil fontified nil 45098 . 45099) (nil fontified nil 45078 . 45098) (nil fontified nil 45077 . 45078) (nil fontified nil 45076 . 45077) (nil fontified nil 45075 . 45076) (nil fontified nil 45064 . 45075) (nil fontified nil 45036 . 45064) (nil fontified nil 45035 . 45036) (nil fontified nil 45026 . 45035) (nil fontified nil 45025 . 45026) (nil fontified nil 45024 . 45025) (nil fontified nil 45018 . 45024) (nil fontified nil 45013 . 45018) (nil fontified nil 45000 . 45013) (nil fontified nil 44999 . 45000) (nil fontified nil 44998 . 44999) (nil fontified nil 44994 . 44998) (nil fontified nil 44989 . 44994) (nil fontified nil 44985 . 44989) (nil fontified nil 44977 . 44985) (nil fontified nil 44976 . 44977) (nil fontified nil 44975 . 44976) (nil fontified nil 44967 . 44975) (nil fontified nil 44966 . 44967) (nil fontified nil 44909 . 44966) (nil fontified nil 44893 . 44909) (nil fontified nil 44891 . 44893) (nil fontified nil 44829 . 44891) (nil fontified nil 44813 . 44829) (nil fontified nil 44811 . 44813) (nil fontified nil 44749 . 44811) (nil fontified nil 44733 . 44749) (nil fontified nil 44731 . 44733) (nil fontified nil 44683 . 44731) (nil fontified nil 44667 . 44683) (nil fontified nil 44665 . 44667) (nil fontified nil 44600 . 44665) (nil fontified nil 44584 . 44600) (nil fontified nil 44582 . 44584) (nil fontified nil 44537 . 44582) (nil fontified nil 44521 . 44537) (nil fontified nil 44519 . 44521) (nil fontified nil 44471 . 44519) (nil fontified nil 44455 . 44471) (nil fontified nil 44453 . 44455) (nil fontified nil 44399 . 44453) (nil fontified nil 44383 . 44399) (nil fontified nil 44381 . 44383) (nil fontified nil 44324 . 44381) (nil fontified nil 44308 . 44324) (nil fontified nil 44306 . 44308) (nil fontified nil 44245 . 44306) (nil fontified nil 44229 . 44245) (nil fontified nil 44227 . 44229) (nil fontified nil 44165 . 44227) (nil fontified nil 44149 . 44165) (nil fontified nil 44147 . 44149) (nil fontified nil 44087 . 44147) (nil fontified nil 44071 . 44087) (nil fontified nil 44069 . 44071) (nil fontified nil 44022 . 44069) (nil fontified nil 44006 . 44022) (nil fontified nil 44004 . 44006) (nil fontified nil 43948 . 44004) (nil fontified nil 43932 . 43948) (nil fontified nil 43930 . 43932) (nil fontified nil 43880 . 43930) (nil fontified nil 43864 . 43880) (nil fontified nil 43862 . 43864) (nil fontified nil 43807 . 43862) (nil fontified nil 43791 . 43807) (nil fontified nil 43789 . 43791) (nil fontified nil 43741 . 43789) (nil fontified nil 43725 . 43741) (nil fontified nil 43723 . 43725) (nil fontified nil 43679 . 43723) (nil fontified nil 43663 . 43679) (nil fontified nil 43661 . 43663) (nil fontified nil 43612 . 43661) (nil fontified nil 43596 . 43612) (nil fontified nil 43594 . 43596) (nil fontified nil 43551 . 43594) (nil fontified nil 43535 . 43551) (nil fontified nil 43534 . 43535) (nil fontified nil 43533 . 43534) (nil fontified nil 43530 . 43533) (nil fontified nil 43526 . 43530) (nil fontified nil 43518 . 43526) (nil fontified nil 43517 . 43518) (nil fontified nil 43516 . 43517) (nil fontified nil 43460 . 43516) (nil fontified nil 43458 . 43460) (nil fontified nil 43427 . 43458) (nil fontified nil 43403 . 43427) (nil fontified nil 43401 . 43403) (nil fontified nil 43336 . 43401) (nil fontified nil 43334 . 43336) (nil fontified nil 43286 . 43334) (nil fontified nil 43284 . 43286) (nil fontified nil 43235 . 43284) (nil fontified nil 43233 . 43235) (nil fontified nil 43193 . 43233) (nil fontified nil 43191 . 43193) (nil fontified nil 43147 . 43191) (nil fontified nil 43145 . 43147) (nil fontified nil 43075 . 43145) (nil fontified nil 43073 . 43075) (nil fontified nil 43028 . 43073) (nil fontified nil 43026 . 43028) (nil fontified nil 42965 . 43026) (nil fontified nil 42963 . 42965) (nil fontified nil 42910 . 42963) (nil fontified nil 42908 . 42910) (nil fontified nil 42850 . 42908) (nil fontified nil 42848 . 42850) (nil fontified nil 42809 . 42848) (nil fontified nil 42807 . 42809) (nil fontified nil 42771 . 42807) (nil fontified nil 42769 . 42771) (nil fontified nil 42712 . 42769) (nil fontified nil 42710 . 42712) (nil fontified nil 42676 . 42710) (nil fontified nil 42674 . 42676) (nil fontified nil 42617 . 42674) (nil fontified nil 42615 . 42617) (nil fontified nil 42576 . 42615) (nil fontified nil 42574 . 42576) (nil fontified nil 42533 . 42574) (nil fontified nil 42531 . 42533) (nil fontified nil 42495 . 42531) (nil fontified nil 42493 . 42495) (nil fontified nil 42470 . 42493) (nil fontified nil 42468 . 42470) (nil fontified nil 42427 . 42468) (nil fontified nil 42425 . 42427) (nil fontified nil 42395 . 42425) (nil fontified nil 42393 . 42395) (nil fontified nil 42359 . 42393) (nil fontified nil 42357 . 42359) (nil fontified nil 42355 . 42357) (nil fontified nil 42337 . 42355) (nil fontified nil 42336 . 42337) (nil fontified nil 42333 . 42336) (nil fontified nil 42324 . 42333) (nil fontified nil 42320 . 42324) (nil fontified nil 42316 . 42320) (nil fontified nil 42315 . 42316) (nil fontified nil 42314 . 42315) (nil fontified nil 42285 . 42314) (nil fontified nil 42283 . 42285) (nil fontified nil 42260 . 42283) (nil fontified nil 42258 . 42260) (nil fontified nil 42240 . 42258) (nil fontified nil 42238 . 42240) (nil fontified nil 42216 . 42238) (nil fontified nil 42214 . 42216) (nil fontified nil 42198 . 42214) (nil fontified nil 42196 . 42198) (nil fontified nil 42178 . 42196) (nil fontified nil 42176 . 42178) (nil fontified nil 42152 . 42176) (nil fontified nil 42150 . 42152) (nil fontified nil 42129 . 42150) (nil fontified nil 42127 . 42129) (nil fontified nil 42114 . 42127) (nil fontified nil 42112 . 42114) (nil fontified nil 42102 . 42112) (nil fontified nil 42100 . 42102) (nil fontified nil 42093 . 42100) (nil fontified nil 42091 . 42093) (nil fontified nil 42080 . 42091) (nil fontified nil 42078 . 42080) (nil fontified nil 42064 . 42078) (nil fontified nil 42062 . 42064) (nil fontified nil 42046 . 42062) (nil fontified nil 42044 . 42046) (nil fontified nil 42030 . 42044) (nil fontified nil 42028 . 42030) (nil fontified nil 42018 . 42028) (nil fontified nil 42016 . 42018) (nil fontified nil 42003 . 42016) (nil fontified nil 42001 . 42003) (nil fontified nil 41990 . 42001) (nil fontified nil 41988 . 41990) (nil fontified nil 41982 . 41988) (nil fontified nil 41980 . 41982) (nil fontified nil 41969 . 41980) (nil fontified nil 41967 . 41969) (nil fontified nil 41962 . 41967) (nil fontified nil 41960 . 41962) (nil fontified nil 41953 . 41960) (nil fontified nil 41951 . 41953) (nil fontified nil 41947 . 41951) (nil fontified nil 41946 . 41947) (nil fontified nil 41943 . 41946) (nil fontified nil 41935 . 41943) (nil fontified nil 41927 . 41935) (nil fontified nil 41926 . 41927) (nil fontified nil 41925 . 41926) (nil fontified nil 41923 . 41925) (nil fontified nil 41904 . 41923) (nil fontified nil 41903 . 41904) (nil fontified nil 41898 . 41903) (nil fontified nil 41897 . 41898) (nil fontified nil 41886 . 41897) (nil fontified nil 41877 . 41886) (nil fontified nil 41869 . 41877) (nil fontified nil 41868 . 41869) (nil fontified nil 41867 . 41868) (nil fontified nil 41858 . 41867) (nil fontified nil 41857 . 41858) (nil fontified nil 41842 . 41857) (nil fontified nil 41834 . 41842) (nil fontified nil 41832 . 41834) (nil fontified nil 41823 . 41832) (nil fontified nil 41815 . 41823) (nil fontified nil 41814 . 41815) (nil fontified nil 41813 . 41814) (nil fontified nil 41812 . 41813) (nil fontified nil 41795 . 41812) (nil fontified nil 41786 . 41795) (nil fontified nil 41778 . 41786) (41778 . 45126) nil (41761 . 41778) nil ("))" . 41761) (41704 . 41761) ("from_u" . -41704) 41710 nil (41708 . 41710) nil (41709 . 41710) (")" . 41709) (41708 . 41709) (" " . -41708) (41708 . 41709) (")" . -41708) (41708 . 41709) nil (")" . -41708) 41709 nil (")" . -41708) (41708 . 41709) nil (41644 . 41709) nil (41643 . 41645) ("(" . -41643) (41639 . 41644) nil (41630 . 41639) (t 25704 11489 214498 403000) nil ("
" . -41408) 41409 nil ("        name_list = generate_names()
        user_name, bot_name = select_names(name_list)
        user_name = get_data(\"name\",message.from_user.id)
        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [\"Where are you now?\", \"Do you have any plans to travel?\", \"Are you currently traveling?\", \"What was your favorite place to travel?\", \"Where are you headed?\", \"Have you been on any recent trips?\", \"Are you exploring any new destinations?\", \"What's your dream travel destination?\", \"Do you prefer solo travel or traveling with companions?\", \"Have you ever traveled for work?\", \"What's the most memorable travel experience you've had?\", \"Are you a fan of adventure travel?\", \"What's your go-to travel packing tip?\", \"Have you ever experienced culture shock while traveling?\", \"Do you enjoy trying local cuisines while on a trip?\", \"What's your favorite mode of transportation when traveling?\", \"Have you ever traveled off the beaten path?\", \"Do you prefer staying in hotels or using alternative accommodations?\", \"What's the longest trip you've ever taken?\", \"Do you have any upcoming travel plans?\", \"What's the most beautiful place you've visited?\", \"Have you ever traveled for a special occasion?\", \"Do you keep a travel journal or document your trips in any way?\", \"What's the most challenging aspect of travel for you?\", \"Do you have any tips for saving money while traveling?\"]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"I've heard you're planning some exciting trips.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"Rumor has it that you're embarking on new adventures.\",
                \"I've heard you've become quite the globetrotter.\",
                \"Word on the street is you're embracing the wanderlust.\",
                \"I've heard whispers of your travel escapades.\",
                \"I've been informed you're jetting off to new destinations.\",
                \"Seems like you're diving headfirst into the world of travel.\",
                \"I've heard you're immersing yourself in different cultures.\",
                \"I've been told you're discovering the beauty of travel.\",
                \"So, I hear you're filling your passport with stamps.\",
                \"Word has it that you're exploring the unknown.\",
                \"I've heard tales of your travel adventures.\",
                \"I've been informed you're venturing into uncharted territories.\",
                \"Seems like you're on a quest to see the world.\",
                \"I've heard you're collecting memories from around the globe.\",
                \"I've been told you're creating a travel story worth sharing.\",
                \"So, I hear you're embarking on a journey of a lifetime.\"
        ]
        usr_start = f\"{random.choice(greeting)} {bot_name}! Long time no see, It's me, {user_name}! {random.choice(conv)} {random.choice(questions)}\"" . 41409) 44757 (t 25704 11456 721092 146000) nil (44845 . 44846) nil (44845 . 44850) (44844 . 44846) ("\"" . -44844) (44844 . 44845) nil ("!" . -44844) ("G" . -44845) 44846 nil (44844 . 44846) nil ("usr_start" . 44844) (t 25704 11407 637643 610000) nil (nil rear-nonsticky nil 44825 . 44826) (nil fontified nil 44822 . 44826) (nil fontified nil 44806 . 44822) (44806 . 44826) (t 25704 11282 103983 958000) nil (45728 . 45748) nil ("resize_keyboard=True" . 45728) 45748 (t 25704 11282 103983 958000) nil (nil fontified nil 40054 . 40055) (nil fontified nil 40053 . 40054) (nil fontified nil 40052 . 40053) (nil fontified nil 40043 . 40052) (nil fontified nil 40042 . 40043) (nil fontified nil 40029 . 40042) (nil fontified nil 40028 . 40029) (nil fontified nil 40027 . 40028) (nil fontified nil 40007 . 40027) (nil fontified nil 40006 . 40007) (nil fontified nil 40005 . 40006) (nil fontified nil 40004 . 40005) (nil fontified nil 39993 . 40004) (nil fontified nil 39965 . 39993) (nil fontified nil 39964 . 39965) (nil fontified nil 39955 . 39964) (nil fontified nil 39954 . 39955) (nil fontified nil 39953 . 39954) (nil fontified nil 39942 . 39953) (nil fontified nil 39929 . 39942) (nil fontified nil 39928 . 39929) (nil fontified nil 39927 . 39928) (nil fontified nil 39923 . 39927) (nil fontified nil 39918 . 39923) (nil fontified nil 39914 . 39918) (nil fontified nil 39906 . 39914) (nil fontified nil 39905 . 39906) (nil fontified nil 39904 . 39905) (nil fontified nil 39896 . 39904) (nil fontified nil 39895 . 39896) (nil fontified nil 39838 . 39895) (nil fontified nil 39822 . 39838) (nil fontified nil 39820 . 39822) (nil fontified nil 39758 . 39820) (nil fontified nil 39742 . 39758) (nil fontified nil 39740 . 39742) (nil fontified nil 39678 . 39740) (nil fontified nil 39662 . 39678) (nil fontified nil 39660 . 39662) (nil fontified nil 39612 . 39660) (nil fontified nil 39596 . 39612) (nil fontified nil 39594 . 39596) (nil fontified nil 39529 . 39594) (nil fontified nil 39513 . 39529) (nil fontified nil 39511 . 39513) (nil fontified nil 39466 . 39511) (nil fontified nil 39450 . 39466) (nil fontified nil 39448 . 39450) (nil fontified nil 39400 . 39448) (nil fontified nil 39384 . 39400) (nil fontified nil 39382 . 39384) (nil fontified nil 39328 . 39382) (nil fontified nil 39312 . 39328) (nil fontified nil 39310 . 39312) (nil fontified nil 39253 . 39310) (nil fontified nil 39237 . 39253) (nil fontified nil 39235 . 39237) (nil fontified nil 39174 . 39235) (nil fontified nil 39158 . 39174) (nil fontified nil 39156 . 39158) (nil fontified nil 39094 . 39156) (nil fontified nil 39078 . 39094) (nil fontified nil 39076 . 39078) (nil fontified nil 39016 . 39076) (nil fontified nil 39000 . 39016) (nil fontified nil 38998 . 39000) (nil fontified nil 38951 . 38998) (nil fontified nil 38935 . 38951) (nil fontified nil 38933 . 38935) (nil fontified nil 38877 . 38933) (nil fontified nil 38861 . 38877) (nil fontified nil 38859 . 38861) (nil fontified nil 38809 . 38859) (nil fontified nil 38793 . 38809) (nil fontified nil 38791 . 38793) (nil fontified nil 38736 . 38791) (nil fontified nil 38720 . 38736) (nil fontified nil 38718 . 38720) (nil fontified nil 38670 . 38718) (nil fontified nil 38654 . 38670) (nil fontified nil 38652 . 38654) (nil fontified nil 38608 . 38652) (nil fontified nil 38592 . 38608) (nil fontified nil 38590 . 38592) (nil fontified nil 38541 . 38590) (nil fontified nil 38525 . 38541) (nil fontified nil 38523 . 38525) (nil fontified nil 38480 . 38523) (nil fontified nil 38464 . 38480) (nil fontified nil 38463 . 38464) (nil fontified nil 38462 . 38463) (nil fontified nil 38459 . 38462) (nil fontified nil 38455 . 38459) (nil fontified nil 38447 . 38455) (nil fontified nil 38446 . 38447) (nil fontified nil 38445 . 38446) (nil fontified nil 38389 . 38445) (nil fontified nil 38387 . 38389) (nil fontified nil 38332 . 38387) (nil fontified nil 38330 . 38332) (nil fontified nil 38265 . 38330) (nil fontified nil 38263 . 38265) (nil fontified nil 38215 . 38263) (nil fontified nil 38213 . 38215) (nil fontified nil 38164 . 38213) (nil fontified nil 38162 . 38164) (nil fontified nil 38122 . 38162) (nil fontified nil 38120 . 38122) (nil fontified nil 38076 . 38120) (nil fontified nil 38074 . 38076) (nil fontified nil 38004 . 38074) (nil fontified nil 38002 . 38004) (nil fontified nil 37957 . 38002) (nil fontified nil 37955 . 37957) (nil fontified nil 37894 . 37955) (nil fontified nil 37892 . 37894) (nil fontified nil 37839 . 37892) (nil fontified nil 37837 . 37839) (nil fontified nil 37779 . 37837) (nil fontified nil 37777 . 37779) (nil fontified nil 37738 . 37777) (nil fontified nil 37736 . 37738) (nil fontified nil 37700 . 37736) (nil fontified nil 37698 . 37700) (nil fontified nil 37641 . 37698) (nil fontified nil 37639 . 37641) (nil fontified nil 37605 . 37639) (nil fontified nil 37603 . 37605) (nil fontified nil 37546 . 37603) (nil fontified nil 37544 . 37546) (nil fontified nil 37505 . 37544) (nil fontified nil 37503 . 37505) (nil fontified nil 37462 . 37503) (nil fontified nil 37460 . 37462) (nil fontified nil 37424 . 37460) (nil fontified nil 37422 . 37424) (nil fontified nil 37399 . 37422) (nil fontified nil 37397 . 37399) (nil fontified nil 37356 . 37397) (nil fontified nil 37354 . 37356) (nil fontified nil 37324 . 37354) (nil fontified nil 37322 . 37324) (nil fontified nil 37288 . 37322) (nil fontified nil 37286 . 37288) (nil fontified nil 37284 . 37286) (nil fontified nil 37266 . 37284) (nil fontified nil 37265 . 37266) (nil fontified nil 37262 . 37265) (nil fontified nil 37253 . 37262) (nil fontified nil 37249 . 37253) (nil fontified nil 37245 . 37249) (nil fontified nil 37244 . 37245) (nil fontified nil 37243 . 37244) (nil fontified nil 37214 . 37243) (nil fontified nil 37212 . 37214) (nil fontified nil 37189 . 37212) (nil fontified nil 37187 . 37189) (nil fontified nil 37169 . 37187) (nil fontified nil 37167 . 37169) (nil fontified nil 37145 . 37167) (nil fontified nil 37143 . 37145) (nil fontified nil 37127 . 37143) (nil fontified nil 37125 . 37127) (nil fontified nil 37107 . 37125) (nil fontified nil 37105 . 37107) (nil fontified nil 37081 . 37105) (nil fontified nil 37079 . 37081) (nil fontified nil 37058 . 37079) (nil fontified nil 37056 . 37058) (nil fontified nil 37043 . 37056) (nil fontified nil 37041 . 37043) (nil fontified nil 37031 . 37041) (nil fontified nil 37029 . 37031) (nil fontified nil 37022 . 37029) (nil fontified nil 37020 . 37022) (nil fontified nil 37009 . 37020) (nil fontified nil 37007 . 37009) (nil fontified nil 36993 . 37007) (nil fontified nil 36991 . 36993) (nil fontified nil 36975 . 36991) (nil fontified nil 36973 . 36975) (nil fontified nil 36959 . 36973) (nil fontified nil 36957 . 36959) (nil fontified nil 36947 . 36957) (nil fontified nil 36945 . 36947) (nil fontified nil 36932 . 36945) (nil fontified nil 36930 . 36932) (nil fontified nil 36919 . 36930) (nil fontified nil 36917 . 36919) (nil fontified nil 36911 . 36917) (nil fontified nil 36909 . 36911) (nil fontified nil 36898 . 36909) (nil fontified nil 36896 . 36898) (nil fontified nil 36891 . 36896) (nil fontified nil 36889 . 36891) (nil fontified nil 36882 . 36889) (nil fontified nil 36880 . 36882) (nil fontified nil 36876 . 36880) (nil fontified nil 36875 . 36876) (nil fontified nil 36872 . 36875) (nil fontified nil 36864 . 36872) (nil fontified nil 36856 . 36864) (36856 . 40055) nil ("        greeting = [\"Hi\", \"Hello\", \"Hey\", \"How are you\", \"How are you doing\", \"Heya\", \"What's up\"]
        questions = [\"Where are you now?\", \"Do you have any plans to travel?\", \"Are you currently traveling?\", \"What was your favorite place to travel?\"]
        usr_start = f\"{random.choice(greeting)} {bot_name}! Long time no see, It's me, {user_name}! I’ve heard you’re getting into travelling. {random.choice(questions)}\"" . 36856) (t 25704 11233 693844 44000) nil (38782 . 41981) nil ("        greeting = [\"Hi\", \"Hello\", \"Hey\", \"Hey there\", \"Heya\", \"Greetings\", \"Salutations\", \"Good day\", \"Good morning\", \"Good afternoon\", \"Good evening\", \"What's up\", \"Howdy\", \"Hi there\", \"Hello there\", \"Hey, how's it going\", \"Heya, what's happening\", \"How's everything\", \"How are things\", \"Hey, what's going on\", \"Hey, how are you\", \"Hello, how's it going\", \"Hi there, how are you doing\"]
        questions = [\"Where are you now?\", \"Do you have any plans to travel?\", \"Are you currently traveling?\", \"What was your favorite place to travel?\", \"Where are you headed?\", \"Have you been on any recent trips?\", \"Are you exploring any new destinations?\", \"What's your dream travel destination?\", \"Do you prefer solo travel or traveling with companions?\", \"Have you ever traveled for work?\", \"What's the most memorable travel experience you've had?\", \"Are you a fan of adventure travel?\", \"What's your go-to travel packing tip?\", \"Have you ever experienced culture shock while traveling?\", \"Do you enjoy trying local cuisines while on a trip?\", \"What's your favorite mode of transportation when traveling?\", \"Have you ever traveled off the beaten path?\", \"Do you prefer staying in hotels or using alternative accommodations?\", \"What's the longest trip you've ever taken?\", \"Do you have any upcoming travel plans?\", \"What's the most beautiful place you've visited?\", \"Have you ever traveled for a special occasion?\", \"Do you keep a travel journal or document your trips in any way?\", \"What's the most challenging aspect of travel for you?\", \"Do you have any tips for saving money while traveling?\"]
        conv = [
                \"I've heard you're getting into traveling.\",
                \"I've heard you're planning some exciting trips.\",
                \"So, I hear you're exploring the world now.\",
                \"I've been told you're catching the travel bug.\",
                \"Rumor has it that you're embarking on new adventures.\",
                \"I've heard you've become quite the globetrotter.\",
                \"Word on the street is you're embracing the wanderlust.\",
                \"I've heard whispers of your travel escapades.\",
                \"I've been informed you're jetting off to new destinations.\",
                \"Seems like you're diving headfirst into the world of travel.\",
                \"I've heard you're immersing yourself in different cultures.\",
                \"I've been told you're discovering the beauty of travel.\",
                \"So, I hear you're filling your passport with stamps.\",
                \"Word has it that you're exploring the unknown.\",
                \"I've heard tales of your travel adventures.\",
                \"I've been informed you're venturing into uncharted territories.\",
                \"Seems like you're on a quest to see the world.\",
                \"I've heard you're collecting memories from around the globe.\",
                \"I've been told you're creating a travel story worth sharing.\",
                \"So, I hear you're embarking on a journey of a lifetime.\"
        ]
        usr_start = f\"{random.choice(greeting)} {bot_name}! Long time no see, It's me, {user_name}! {random.choice(conv)} {random.choice(questions)}\"" . 38782) (t 25704 11233 693844 44000)) (emacs-undo-equiv-table (-20 . -22) (-14 . -16) (-6 . -8) (-16 . -18) (5 . -1)))