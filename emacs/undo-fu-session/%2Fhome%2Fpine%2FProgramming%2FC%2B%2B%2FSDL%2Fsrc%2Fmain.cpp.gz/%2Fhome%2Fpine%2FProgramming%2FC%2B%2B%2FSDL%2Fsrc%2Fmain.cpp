((buffer-size . 3094) (buffer-checksum . "1575d0bda28cc28ef7954c1e57a5bcdad52579e2"))
((emacs-buffer-undo-list nil (1345 . 1348) nil ("t" . -1345) ((marker . 1348) . -1) 1346 nil (1342 . 1346) nil (1342 . 1343) (t 25707 30223 984750 267000) nil (3087 . 3088) nil ("
" . -3087) ((marker . 1348) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ("
" . -3088) ((marker . 1348) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) ((marker . 3094) . -1) 3089 nil ("\"\"\"

# 1. Create a new file called \"main.cpp\"
# 2. Copy the code above into the file
# 3. Save the file
# 4. Run the code
# 5. If you did it correctly, you should see a window with a black background and a white image of a \"hello\" in the center.

# ## Step 2: Compiling and Running the Code
# 
# Now that we have the code, we need to compile it.
# 
# ### Compiling
# 
# Compiling is the process of converting the code into a binary executable file.
# 
# ### Running
# 
# Running is the process of executing the binary file.
# 
# ### Compiling and Running
# 
# Compiling and running is the process of converting the code into a binary executable file and then executing the binary file.
# 
# ### Compiling on Windows
# 
# On Windows, we can use the Visual Studio IDE to compile the code.
#" . 3089) ((marker . 3094) . -719) ((marker . 3094) . -786) ((marker . 3094) . -788) ((marker* . 3095) . 786) ((marker . 3094) . -4) ((marker . 3094) . -6) ((marker . 3094) . -59) ((marker . 3094) . -116) ((marker . 3094) . -188) ((marker . 3094) . -257) ((marker . 3094) . -325) ((marker . 3094) . -386) ((marker . 3094) . -467) ((marker . 3094) . -542) ((marker . 3094) . -633) ((marker . 3094) . -717) ((marker) . -788) (nil syntax-table nil 3091 . 3092) (nil syntax-table (15) 3092 . 3093) (nil syntax-table (15) 3091 . 3092) (nil syntax-table nil 3092 . 3093) (nil syntax-table (1) 3091 . 3092) nil (3806 . 3877) (nil syntax-table nil 3091 . 3092) (nil syntax-table (15) 3092 . 3093) (nil syntax-table (15) 3091 . 3092) (nil syntax-table nil 3092 . 3093) (nil syntax-table (1) 3091 . 3092) nil (3722 . 3806) (nil syntax-table nil 3091 . 3092) (nil syntax-table (15) 3092 . 3093) (nil syntax-table (15) 3091 . 3092) (nil syntax-table nil 3092 . 3093) (nil syntax-table (1) 3091 . 3092) nil (3631 . 3722) (nil syntax-table nil 3091 . 3092) (nil syntax-table (15) 3092 . 3093) (nil syntax-table (15) 3091 . 3092) (nil syntax-table nil 3092 . 3093) (nil syntax-table (1) 3091 . 3092) nil (3556 . 3631) (nil syntax-table nil 3091 . 3092) (nil syntax-table (15) 3092 . 3093) (nil syntax-table (15) 3091 . 3092) (nil syntax-table nil 3092 . 3093) (nil syntax-table (1) 3091 . 3092) nil (3475 . 3556) (nil syntax-table nil 3091 . 3092) (nil syntax-table (15) 3092 . 3093) (nil syntax-table (15) 3091 . 3092) (nil syntax-table nil 3092 . 3093) (nil syntax-table (1) 3091 . 3092) nil (3414 . 3475) (nil syntax-table nil 3091 . 3092) (nil syntax-table (15) 3092 . 3093) (nil syntax-table (15) 3091 . 3092) (nil syntax-table nil 3092 . 3093) (nil syntax-table (1) 3091 . 3092) nil (3346 . 3414) (nil syntax-table nil 3091 . 3092) (nil syntax-table (15) 3092 . 3093) (nil syntax-table (15) 3091 . 3092) (nil syntax-table nil 3092 . 3093) (nil syntax-table (1) 3091 . 3092) nil (3277 . 3346) (nil syntax-table nil 3091 . 3092) (nil syntax-table (15) 3092 . 3093) (nil syntax-table (15) 3091 . 3092) (nil syntax-table nil 3092 . 3093) (nil syntax-table (1) 3091 . 3092) nil (3205 . 3277) (nil syntax-table nil 3091 . 3092) (nil syntax-table (15) 3092 . 3093) (nil syntax-table (15) 3091 . 3092) (nil syntax-table nil 3092 . 3093) (nil syntax-table (1) 3091 . 3092) nil (3148 . 3205) (nil syntax-table nil 3091 . 3092) (nil syntax-table (15) 3092 . 3093) (nil syntax-table (15) 3091 . 3092) (nil syntax-table nil 3092 . 3093) (nil syntax-table (1) 3091 . 3092) nil (3095 . 3148) (nil syntax-table nil 3091 . 3092) (nil syntax-table (15) 3092 . 3093) (nil syntax-table (15) 3091 . 3092) (nil syntax-table nil 3092 . 3093) (nil syntax-table (1) 3091 . 3092) nil (3029 . 3095) nil (2924 . 3029) nil (2806 . 2924) nil (2733 . 2806) nil (2678 . 2733) nil (2539 . 2678) nil (2407 . 2539) nil (2323 . 2407) nil (2193 . 2323) nil (2065 . 2193) nil (1979 . 2065) nil (1907 . 1979) (nil syntax-table (1) 1886 . 1887) nil (1823 . 1907) nil (1769 . 1823) nil (1692 . 1769) nil (1602 . 1692) nil (1538 . 1602) nil (1453 . 1538) (nil syntax-table (1) 1452 . 1453) nil (1391 . 1453) nil (1332 . 1391) nil (1238 . 1332) nil (1166 . 1238) nil (1057 . 1166) nil (982 . 1057) (nil syntax-table (1) 953 . 954) nil (892 . 982) nil (851 . 892) nil (778 . 851) nil (687 . 778) nil (619 . 687) nil (564 . 619) nil (473 . 564) nil ("
" . -473) ((marker . 1348) . -1) 474 nil (473 . 474) nil (451 . 452) nil (450 . 451) nil (" " . -450) ((marker . 1348) . -1) ((marker . 3094) . -1) ((marker . 1313) . -1) ("*" . -451) ((marker . 1348) . -1) ((marker . 1313) . -1) 452 nil (472 . 472) (472 . 473) (nil face font-lock-type-face 450 . 451) (nil fontified nil 450 . 451) (450 . 451) (" " . -451) (471 . 471) (471 . 472) nil (nil rear-nonsticky nil 470 . 471) (nil fontified nil 284 . 471) (nil fontified nil 283 . 284) (nil fontified nil 264 . 283) (nil fontified nil 263 . 264) (nil fontified nil 249 . 263) (nil fontified nil 248 . 249) (248 . 471) nil (247 . 247) (247 . 248) (246 . 246) (246 . 247) nil (nil rear-nonsticky nil 245 . 246) (nil fontified nil 118 . 246) (118 . 246) nil (117 . 117) (117 . 118) nil ("
" . -1) ((marker . 1348) . -1) ((marker . 1313) . -1) 2 nil ("#include <SDL2/SDL_render.h>
#include <SDL2/SDL_video.h>" . 1) ((marker . 3094) . -28) ((marker . 3094) . -56) ((marker) . -56) nil ("
int main(int argc, char *argv[]) {
	if (SDL_Init(SDL_INIT_VIDEO) < 0) {
		std::cerr << \"SDL_Init Error: \" << SDL_GetError() << std::endl;
		return 1;
	}
	SDL_Window* window = SDL_CreateWindow(\"Text\",
																				SDL_WINDOWPOS_CENTERED,
																				SDL_WINDOWPOS_CENTERED,
																				800, 600,
																				SDL_WINDOW_SHOWN);
	if (window == nullptr) {
		std::cerr << \"SDL_CreateWindow Error: \" << SDL_GetError() << std::endl;
		SDL_Quit();
		return 1;
	}

	SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, 0);
	
	SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255); // Red background
	SDL_RenderClear(renderer);
	SDL_RenderPresent(renderer);
	
	SDL_Event event;
	bool running = true;
	
	while (running) {
    while (SDL_PollEvent(&event)) {
			switch (event.type) {
			case SDL_QUIT:
				running = false;
				break;
			case SDL_WINDOWEVENT:
				if (event.window.event == SDL_WINDOWEVENT_CLOSE) {
					running = false;
				}
				break;
            // Handle other events here
			}
    }
		
    // Update and render your application here
	}
	
	SDL_Delay(5000);
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	// Clean up resources and subsystems
	SDL_Quit();
	
	return 0;
}
" . 174) ((marker . 3094) . -1221) ((marker . 117) . -36) ((marker . 117) . -36) ((marker . 117) . -154) ((marker . 117) . -194) ((marker . 117) . -194) ((marker . 117) . -1074) ((marker . 117) . -851) ((marker . 117) . -953) ((marker . 117) . -970) ((marker . 117) . -774) ((marker . 117) . -1015) ((marker . 117) . -1015) ((marker . 117) . -959) ((marker . 117) . -844) ((marker . 117) . -959) ((marker . 117) . -647) ((marker . 117) . -1221) ((marker . 117) . -1221) ((marker . 117) . -984) ((marker) . -1221) (t 25707 29970 674191 152000) nil ("\\" . -1) ((marker . 1348) . -1) 2 (t 25707 29960 677803 903000) nil (1 . 2) (1 . 1395) nil ("#include <SDL2/SDL_render.h>
#include <SDL2/SDL_video.h>
#include <iostream>
#include <stdlib.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>

int main(int argc, char *argv[]) {
	if (SDL_Init(SDL_INIT_VIDEO) < 0) {
		std::cerr << \"SDL_Init Error: \" << SDL_GetError() << std::endl;
		return 1;
	}
	SDL_Window* window = SDL_CreateWindow(\"Text\",
																				SDL_WINDOWPOS_CENTERED,
																				SDL_WINDOWPOS_CENTERED,
																				800, 600,
																				SDL_WINDOW_SHOWN);
	if (window == nullptr) {
		std::cerr << \"SDL_CreateWindow Error: \" << SDL_GetError() << std::endl;
		SDL_Quit();
		return 1;
	}

	SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, 0);
	
	SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255); // Red background
	SDL_RenderClear(renderer);
	SDL_RenderPresent(renderer);
	
	SDL_Event event;
	bool running = true;
	
	while (running) {
    while (SDL_PollEvent(&event)) {
			switch (event.type) {
			case SDL_QUIT:
				running = false;
				break;
			case SDL_WINDOWEVENT:
				if (event.window.event == SDL_WINDOWEVENT_CLOSE) {
					running = false;
				}
				break;
            // Handle other events here
			}
    }
		
    // Update and render your application here
	}
	
	SDL_Delay(5000);
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	// Clean up resources and subsystems
	SDL_Quit();
	
	return 0;
}
" . 1) ((marker . 1348) . -1245) ((marker . 933) . -57) ((marker . 3094) . -28) (nil rear-nonsticky t 1394 . 1395) (t 25707 29945 264905 19000) nil (nil rear-nonsticky nil 1394 . 1395) (nil fontified nil 1394 . 1395) (nil fontified nil 1393 . 1394) (nil fontified nil 1392 . 1393) (nil fontified nil 1391 . 1392) (nil fontified nil 1390 . 1391) (nil fontified nil 1389 . 1390) (nil fontified nil 1388 . 1389) (nil fontified nil 1387 . 1388) (nil fontified nil 1386 . 1387) (nil fontified nil 1385 . 1386) (nil fontified nil 1384 . 1385) (nil fontified nil 1383 . 1384) (nil fontified nil 1382 . 1383) (nil fontified nil 1381 . 1382) (nil fontified nil 1380 . 1381) (nil fontified nil 1379 . 1380) (nil fontified nil 1378 . 1379) (nil fontified nil 1377 . 1378) (nil fontified nil 1376 . 1377) (nil fontified nil 1369 . 1376) (nil fontified nil 1368 . 1369) (nil fontified nil 1367 . 1368) (nil fontified nil 1366 . 1367) (nil fontified nil 1333 . 1366) (nil fontified nil 1331 . 1333) (nil fontified nil 1330 . 1331) (nil fontified nil 1329 . 1330) (nil fontified nil 1328 . 1329) (nil fontified nil 1327 . 1328) (nil fontified nil 1326 . 1327) (nil fontified nil 1320 . 1326) (nil fontified nil 1319 . 1320) (nil fontified nil 1302 . 1319) (nil fontified nil 1301 . 1302) (nil fontified nil 1300 . 1301) (nil fontified nil 1299 . 1300) (nil fontified nil 1298 . 1299) (nil fontified nil 1290 . 1298) (nil fontified nil 1289 . 1290) (nil fontified nil 1270 . 1289) (nil fontified nil 1269 . 1270) (nil fontified nil 1268 . 1269) (nil fontified nil 1267 . 1268) (nil fontified nil 1266 . 1267) (nil fontified nil 1262 . 1266) (nil fontified nil 1261 . 1262) (nil fontified nil 1252 . 1261) (nil fontified nil 1251 . 1252) (nil fontified nil 1250 . 1251) (nil fontified nil 1249 . 1250) (nil fontified nil 1248 . 1249) (nil fontified nil 1247 . 1248) (nil fontified nil 1246 . 1247) (nil fontified nil 1245 . 1246) (nil fontified nil 1206 . 1245) (nil fontified nil 1204 . 1206) (nil fontified nil 1203 . 1204) (nil fontified nil 1199 . 1203) (nil fontified nil 1198 . 1199) (nil fontified nil 1196 . 1198) (nil fontified nil 1195 . 1196) (nil fontified nil 1194 . 1195) (nil fontified nil 1190 . 1194) (nil fontified nil 1189 . 1190) (nil fontified nil 1188 . 1189) (nil fontified nil 1186 . 1188) (nil fontified nil 1185 . 1186) (nil fontified nil 1184 . 1185) (nil fontified nil 1160 . 1184) (nil fontified nil 1158 . 1160) (nil fontified nil 1157 . 1158) (nil fontified nil 1145 . 1157) (nil fontified nil 1143 . 1145) (nil fontified nil 1138 . 1143) (nil fontified nil 1134 . 1138) (nil fontified nil 1133 . 1134) (nil fontified nil 1132 . 1133) (nil fontified nil 1128 . 1132) (nil fontified nil 1126 . 1128) (nil fontified nil 1121 . 1126) (nil fontified nil 1111 . 1121) (nil fontified nil 1106 . 1111) (nil fontified nil 1105 . 1106) (nil fontified nil 1104 . 1105) (nil fontified nil 1103 . 1104) (nil fontified nil 1102 . 1103) (nil fontified nil 1059 . 1102) (nil fontified nil 1058 . 1059) (nil fontified nil 1057 . 1058) (nil fontified nil 1055 . 1057) (nil fontified nil 1051 . 1055) (nil fontified nil 1050 . 1051) (nil fontified nil 1049 . 1050) (nil fontified nil 1033 . 1049) (nil fontified nil 1029 . 1033) (nil fontified nil 1026 . 1029) (nil fontified nil 1024 . 1026) (nil fontified nil 1019 . 1024) (nil fontified nil 1015 . 1019) (nil fontified nil 1013 . 1015) (nil fontified nil 1008 . 1013) (nil fontified nil 998 . 1008) (nil fontified nil 994 . 998) (nil fontified nil 993 . 994) (nil fontified nil 992 . 993) (nil fontified nil 983 . 992) (nil fontified nil 979 . 983) (nil fontified nil 976 . 979) (nil fontified nil 975 . 976) (nil fontified nil 974 . 975) (nil fontified nil 973 . 974) (nil fontified nil 972 . 973) (nil fontified nil 962 . 972) (nil fontified nil 961 . 962) (nil fontified nil 960 . 961) (nil fontified nil 954 . 960) (nil fontified nil 951 . 954) (nil fontified nil 950 . 951) (nil fontified nil 949 . 950) (nil fontified nil 948 . 949) (nil fontified nil 947 . 948) (nil fontified nil 946 . 947) (nil fontified nil 940 . 946) (nil fontified nil 939 . 940) (nil fontified nil 926 . 939) (nil fontified nil 925 . 926) (nil fontified nil 924 . 925) (nil fontified nil 919 . 924) (nil fontified nil 915 . 919) (nil fontified nil 914 . 915) (nil fontified nil 913 . 914) (nil fontified nil 912 . 913) (nil fontified nil 911 . 912) (nil fontified nil 904 . 911) (nil fontified nil 903 . 904) (nil fontified nil 902 . 903) (nil fontified nil 897 . 902) (nil fontified nil 896 . 897) (nil fontified nil 895 . 896) (nil fontified nil 894 . 895) (nil fontified nil 892 . 894) (nil fontified nil 888 . 892) (nil fontified nil 885 . 888) (nil fontified nil 878 . 885) (nil fontified nil 877 . 878) (nil fontified nil 876 . 877) (nil fontified nil 873 . 876) (nil fontified nil 872 . 873) (nil fontified nil 870 . 872) (nil fontified nil 865 . 870) (nil fontified nil 864 . 865) (nil fontified nil 863 . 864) (nil fontified nil 855 . 863) (nil fontified nil 854 . 855) (nil fontified nil 853 . 854) (nil fontified nil 852 . 853) (nil fontified nil 851 . 852) (nil fontified nil 850 . 851) (nil fontified nil 849 . 850) (nil fontified nil 841 . 849) (nil fontified nil 840 . 841) (nil fontified nil 823 . 840) (nil fontified nil 822 . 823) (nil fontified nil 821 . 822) (nil fontified nil 820 . 821) (nil fontified nil 819 . 820) (nil fontified nil 811 . 819) (nil fontified nil 810 . 811) (nil fontified nil 796 . 810) (nil fontified nil 795 . 796) (nil fontified nil 794 . 795) (nil fontified nil 793 . 794) (nil fontified nil 779 . 793) (nil fontified nil 777 . 779) (nil fontified nil 776 . 777) (nil fontified nil 775 . 776) (nil fontified nil 774 . 775) (nil fontified nil 773 . 774) (nil fontified nil 749 . 773) (nil fontified nil 748 . 749) (nil fontified nil 726 . 748) (nil fontified nil 725 . 726) (nil fontified nil 724 . 725) (nil fontified nil 723 . 724) (nil fontified nil 722 . 723) (nil fontified nil 721 . 722) (nil fontified nil 720 . 721) (nil fontified nil 707 . 720) (nil fontified nil 706 . 707) (nil fontified nil 685 . 706) (nil fontified nil 677 . 685) (nil fontified nil 675 . 677) (nil fontified nil 674 . 675) (nil fontified nil 663 . 674) (nil fontified nil 662 . 663) (nil fontified nil 661 . 662) (nil fontified nil 660 . 661) (nil fontified nil 659 . 660) (nil fontified nil 658 . 659) (nil fontified nil 654 . 658) (nil fontified nil 648 . 654) (nil fontified nil 646 . 648) (nil fontified nil 644 . 646) (nil fontified nil 643 . 644) (nil fontified nil 642 . 643) (nil fontified nil 634 . 642) (nil fontified nil 632 . 634) (nil fontified nil 624 . 632) (nil fontified nil 621 . 624) (nil fontified nil 617 . 621) (nil fontified nil 616 . 617) (nil fontified nil 615 . 616) (nil fontified nil 599 . 615) (nil fontified nil 573 . 599) (nil fontified nil 563 . 573) (nil fontified nil 560 . 563) (nil fontified nil 558 . 560) (nil fontified nil 557 . 558) (nil fontified nil 556 . 557) (nil fontified nil 555 . 556) (nil fontified nil 554 . 555) (nil fontified nil 547 . 554) (nil fontified nil 537 . 547) (nil fontified nil 536 . 537) (nil fontified nil 535 . 536) (nil fontified nil 533 . 535) (nil fontified nil 532 . 533) (nil fontified nil 530 . 532) (nil fontified nil 529 . 530) (nil fontified nil 513 . 529) (nil fontified nil 483 . 513) (nil fontified nil 439 . 483) (nil fontified nil 395 . 439) (nil fontified nil 375 . 395) (nil fontified nil 373 . 375) (nil fontified nil 372 . 373) (nil fontified nil 371 . 372) (nil fontified nil 370 . 371) (nil fontified nil 369 . 370) (nil fontified nil 368 . 369) (nil fontified nil 367 . 368) (nil fontified nil 366 . 367) (nil fontified nil 347 . 366) (nil fontified nil 341 . 347) (nil fontified nil 339 . 341) (nil fontified nil 338 . 339) (nil fontified nil 329 . 338) (nil fontified nil 328 . 329) (nil fontified nil 327 . 328) (nil fontified nil 326 . 327) (nil fontified nil 325 . 326) (nil fontified nil 321 . 325) (nil fontified nil 315 . 321) (nil fontified nil 313 . 315) (nil fontified nil 305 . 313) (nil fontified nil 302 . 305) (nil fontified nil 298 . 302) (nil fontified nil 297 . 298) (nil fontified nil 296 . 297) (nil fontified nil 280 . 296) (nil fontified nil 262 . 280) (nil fontified nil 252 . 262) (nil fontified nil 249 . 252) (nil fontified nil 247 . 249) (nil fontified nil 246 . 247) (nil fontified nil 245 . 246) (nil fontified nil 244 . 245) (nil fontified nil 243 . 244) (nil fontified nil 239 . 243) (nil fontified nil 238 . 239) (nil fontified nil 224 . 238) (nil fontified nil 223 . 224) (nil fontified nil 215 . 223) (nil fontified nil 214 . 215) (nil fontified nil 213 . 214) (nil fontified nil 211 . 213) (nil fontified nil 210 . 211) (nil fontified nil 209 . 210) (nil fontified nil 208 . 209) (nil fontified nil 207 . 208) (nil fontified nil 206 . 207) (nil fontified nil 205 . 206) (nil fontified nil 204 . 205) (nil fontified nil 200 . 204) (nil fontified nil 198 . 200) (nil fontified nil 194 . 198) (nil fontified nil 193 . 194) (nil fontified nil 192 . 193) (nil fontified nil 188 . 192) (nil fontified nil 187 . 188) (nil fontified nil 184 . 187) (nil fontified nil 183 . 184) (nil fontified nil 179 . 183) (nil fontified nil 178 . 179) (nil fontified nil 177 . 178) (nil fontified nil 176 . 177) (nil fontified nil 175 . 176) (nil fontified nil 174 . 175) (nil fontified nil 173 . 174) (nil fontified nil 172 . 173) (nil fontified nil 158 . 172) (nil fontified nil 157 . 158) (nil fontified nil 156 . 157) (nil fontified nil 155 . 156) (nil fontified nil 154 . 155) (nil fontified nil 153 . 154) (nil fontified nil 152 . 153) (nil fontified nil 151 . 152) (nil fontified nil 150 . 151) (nil fontified nil 149 . 150) (nil fontified nil 148 . 149) (nil fontified nil 147 . 148) (nil fontified nil 146 . 147) (nil fontified nil 130 . 146) (nil fontified nil 129 . 130) (nil fontified nil 128 . 129) (nil fontified nil 127 . 128) (nil fontified nil 126 . 127) (nil fontified nil 125 . 126) (nil fontified nil 124 . 125) (nil fontified nil 123 . 124) (nil fontified nil 122 . 123) (nil fontified nil 121 . 122) (nil fontified nil 120 . 121) (nil fontified nil 119 . 120) (nil fontified nil 118 . 119) (nil fontified nil 108 . 118) (nil fontified nil 107 . 108) (nil fontified nil 106 . 107) (nil fontified nil 105 . 106) (nil fontified nil 104 . 105) (nil fontified nil 103 . 104) (nil fontified nil 102 . 103) (nil fontified nil 101 . 102) (nil fontified nil 100 . 101) (nil fontified nil 99 . 100) (nil fontified nil 98 . 99) (nil fontified nil 97 . 98) (nil fontified nil 96 . 97) (nil fontified nil 88 . 96) (nil fontified nil 87 . 88) (nil fontified nil 86 . 87) (nil fontified nil 85 . 86) (nil fontified nil 84 . 85) (nil fontified nil 83 . 84) (nil fontified nil 82 . 83) (nil fontified nil 81 . 82) (nil fontified nil 80 . 81) (nil fontified nil 79 . 80) (nil fontified nil 78 . 79) (nil fontified nil 77 . 78) (nil fontified nil 76 . 77) (nil fontified nil 68 . 76) (nil fontified nil 67 . 68) (nil fontified nil 66 . 67) (nil fontified nil 65 . 66) (nil fontified nil 64 . 65) (nil fontified nil 62 . 64) (nil fontified nil 60 . 62) (nil fontified nil 59 . 60) (nil fontified nil 58 . 59) (nil fontified nil 57 . 58) (nil fontified nil 56 . 57) (nil fontified nil 40 . 56) (nil fontified nil 39 . 40) (nil fontified nil 38 . 39) (nil fontified nil 31 . 38) (nil fontified nil 30 . 31) (nil fontified nil 29 . 30) (nil fontified nil 28 . 29) (nil fontified nil 11 . 28) (nil fontified nil 10 . 11) (nil fontified nil 9 . 10) (nil fontified nil 2 . 9) (nil fontified nil 1 . 2) (1 . 1395) nil ("#include <SDL2/SDL_render.h>
#include <SDL2/SDL_video.h>
#include <iostream>
#include <stdlib.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>

int main(int argc, char *argv[]) {
	if (SDL_Init(SDL_INIT_VIDEO) < 0) {
		std::cerr << \"SDL_Init Error: \" << SDL_GetError() << std::endl;
		return 1;
	}
	SDL_Window* window = SDL_CreateWindow(\"Text\",
																				SDL_WINDOWPOS_CENTERED,
																				SDL_WINDOWPOS_CENTERED,
																				800, 600,
																				SDL_WINDOW_SHOWN);
	if (window == nullptr) {
		std::cerr << \"SDL_CreateWindow Error: \" << SDL_GetError() << std::endl;
		SDL_Quit();
		return 1;
	}

	SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, 0);
	
	SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255); // Red background
	SDL_RenderClear(renderer);
	SDL_RenderPresent(renderer);
	
	SDL_Event event;
	bool running = true;
	
	while (running) {
    while (SDL_PollEvent(&event)) {
			switch (event.type) {
			case SDL_QUIT:
				running = false;
				break;
			case SDL_WINDOWEVENT:
				if (event.window.event == SDL_WINDOWEVENT_CLOSE) {
					running = false;
				}
				break;
            // Handle other events here
			}
    }
		
    // Update and render your application here
	}
	
	SDL_Delay(5000);
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	// Clean up resources and subsystems
	SDL_Quit();
	
	return 0;
}
" . 1) ((marker . 3094) . -28) ((marker . 3094) . -1394) ((marker . 116) . -172) ((marker . 117) . -209) ((marker . 117) . -209) ((marker . 117) . -327) ((marker . 117) . -367) ((marker . 117) . -367) ((marker . 117) . -1247) ((marker . 117) . -1024) ((marker . 117) . -1126) ((marker . 117) . -1143) ((marker . 117) . -947) ((marker . 117) . -1188) ((marker . 117) . -1188) ((marker . 117) . -1132) ((marker . 117) . -1017) ((marker . 117) . -1132) ((marker . 117) . -820) ((marker . 117) . -1394) ((marker . 117) . -1394) ((marker . 117) . -1157) ("\\" . -1) ((marker . 1348) . -1) 2 nil (1 . 2) (t 25707 29722 112809 739000) nil (1 . 1395) nil ("#include <SDL2/SDL_render.h>
#include <SDL2/SDL_video.h>
#include <iostream>
#include <stdlib.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>

int main(int argc, char *argv[]) {
	if (SDL_Init(SDL_INIT_VIDEO) < 0) {
		std::cerr << \"SDL_Init Error: \" << SDL_GetError() << std::endl;
		return 1;
	}
	SDL_Window* window = SDL_CreateWindow(\"Text\",
																				SDL_WINDOWPOS_CENTERED,
																				SDL_WINDOWPOS_CENTERED,
																				800, 600,
																				SDL_WINDOW_SHOWN);
	if (window == nullptr) {
		std::cerr << \"SDL_CreateWindow Error: \" << SDL_GetError() << std::endl;
		SDL_Quit();
		return 1;
	}

	SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, 0);
	
	SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255); // Red background
	SDL_RenderClear(renderer);
	SDL_RenderPresent(renderer);
	
	SDL_Event event;
	bool running = true;
	
	while (running) {
    while (SDL_PollEvent(&event)) {
			switch (event.type) {
			case SDL_QUIT:
				running = false;
				break;
			case SDL_WINDOWEVENT:
				if (event.window.event == SDL_WINDOWEVENT_CLOSE) {
					running = false;
				}
				break;
            // Handle other events here
			}
    }
		
    // Update and render your application here
	}
	
	SDL_Delay(5000);
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	// Clean up resources and subsystems
	SDL_Quit();
	
	return 0;
}
" . 1) ((marker . 3094) . -28) ((marker . 3094) . -1394) ((marker . 116) . -172) ((marker . 117) . -209) ((marker . 117) . -209) ((marker . 117) . -327) ((marker . 117) . -367) ((marker . 117) . -367) ((marker . 117) . -1247) ((marker . 117) . -1024) ((marker . 117) . -1126) ((marker . 117) . -1143) ((marker . 117) . -947) ((marker . 117) . -1188) ((marker . 117) . -1188) ((marker . 117) . -1132) ((marker . 117) . -1017) ((marker . 117) . -1132) ((marker . 117) . -820) ((marker . 117) . -1394) ((marker) . -1394) ((marker . 117) . -1394) ((marker . 117) . -1157) (t 25707 29722 112809 739000) nil ("
" . -821) ((marker . 1348) . -1) ((marker . 3094) . -1) 822 nil (823 . 824) ("				" . 823) 855 nil (nil fontified nil 854 . 855) (nil fontified nil 853 . 854) (nil fontified nil 845 . 853) (nil fontified nil 844 . 845) (nil fontified nil 827 . 844) (nil fontified nil 823 . 827) (nil fontified nil 822 . 823) (822 . 855) nil ("
				SDL_RenderPresent(renderer);" . 1104) ((marker . 3094) . -33) ((marker) . -33) (t 25707 29697 140192 783000) nil ("
" . -1104) ((marker . 1348) . -1) ((marker . 3094) . -1) (" " . -1105) ((marker . 1348) . -1) ((marker . 3094) . -1) (" " . -1106) ((marker . 1348) . -1) ((marker . 3094) . -1) ("	" . 1107) ((marker . 1348) . -1) ((marker . 3094) . -1) (1105 . 1107) 1106 nil (" " . -1106) ((marker . 1348) . -1) ((marker . 3094) . -1) (" " . -1107) ((marker . 1348) . -1) ((marker . 3094) . -1) ("	" . 1108) ((marker . 1348) . -1) ((marker . 3094) . -1) (1106 . 1108) 1107 nil (" " . -1107) ((marker . 1348) . -1) ((marker . 3094) . -1) (" " . -1108) ((marker . 1348) . -1) ((marker . 3094) . -1) ("	" . 1109) ((marker . 1348) . -1) ((marker . 3094) . -1) (1107 . 1109) 1108 nil (" " . -1108) ((marker . 1348) . -1) ((marker . 3094) . -1) (" " . -1109) ((marker . 1348) . -1) ((marker . 3094) . -1) ("	" . 1110) ((marker . 1348) . -1) ((marker . 3094) . -1) (1108 . 1110) 1109 nil (1110 . 1114) ("			" . 1110) 1141 nil (nil fontified nil 1140 . 1141) (nil fontified nil 1139 . 1140) (nil fontified nil 1131 . 1139) (nil fontified nil 1130 . 1131) (nil fontified nil 1113 . 1130) (nil fontified nil 1110 . 1113) (nil fontified nil 1109 . 1110) (1109 . 1141) nil (1104 . 1109) nil ("
			SDL_RenderPresent(renderer);" . 1160) ((marker . 3094) . -32) ((marker . 1313) . -8) ((marker) . -32) (t 25707 29669 511195 24000) nil ("
" . -1160) ((marker . 1348) . -1) ((marker . 3094) . -1) (" " . -1161) ((marker . 1348) . -1) ((marker . 3094) . -1) (" " . -1162) ((marker . 1348) . -1) ((marker . 3094) . -1) ("	" . 1163) ((marker . 1348) . -1) ((marker . 3094) . -1) (1161 . 1163) 1162 nil (" " . -1162) ((marker . 1348) . -1) ((marker . 3094) . -1) (" " . -1163) ((marker . 1348) . -1) ((marker . 3094) . -1) ("	" . 1164) ((marker . 1348) . -1) ((marker . 3094) . -1) (1162 . 1164) 1163 nil (" " . -1163) ((marker . 1348) . -1) ((marker . 3094) . -1) (" " . -1164) ((marker . 1348) . -1) ((marker . 3094) . -1) ("	" . 1165) ((marker . 1348) . -1) ((marker . 3094) . -1) (1163 . 1165) 1164 nil ("
" . -1164) ((marker . 1348) . -1) (" " . -1165) ((marker . 1348) . -1) (" " . -1166) ((marker . 1348) . -1) ("	" . 1167) ((marker . 1348) . -1) (1165 . 1167) 1166 nil (" " . -1166) ((marker . 1348) . -1) (" " . -1167) ((marker . 1348) . -1) ("	" . 1168) ((marker . 1348) . -1) (1166 . 1168) 1167 nil (" " . -1167) ((marker . 1348) . -1) (" " . -1168) ((marker . 1348) . -1) ("	" . 1169) ((marker . 1348) . -1) (1167 . 1169) 1168 nil (1169 . 1172) ("	" . 1169) 1174 nil (1165 . 1168) (t 25707 29665 418043 154000) nil (nil fontified nil 1194 . 1195) (nil fontified nil 1193 . 1194) (nil fontified nil 1185 . 1193) (nil fontified nil 1184 . 1185) (nil fontified nil 1167 . 1184) (nil fontified nil 1166 . 1167) (nil fontified nil 1165 . 1166) (nil fontified nil 1164 . 1165) (1164 . 1195) nil (1160 . 1164) nil ("

	SDL_RenderPresent(renderer);" . 1219) ((marker . 3094) . -31) ((marker . 117) . -1) ((marker) . -31) (t 25707 29626 467359 975000) nil ("
" . -1220) ((marker . 1348) . -1) ((marker . 3094) . -1) (" " . -1221) ((marker . 1348) . -1) ((marker . 3094) . -1) (" " . -1222) ((marker . 1348) . -1) ((marker . 3094) . -1) ("	" . 1223) ((marker . 1348) . -1) ((marker . 3094) . -1) (1221 . 1223) 1222 (t 25707 29625 294147 446000) nil (nil rear-nonsticky nil 1251 . 1252) (nil fontified nil 1251 . 1252) (nil fontified nil 1250 . 1251) (nil fontified nil 1242 . 1250) (nil fontified nil 1241 . 1242) (nil fontified nil 1224 . 1241) (nil fontified nil 1223 . 1224) (nil fontified nil 1222 . 1223) (1222 . 1252) nil (1221 . 1222) nil (1222 . 1223) ("	" . 1221) ((marker . 1348) . -1) (1221 . 1223) ("	" . 1220) ((marker . 1348) . -1) (1221 . 1222) nil (1220 . 1221) nil ("
	SDL_RenderPresent(renderer);" . 821) ((marker . 3094) . -30) ((marker) . -30) (t 25707 29599 927889 430000) nil (nil rear-nonsticky nil 1299 . 1300) (nil fontified nil 1270 . 1300) (1270 . 1300) (t 25707 29590 230962 896000) nil (1269 . 1270) nil (nil rear-nonsticky nil 1268 . 1269) (nil fontified nil 1252 . 1269) (1252 . 1269) nil (1251 . 1252) ("	" . 1250) ((marker . 1348) . -1) (1251 . 1252) nil (1250 . 1251) (t 25707 29549 134978 860000) nil ("
" . -851) ((marker . 1348) . -1) 852 nil (nil rear-nonsticky nil 851 . 852) (nil fontified nil 823 . 852) (823 . 852) nil (822 . 823) nil (824 . 825) ("	" . 823) ((marker . 1348) . -1) (823 . 825) ("	" . 822) ((marker . 1348) . -1) (823 . 824) (t 25707 29517 929558 125000) nil (794 . 795) 820 nil (nil rear-nonsticky nil 819 . 820) (nil fontified nil 726 . 820) (726 . 820) nil (725 . 726) nil (723 . 724) nil (725 . 726) ("	" . 724) ((marker . 1348) . -1) (724 . 726) ("	" . 723) ((marker . 1348) . -1) (724 . 725) (t 25707 29507 53015 686000) nil (nil rear-nonsticky nil 721 . 722) (nil fontified nil 663 . 722) (663 . 722) nil ("SDL_CreateRenderer" . 663) ((marker . 3094) . -18) ((marker) . -18) nil (1 . 30) (634 . 634) (634 . 652) ("SDL_Cre" . 634) (634 . 641) ("SDL_CreateRenderer(SDL_Window *window, int index, Uint32 flags)" . -634) (634 . 697) ("SDL_CreateRe" . -634) ((marker . 1313) . -12) ((marker . 1348) . -12) 646 nil (644 . 646) nil ("_" . -644) ((marker . 1313) . -1) ((marker . 1348) . -1) 645 nil (634 . 645) nil (633 . 634) nil (634 . 635) ("	" . 633) ((marker . 1348) . -1) (633 . 635) ("	" . 632) ((marker . 1348) . -1) (633 . 634) nil (632 . 633) (t 25707 29223 712917 764000) nil (1030 . 1047) ("SDL_D" . 1030) (1030 . 1035) ("SDL_DestroyWindow(SDL_Window *window)" . -1030) (1030 . 1067) ("SDL_Destroy" . -1030) ((marker . 1348) . -11) ((marker . 3094) . -4) 1041 nil (1034 . 1041) nil ("Window_Destroy" . 1034) ((marker . 3094) . -14) ((marker) . -14) (t 25707 29196 753225 515000) nil (1030 . 1057) ("SDL_Window_Des" . -1030) ((marker . 1313) . -14) ((marker . 1348) . -14) 1044 nil (1043 . 1044) nil (1040 . 1043) nil (1 . 29) (1002 . 1002) (1002 . 1012) ("SDL_W" . 1002) (1002 . 1007) ("SDL_Window" . -1002) (1002 . 1012) ("SDL_Win" . -1002) ((marker . 1313) . -7) ((marker . 1348) . -7) 1009 nil (1002 . 1009) nil (1001 . 1002) ("	" . 1000) ((marker . 1348) . -1) (1001 . 1002) (t 25707 29099 274338 80000) nil (647 . 648) nil ("	" . 647) ((marker . 3094) . -1) ((marker) . -1) nil (1040 . 1041) 1044 nil (1002 . 1003) 1004 nil (1000 . 1001) nil (997 . 998) 998 nil (947 . 949) nil (936 . 939) ("        " . -936) ((marker . 1348) . -8) 944 nil (885 . 889) ("                " . 885) ((marker . 1348) . -8) 893 nil (879 . 883) ("                " . 879) ((marker . 1348) . -10) 889 nil (857 . 862) ("                    " . 857) ((marker . 1348) . -8) 865 nil (802 . 806) ("                " . 802) ((marker . 1348) . -6) 808 nil (777 . 780) ("            " . 777) ((marker . 1348) . -8) 785 nil (766 . 770) ("                " . 766) ((marker . 1348) . -8) 774 nil (745 . 749) ("                " . 745) ((marker . 1348) . -6) 751 nil (727 . 730) ("            " . 727) ((marker . 1348) . -6) 733 nil (702 . 705) ("        " . 702) ((marker . 1348) . -4) 706 nil (647 . 648) 649 nil (645 . 646) nil (623 . 624) 624 nil (nil rear-nonsticky nil 1145 . 1146) (nil fontified nil 606 . 1146) (606 . 1146) nil (605 . 606) nil (606 . 607) ("	" . 605) ((marker . 1348) . -1) (605 . 607) ("	" . 604) ((marker . 1348) . -1) (603 . 606) (t 25707 28983 85663 751000) nil (312 . 315) nil ("E" . -312) ((marker . 1348) . -1) 313 nil (311 . 313) nil ("SDL2 Window" . 311) ((marker . 3094) . -11) ((marker . 117) . -7) ((marker . 117) . -11) ((marker) . -11) (t 25707 28975 642415 324000) nil (608 . 609) ("    " . 608) 613 nil (596 . 598) ("        " . 596) 611 nil (582 . 584) ("        " . 582) 601 nil (508 . 510) ("        " . 508) 534 nil (482 . 483) ("    " . 482) 510 nil (443 . 463) ("                                          " . 443) ((marker . 1348) . -40) 483 nil (413 . 433) ("                                          " . 413) ((marker . 1348) . -40) 453 nil (369 . 389) ("                                          " . 369) ((marker . 1348) . -40) 409 nil (325 . 345) ("                                          " . 325) ((marker . 1348) . -2) 327 nil (271 . 272) ("	    " . 271) ((marker . 3094) . -1) ((marker . 117) . -1) nil (nil rear-nonsticky nil 725 . 726) (nil fontified nil 272 . 726) (272 . 726) (t 25707 28950 86040 164000) nil ("    SDL_Window* window = SDL_CreateWindow(\"SDL2 Window\",
                                          SDL_WINDOWPOS_CENTERED,
                                          SDL_WINDOWPOS_CENTERED,
                                          800, 600,
                                          SDL_WINDOW_SHOWN);
    if (window == nullptr) {
        std::cerr << \"SDL_CreateWindow Error: \" << SDL_GetError() << std::endl;
        SDL_Quit();
        return 1;
    }" . 272) ((marker . 1348) . -454) ((marker*) . 1) ((marker) . -454) ((marker*) . 125) ((marker) . -330) (nil rear-nonsticky t 725 . 726) nil (nil rear-nonsticky nil 725 . 726) (nil fontified nil 272 . 726) (272 . 726) (t 25707 28950 86040 164000) nil (270 . 272) (t 25707 28925 676318 563000) nil (268 . 269) ("    " . -268) ((marker . 1348) . -4) 272 nil (256 . 258) ("        " . 256) ((marker . 1348) . -4) 260 nil (190 . 192) ("        " . 190) ((marker . 1348) . -2) 192 nil (153 . 154) ("	    " . 153) ((marker . 1348) . -4) ((marker . 3094) . -1) ((marker . 117) . -1) ((marker . 117) . -1) 157 nil (nil rear-nonsticky nil 288 . 289) (nil fontified nil 154 . 289) (154 . 289) (t 25707 28827 610770 54000) nil ("    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        std::cerr << \"SDL_Init Error: \" << SDL_GetError() << std::endl;
        return 1;
    }" . 154) ((marker . 1348) . -135) ((marker*) . 1) ((marker) . -135) ((marker*) . 97) ((marker) . -39) (nil rear-nonsticky t 288 . 289) nil (nil rear-nonsticky nil 288 . 289) (nil fontified nil 154 . 289) (154 . 289) (t 25707 28827 610770 54000) nil ("
" . -116) ((marker . 1348) . -1) 117 nil ("
" . -116) ((marker . 1348) . -1) ((marker . 3094) . -1) ((marker . 116) . -1) 117 (t 25707 28823 970811 547000) nil (101 . 116) nil (100 . 101) nil (92 . 100) nil (91 . 92) nil (90 . 90) (90 . 91) nil (73 . 90) nil (72 . 73) nil (64 . 72) nil ("u" . -64) ((marker . 1348) . -1) ((marker . 3094) . -1) ("c" . -65) ((marker . 1348) . -1) ((marker . 3094) . -1) ("b" . -66) ((marker . 1348) . -1) ((marker . 3094) . -1) 67 nil (64 . 67) nil (63 . 64) nil (62 . 62) (62 . 63) (t 25707 28815 830904 334000) nil (">" . 62) ((marker . 3094) . -1) (51 . 62) ("SDL" . -51) ((marker . 1348) . -3) 54 nil (51 . 54) nil ("S" . -51) ((marker . 1348) . -1) ("D" . -52) ((marker . 1348) . -1) ("L" . -53) ((marker . 1348) . -1) ("2" . -54) ((marker . 1348) . -1) 55 nil (56 . 56) (56 . 57) nil (55 . 56) nil ("<" . -55) ((marker . 1348) . -1) ((marker . 3094) . -1) 56 nil (55 . 56) nil (51 . 55) nil (" " . -51) ((marker . 1348) . -1) ((marker . 3094) . -1) 52 nil (51 . 52) nil (50 . 51) nil (42 . 50) nil (41 . 42) nil ("$" . -41) ((marker . 1313) . -1) ((marker . 1348) . -1) 42 nil (41 . 42) nil (40 . 40) (40 . 41) nil (31 . 40) ("stdli" . -31) ((marker . 1348) . -5) ((marker . 3094) . -5) 36 nil (31 . 36) nil ("i" . -31) ((marker . 1348) . -1) ((marker . 3094) . -1) ("o" . -32) ((marker . 1348) . -1) ((marker . 3094) . -1) 33 nil (31 . 33) nil (30 . 31) nil (23 . 30) nil ("c" . -23) ((marker . 1348) . -1) ((marker . 3094) . -1) 24 nil (22 . 24) nil ("c" . -22) ((marker . 1348) . -1) ((marker . 3094) . -1) 23 nil (22 . 23) nil (21 . 22) nil (22 . 22) (22 . 23) (21 . 21) (21 . 22) (t 25707 28773 551386 213000) nil (71 . 72) 69 nil (68 . 69) nil (60 . 68) nil (57 . 58) nil (58 . 59) ("  " . 58) (57 . 58) (57 . 59) (57 . 58) (56 . 56) (56 . 57) nil (26 . 57) ("main" . -26) ((marker . 1313) . -4) ((marker . 1348) . -4) 30 nil (22 . 30) nil (21 . 21) (21 . 22) (20 . 20) (20 . 21) nil (11 . 20) ("iost" . -11) ((marker . 1348) . -4) ((marker . 3094) . -4) 15 nil (11 . 15) nil (10 . 11) nil (9 . 10) nil ("<" . -9) ((marker . 1348) . -1) ((marker . 3094) . -1) 10 nil (9 . 10) nil (" " . -9) ((marker . 1348) . -1) ((marker . 3094) . -1) 10 nil (2 . 10) nil (1 . 2) (t 25707 28755 428259 401000)) (emacs-pending-undo-list (1 . 2) (t 25707 29722 112809 739000) nil (1 . 1395) nil ("#include <SDL2/SDL_render.h>
#include <SDL2/SDL_video.h>
#include <iostream>
#include <stdlib.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>

int main(int argc, char *argv[]) {
	if (SDL_Init(SDL_INIT_VIDEO) < 0) {
		std::cerr << \"SDL_Init Error: \" << SDL_GetError() << std::endl;
		return 1;
	}
	SDL_Window* window = SDL_CreateWindow(\"Text\",
																				SDL_WINDOWPOS_CENTERED,
																				SDL_WINDOWPOS_CENTERED,
																				800, 600,
																				SDL_WINDOW_SHOWN);
	if (window == nullptr) {
		std::cerr << \"SDL_CreateWindow Error: \" << SDL_GetError() << std::endl;
		SDL_Quit();
		return 1;
	}

	SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, 0);
	
	SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255); // Red background
	SDL_RenderClear(renderer);
	SDL_RenderPresent(renderer);
	
	SDL_Event event;
	bool running = true;
	
	while (running) {
    while (SDL_PollEvent(&event)) {
			switch (event.type) {
			case SDL_QUIT:
				running = false;
				break;
			case SDL_WINDOWEVENT:
				if (event.window.event == SDL_WINDOWEVENT_CLOSE) {
					running = false;
				}
				break;
            // Handle other events here
			}
    }
		
    // Update and render your application here
	}
	
	SDL_Delay(5000);
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	// Clean up resources and subsystems
	SDL_Quit();
	
	return 0;
}
" . 1) ((marker . 3094) . -28) ((marker . 3094) . -1394) ((marker . 116) . -172) ((marker . 117) . -209) ((marker . 117) . -209) ((marker . 117) . -327) ((marker . 117) . -367) ((marker . 117) . -367) ((marker . 117) . -1247) ((marker . 117) . -1024) ((marker . 117) . -1126) ((marker . 117) . -1143) ((marker . 117) . -947) ((marker . 117) . -1188) ((marker . 117) . -1188) ((marker . 117) . -1132) ((marker . 117) . -1017) ((marker . 117) . -1132) ((marker . 117) . -820) ((marker . 117) . -1394) ((marker) . -1394) ((marker . 117) . -1394) ((marker . 117) . -1157) (t 25707 29722 112809 739000) nil ("
" . -821) ((marker . 1348) . -1) ((marker . 3094) . -1) 822 nil (823 . 824) ("				" . 823) 855 nil (nil fontified nil 854 . 855) (nil fontified nil 853 . 854) (nil fontified nil 845 . 853) (nil fontified nil 844 . 845) (nil fontified nil 827 . 844) (nil fontified nil 823 . 827) (nil fontified nil 822 . 823) (822 . 855) nil ("
				SDL_RenderPresent(renderer);" . 1104) ((marker . 3094) . -33) ((marker) . -33) (t 25707 29697 140192 783000) nil ("
" . -1104) ((marker . 1348) . -1) ((marker . 3094) . -1) (" " . -1105) ((marker . 1348) . -1) ((marker . 3094) . -1) (" " . -1106) ((marker . 1348) . -1) ((marker . 3094) . -1) ("	" . 1107) ((marker . 1348) . -1) ((marker . 3094) . -1) (1105 . 1107) 1106 nil (" " . -1106) ((marker . 1348) . -1) ((marker . 3094) . -1) (" " . -1107) ((marker . 1348) . -1) ((marker . 3094) . -1) ("	" . 1108) ((marker . 1348) . -1) ((marker . 3094) . -1) (1106 . 1108) 1107 nil (" " . -1107) ((marker . 1348) . -1) ((marker . 3094) . -1) (" " . -1108) ((marker . 1348) . -1) ((marker . 3094) . -1) ("	" . 1109) ((marker . 1348) . -1) ((marker . 3094) . -1) (1107 . 1109) 1108 nil (" " . -1108) ((marker . 1348) . -1) ((marker . 3094) . -1) (" " . -1109) ((marker . 1348) . -1) ((marker . 3094) . -1) ("	" . 1110) ((marker . 1348) . -1) ((marker . 3094) . -1) (1108 . 1110) 1109 nil (1110 . 1114) ("			" . 1110) 1141 nil (nil fontified nil 1140 . 1141) (nil fontified nil 1139 . 1140) (nil fontified nil 1131 . 1139) (nil fontified nil 1130 . 1131) (nil fontified nil 1113 . 1130) (nil fontified nil 1110 . 1113) (nil fontified nil 1109 . 1110) (1109 . 1141) nil (1104 . 1109) nil ("
			SDL_RenderPresent(renderer);" . 1160) ((marker . 3094) . -32) ((marker . 1313) . -8) ((marker) . -32) (t 25707 29669 511195 24000) nil ("
" . -1160) ((marker . 1348) . -1) ((marker . 3094) . -1) (" " . -1161) ((marker . 1348) . -1) ((marker . 3094) . -1) (" " . -1162) ((marker . 1348) . -1) ((marker . 3094) . -1) ("	" . 1163) ((marker . 1348) . -1) ((marker . 3094) . -1) (1161 . 1163) 1162 nil (" " . -1162) ((marker . 1348) . -1) ((marker . 3094) . -1) (" " . -1163) ((marker . 1348) . -1) ((marker . 3094) . -1) ("	" . 1164) ((marker . 1348) . -1) ((marker . 3094) . -1) (1162 . 1164) 1163 nil (" " . -1163) ((marker . 1348) . -1) ((marker . 3094) . -1) (" " . -1164) ((marker . 1348) . -1) ((marker . 3094) . -1) ("	" . 1165) ((marker . 1348) . -1) ((marker . 3094) . -1) (1163 . 1165) 1164 nil ("
" . -1164) ((marker . 1348) . -1) (" " . -1165) ((marker . 1348) . -1) (" " . -1166) ((marker . 1348) . -1) ("	" . 1167) ((marker . 1348) . -1) (1165 . 1167) 1166 nil (" " . -1166) ((marker . 1348) . -1) (" " . -1167) ((marker . 1348) . -1) ("	" . 1168) ((marker . 1348) . -1) (1166 . 1168) 1167 nil (" " . -1167) ((marker . 1348) . -1) (" " . -1168) ((marker . 1348) . -1) ("	" . 1169) ((marker . 1348) . -1) (1167 . 1169) 1168 nil (1169 . 1172) ("	" . 1169) 1174 nil (1165 . 1168) (t 25707 29665 418043 154000) nil (nil fontified nil 1194 . 1195) (nil fontified nil 1193 . 1194) (nil fontified nil 1185 . 1193) (nil fontified nil 1184 . 1185) (nil fontified nil 1167 . 1184) (nil fontified nil 1166 . 1167) (nil fontified nil 1165 . 1166) (nil fontified nil 1164 . 1165) (1164 . 1195) nil (1160 . 1164) nil ("

	SDL_RenderPresent(renderer);" . 1219) ((marker . 3094) . -31) ((marker . 117) . -1) ((marker) . -31) (t 25707 29626 467359 975000) nil ("
" . -1220) ((marker . 1348) . -1) ((marker . 3094) . -1) (" " . -1221) ((marker . 1348) . -1) ((marker . 3094) . -1) (" " . -1222) ((marker . 1348) . -1) ((marker . 3094) . -1) ("	" . 1223) ((marker . 1348) . -1) ((marker . 3094) . -1) (1221 . 1223) 1222 (t 25707 29625 294147 446000) nil (nil rear-nonsticky nil 1251 . 1252) (nil fontified nil 1251 . 1252) (nil fontified nil 1250 . 1251) (nil fontified nil 1242 . 1250) (nil fontified nil 1241 . 1242) (nil fontified nil 1224 . 1241) (nil fontified nil 1223 . 1224) (nil fontified nil 1222 . 1223) (1222 . 1252) nil (1221 . 1222) nil (1222 . 1223) ("	" . 1221) ((marker . 1348) . -1) (1221 . 1223) ("	" . 1220) ((marker . 1348) . -1) (1221 . 1222) nil (1220 . 1221) nil ("
	SDL_RenderPresent(renderer);" . 821) ((marker . 3094) . -30) ((marker) . -30) (t 25707 29599 927889 430000) nil (nil rear-nonsticky nil 1299 . 1300) (nil fontified nil 1270 . 1300) (1270 . 1300) (t 25707 29590 230962 896000) nil (1269 . 1270) nil (nil rear-nonsticky nil 1268 . 1269) (nil fontified nil 1252 . 1269) (1252 . 1269) nil (1251 . 1252) ("	" . 1250) ((marker . 1348) . -1) (1251 . 1252) nil (1250 . 1251) (t 25707 29549 134978 860000) nil ("
" . -851) ((marker . 1348) . -1) 852 nil (nil rear-nonsticky nil 851 . 852) (nil fontified nil 823 . 852) (823 . 852) nil (822 . 823) nil (824 . 825) ("	" . 823) ((marker . 1348) . -1) (823 . 825) ("	" . 822) ((marker . 1348) . -1) (823 . 824) (t 25707 29517 929558 125000) nil (794 . 795) 820 nil (nil rear-nonsticky nil 819 . 820) (nil fontified nil 726 . 820) (726 . 820) nil (725 . 726) nil (723 . 724) nil (725 . 726) ("	" . 724) ((marker . 1348) . -1) (724 . 726) ("	" . 723) ((marker . 1348) . -1) (724 . 725) (t 25707 29507 53015 686000) nil (nil rear-nonsticky nil 721 . 722) (nil fontified nil 663 . 722) (663 . 722) nil ("SDL_CreateRenderer" . 663) ((marker . 3094) . -18) ((marker) . -18) nil (1 . 30) (634 . 634) (634 . 652) ("SDL_Cre" . 634) (634 . 641) ("SDL_CreateRenderer(SDL_Window *window, int index, Uint32 flags)" . -634) (634 . 697) ("SDL_CreateRe" . -634) ((marker . 1313) . -12) ((marker . 1348) . -12) 646 nil (644 . 646) nil ("_" . -644) ((marker . 1313) . -1) ((marker . 1348) . -1) 645 nil (634 . 645) nil (633 . 634) nil (634 . 635) ("	" . 633) ((marker . 1348) . -1) (633 . 635) ("	" . 632) ((marker . 1348) . -1) (633 . 634) nil (632 . 633) (t 25707 29223 712917 764000) nil (1030 . 1047) ("SDL_D" . 1030) (1030 . 1035) ("SDL_DestroyWindow(SDL_Window *window)" . -1030) (1030 . 1067) ("SDL_Destroy" . -1030) ((marker . 1348) . -11) ((marker . 3094) . -4) 1041 nil (1034 . 1041) nil ("Window_Destroy" . 1034) ((marker . 3094) . -14) ((marker) . -14) (t 25707 29196 753225 515000) nil (1030 . 1057) ("SDL_Window_Des" . -1030) ((marker . 1313) . -14) ((marker . 1348) . -14) 1044 nil (1043 . 1044) nil (1040 . 1043) nil (1 . 29) (1002 . 1002) (1002 . 1012) ("SDL_W" . 1002) (1002 . 1007) ("SDL_Window" . -1002) (1002 . 1012) ("SDL_Win" . -1002) ((marker . 1313) . -7) ((marker . 1348) . -7) 1009 nil (1002 . 1009) nil (1001 . 1002) ("	" . 1000) ((marker . 1348) . -1) (1001 . 1002) (t 25707 29099 274338 80000) nil (647 . 648) nil ("	" . 647) ((marker . 3094) . -1) ((marker) . -1) nil (1040 . 1041) 1044 nil (1002 . 1003) 1004 nil (1000 . 1001) nil (997 . 998) 998 nil (947 . 949) nil (936 . 939) ("        " . -936) ((marker . 1348) . -8) 944 nil (885 . 889) ("                " . 885) ((marker . 1348) . -8) 893 nil (879 . 883) ("                " . 879) ((marker . 1348) . -10) 889 nil (857 . 862) ("                    " . 857) ((marker . 1348) . -8) 865 nil (802 . 806) ("                " . 802) ((marker . 1348) . -6) 808 nil (777 . 780) ("            " . 777) ((marker . 1348) . -8) 785 nil (766 . 770) ("                " . 766) ((marker . 1348) . -8) 774 nil (745 . 749) ("                " . 745) ((marker . 1348) . -6) 751 nil (727 . 730) ("            " . 727) ((marker . 1348) . -6) 733 nil (702 . 705) ("        " . 702) ((marker . 1348) . -4) 706 nil (647 . 648) 649 nil (645 . 646) nil (623 . 624) 624 nil (nil rear-nonsticky nil 1145 . 1146) (nil fontified nil 606 . 1146) (606 . 1146) nil (605 . 606) nil (606 . 607) ("	" . 605) ((marker . 1348) . -1) (605 . 607) ("	" . 604) ((marker . 1348) . -1) (603 . 606) (t 25707 28983 85663 751000) nil (312 . 315) nil ("E" . -312) ((marker . 1348) . -1) 313 nil (311 . 313) nil ("SDL2 Window" . 311) ((marker . 3094) . -11) ((marker . 117) . -7) ((marker . 117) . -11) ((marker) . -11) (t 25707 28975 642415 324000) nil (608 . 609) ("    " . 608) 613 nil (596 . 598) ("        " . 596) 611 nil (582 . 584) ("        " . 582) 601 nil (508 . 510) ("        " . 508) 534 nil (482 . 483) ("    " . 482) 510 nil (443 . 463) ("                                          " . 443) ((marker . 1348) . -40) 483 nil (413 . 433) ("                                          " . 413) ((marker . 1348) . -40) 453 nil (369 . 389) ("                                          " . 369) ((marker . 1348) . -40) 409 nil (325 . 345) ("                                          " . 325) ((marker . 1348) . -2) 327 nil (271 . 272) ("	    " . 271) ((marker . 3094) . -1) ((marker . 117) . -1) nil (nil rear-nonsticky nil 725 . 726) (nil fontified nil 272 . 726) (272 . 726) (t 25707 28950 86040 164000) nil ("    SDL_Window* window = SDL_CreateWindow(\"SDL2 Window\",
                                          SDL_WINDOWPOS_CENTERED,
                                          SDL_WINDOWPOS_CENTERED,
                                          800, 600,
                                          SDL_WINDOW_SHOWN);
    if (window == nullptr) {
        std::cerr << \"SDL_CreateWindow Error: \" << SDL_GetError() << std::endl;
        SDL_Quit();
        return 1;
    }" . 272) ((marker . 1348) . -454) ((marker*) . 1) ((marker) . -454) ((marker*) . 125) ((marker) . -330) (nil rear-nonsticky t 725 . 726) nil (nil rear-nonsticky nil 725 . 726) (nil fontified nil 272 . 726) (272 . 726) (t 25707 28950 86040 164000) nil (270 . 272) (t 25707 28925 676318 563000) nil (268 . 269) ("    " . -268) ((marker . 1348) . -4) 272 nil (256 . 258) ("        " . 256) ((marker . 1348) . -4) 260 nil (190 . 192) ("        " . 190) ((marker . 1348) . -2) 192 nil (153 . 154) ("	    " . 153) ((marker . 1348) . -4) ((marker . 3094) . -1) ((marker . 117) . -1) ((marker . 117) . -1) 157 nil (nil rear-nonsticky nil 288 . 289) (nil fontified nil 154 . 289) (154 . 289) (t 25707 28827 610770 54000) nil ("    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        std::cerr << \"SDL_Init Error: \" << SDL_GetError() << std::endl;
        return 1;
    }" . 154) ((marker . 1348) . -135) ((marker*) . 1) ((marker) . -135) ((marker*) . 97) ((marker) . -39) (nil rear-nonsticky t 288 . 289) nil (nil rear-nonsticky nil 288 . 289) (nil fontified nil 154 . 289) (154 . 289) (t 25707 28827 610770 54000) nil ("
" . -116) ((marker . 1348) . -1) 117 nil ("
" . -116) ((marker . 1348) . -1) ((marker . 3094) . -1) ((marker . 116) . -1) 117 (t 25707 28823 970811 547000) nil (101 . 116) nil (100 . 101) nil (92 . 100) nil (91 . 92) nil (90 . 90) (90 . 91) nil (73 . 90) nil (72 . 73) nil (64 . 72) nil ("u" . -64) ((marker . 1348) . -1) ((marker . 3094) . -1) ("c" . -65) ((marker . 1348) . -1) ((marker . 3094) . -1) ("b" . -66) ((marker . 1348) . -1) ((marker . 3094) . -1) 67 nil (64 . 67) nil (63 . 64) nil (62 . 62) (62 . 63) (t 25707 28815 830904 334000) nil (">" . 62) ((marker . 3094) . -1) (51 . 62) ("SDL" . -51) ((marker . 1348) . -3) 54 nil (51 . 54) nil ("S" . -51) ((marker . 1348) . -1) ("D" . -52) ((marker . 1348) . -1) ("L" . -53) ((marker . 1348) . -1) ("2" . -54) ((marker . 1348) . -1) 55 nil (56 . 56) (56 . 57) nil (55 . 56) nil ("<" . -55) ((marker . 1348) . -1) ((marker . 3094) . -1) 56 nil (55 . 56) nil (51 . 55) nil (" " . -51) ((marker . 1348) . -1) ((marker . 3094) . -1) 52 nil (51 . 52) nil (50 . 51) nil (42 . 50) nil (41 . 42) nil ("$" . -41) ((marker . 1313) . -1) ((marker . 1348) . -1) 42 nil (41 . 42) nil (40 . 40) (40 . 41) nil (31 . 40) ("stdli" . -31) ((marker . 1348) . -5) ((marker . 3094) . -5) 36 nil (31 . 36) nil ("i" . -31) ((marker . 1348) . -1) ((marker . 3094) . -1) ("o" . -32) ((marker . 1348) . -1) ((marker . 3094) . -1) 33 nil (31 . 33) nil (30 . 31) nil (23 . 30) nil ("c" . -23) ((marker . 1348) . -1) ((marker . 3094) . -1) 24 nil (22 . 24) nil ("c" . -22) ((marker . 1348) . -1) ((marker . 3094) . -1) 23 nil (22 . 23) nil (21 . 22) nil (22 . 22) (22 . 23) (21 . 21) (21 . 22) (t 25707 28773 551386 213000) nil (71 . 72) 69 nil (68 . 69) nil (60 . 68) nil (57 . 58) nil (58 . 59) ("  " . 58) (57 . 58) (57 . 59) (57 . 58) (56 . 56) (56 . 57) nil (26 . 57) ("main" . -26) ((marker . 1313) . -4) ((marker . 1348) . -4) 30 nil (22 . 30) nil (21 . 21) (21 . 22) (20 . 20) (20 . 21) nil (11 . 20) ("iost" . -11) ((marker . 1348) . -4) ((marker . 3094) . -4) 15 nil (11 . 15) nil (10 . 11) nil (9 . 10) nil ("<" . -9) ((marker . 1348) . -1) ((marker . 3094) . -1) 10 nil (9 . 10) nil (" " . -9) ((marker . 1348) . -1) ((marker . 3094) . -1) 10 nil (2 . 10) nil (1 . 2) (t 25707 28755 428259 401000)) (emacs-undo-equiv-table (64 . -1) (-103 . -105) (-2 . -4) (65 . 67) (-65 . -67) (-111 . -113)))