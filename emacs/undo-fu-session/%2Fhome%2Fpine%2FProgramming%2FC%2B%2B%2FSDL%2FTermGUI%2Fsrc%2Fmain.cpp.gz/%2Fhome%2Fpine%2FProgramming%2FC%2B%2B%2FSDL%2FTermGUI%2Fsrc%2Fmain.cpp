((buffer-size . 1286) (buffer-checksum . "e2c406857c5a3093a584f44e4133556233f47920"))
((emacs-buffer-undo-list nil ("[" . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) 2 (t 25711 7566 196337 1000) nil (1287 . 1288) nil ("
" . -1287) ((marker . 1) . -1) ((marker . 1286) . -1) ((marker . 1286) . -1) ("]" . -1288) ((marker . 1) . -1) ((marker . 1286) . -1) ((marker . 1286) . -1) ((marker*) . 1) ((marker) . -1) 1289 nil ("
" . 1289) nil (1 . 2) nil (945 . 1102) nil ("        // Set renderer color to black
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);

        // Clear renderer
        SDL_RenderClear(renderer);
" . 747) ((marker . 1) . -8) (nil rear-nonsticky t 903 . 904) nil (747 . 755) ("		" . 747) nil (780 . 788) ("		" . 780) nil (831 . 839) ("		" . 831) nil (851 . 859) ("		" . 851) nil (1262 . 1264) nil ("" . 1078) nil (1078 . 1079) nil ("
]" . 1262) ((marker . 1286) . -2) ((marker . 1286) . -2) nil (851 . 853) ("        " . 851) nil (831 . 833) ("        " . 831) nil (780 . 782) ("        " . 780) nil (747 . 749) ("        " . 747) nil (nil rear-nonsticky nil 903 . 904) (747 . 904) nil ("        // Set renderer color to black
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);

        // Clear renderer
        SDL_RenderClear(renderer);
" . 945) (t 25711 7552 753067 370000) nil (945 . 1102) nil ("        // Set renderer color to black
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);

        // Clear renderer
        SDL_RenderClear(renderer);
" . 747) ((marker . 1) . -8) (nil rear-nonsticky t 903 . 904) nil (747 . 755) ("		" . 747) nil (780 . 788) ("		" . 780) nil (831 . 839) ("		" . 831) nil (851 . 859) ("		" . 851) nil (1262 . 1264) (t 25711 7488 216724 947000) nil ("" . 1078) ((marker . 1) . -1) nil (1078 . 1079) (t 25711 7488 216724 947000) nil ("
" . -1262) ((marker . 1) . -1) ((marker . 1286) . -1) ((marker . 1286) . -1) ("]" . -1263) ((marker . 1) . -1) ((marker . 1286) . -1) ((marker . 1286) . -1) ((marker*) . 1) ((marker) . -1) 1264 (t 25711 7475 340126 851000) nil (851 . 853) ("        " . 851) ((marker . 1) . -4) 855 nil (831 . 833) ("        " . 831) ((marker . 1) . -4) 835 nil (780 . 782) ("        " . 780) ((marker . 1158) . -8) ((marker . 1) . -4) 784 nil (747 . 749) ("        " . -747) ((marker . 1) . -8) 755 (t 25711 7469 256826 384000) nil (nil rear-nonsticky nil 903 . 904) (nil fontified nil 902 . 904) (nil fontified nil 901 . 902) (nil fontified nil 893 . 901) (nil fontified nil 892 . 893) (nil fontified nil 878 . 892) (nil fontified nil 877 . 878) (nil fontified nil 869 . 877) (nil fontified nil 854 . 869) (nil fontified nil 852 . 854) (nil fontified nil 851 . 852) (nil fontified nil 843 . 851) (nil fontified nil 840 . 843) (nil fontified nil 839 . 840) (nil fontified nil 817 . 839) (nil fontified nil 816 . 817) (nil fontified nil 795 . 816) (nil fontified nil 794 . 795) (nil fontified nil 786 . 794) (nil fontified nil 758 . 786) (nil fontified nil 756 . 758) (nil fontified nil 755 . 756) (nil fontified nil 748 . 755) (nil fontified nil 747 . 748) (747 . 904) nil ("        // Set renderer color to black
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);

        // Clear renderer
        SDL_RenderClear(renderer);
" . 945) ((marker . 1) . -157) ((marker) . -157) (t 25711 7462 653529 78000) nil ("[" . -1) ((marker . 1) . -1) 2 (t 25711 7455 550234 910000) nil (1289 . 1290) nil (1 . 1289) nil ("#include <SDL2/SDL.h>

int main() {
  // Initialize SDL.
  if (SDL_Init(SDL_INIT_VIDEO) < 0) {
    std::cout << \"SDL could not initialize! SDL_Error: \" << SDL_GetError() << std::endl;
    return -1;
  }

  // Create a window.
  SDL_Window* window = SDL_CreateWindow(\"SDL2 Blue Background\", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 640, 480, SDL_WINDOW_SHOWN);
  if (window == nullptr) {
    std::cout << \"Window could not be created! SDL_Error: \" << SDL_GetError() << std::endl;
    return -1;
  }

  // Create a renderer for the window.
  SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
  if (renderer == nullptr) {
    std::cout << \"Renderer could not be created! SDL_Error: \" << SDL_GetError() << std::endl;
    return -1;
  }

  // Clear the window to blue.
  SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
  SDL_RenderClear(renderer);

  // Present the rendered image to the screen.
  SDL_RenderPresent(renderer);

  // Wait for the user to close the window.
  SDL_Event event;
  while (SDL_PollEvent(&event) != 0) {
    if (event.type == SDL_QUIT) {
      break;
    }
  }

  // Clean up.
  SDL_DestroyRenderer(renderer);
  SDL_DestroyWindow(window);
  SDL_Quit();

  return 0;
}" . 1) ((marker . 40) . -21) ((marker . 1) . -1232) ((marker . 1) . -23) ((marker*) . 1) ((marker) . -1232) ((marker*) . 1198) ((marker) . -35) (nil fontified t 1228 . 1232) (nil fontified t 1222 . 1228) (nil fontified t 1217 . 1222) (nil fontified t 1216 . 1217) (nil fontified t 1215 . 1216) (nil fontified t 1203 . 1215) (nil fontified t 1202 . 1203) (nil fontified t 1196 . 1202) (nil fontified t 1195 . 1196) (nil fontified t 1174 . 1195) (nil fontified t 1173 . 1174) (nil fontified t 1165 . 1173) (nil fontified t 1164 . 1165) (nil fontified t 1146 . 1164) (nil fontified t 1145 . 1146) (nil fontified t 1143 . 1145) (nil fontified t 1133 . 1143) (nil fontified t 1131 . 1133) (nil fontified t 1130 . 1131) (nil fontified t 1128 . 1130) (nil fontified t 1126 . 1128) (nil fontified t 1125 . 1126) (nil fontified t 1122 . 1125) (nil fontified t 1121 . 1122) (nil fontified t 1115 . 1121) (nil fontified t 1110 . 1115) (nil fontified t 1103 . 1110) (nil fontified t 1102 . 1103) (nil fontified t 1101 . 1102) (nil fontified t 1100 . 1101) (nil fontified t 1078 . 1100) (nil fontified t 1077 . 1078) (nil fontified t 1076 . 1077) (nil fontified t 1074 . 1076) (nil fontified t 1069 . 1074) (nil fontified t 1068 . 1069) (nil fontified t 1067 . 1068) (nil fontified t 1066 . 1067) (nil fontified t 1061 . 1066) (nil fontified t 1060 . 1061) (nil fontified t 1054 . 1060) (nil fontified t 1053 . 1054) (nil fontified t 1040 . 1053) (nil fontified t 1039 . 1040) (nil fontified t 1038 . 1039) (nil fontified t 1033 . 1038) (nil fontified t 1029 . 1033) (nil fontified t 1024 . 1029) (nil fontified t 1023 . 1024) (nil fontified t 1022 . 1023) (nil fontified t 1015 . 1022) (nil fontified t 1014 . 1015) (nil fontified t 1012 . 1014) (nil fontified t 973 . 1012) (nil fontified t 971 . 973) (nil fontified t 970 . 971) (nil fontified t 968 . 970) (nil fontified t 965 . 968) (nil fontified t 964 . 965) (nil fontified t 956 . 964) (nil fontified t 955 . 956) (nil fontified t 939 . 955) (nil fontified t 938 . 939) (nil fontified t 936 . 938) (nil fontified t 894 . 936) (nil fontified t 892 . 894) (nil fontified t 891 . 892) (nil fontified t 889 . 891) (nil fontified t 886 . 889) (nil fontified t 885 . 886) (nil fontified t 877 . 885) (nil fontified t 876 . 877) (nil fontified t 857 . 876) (nil fontified t 856 . 857) (nil fontified t 832 . 856) (nil fontified t 831 . 832) (nil fontified t 810 . 831) (nil fontified t 809 . 810) (nil fontified t 807 . 809) (nil fontified t 781 . 807) (nil fontified t 779 . 781) (nil fontified t 778 . 779) (nil fontified t 776 . 778) (nil fontified t 774 . 776) (nil fontified t 773 . 774) (nil fontified t 766 . 773) (nil fontified t 760 . 766) (nil fontified t 748 . 760) (nil fontified t 745 . 748) (nil fontified t 741 . 745) (nil fontified t 740 . 741) (nil fontified t 739 . 740) (nil fontified t 723 . 739) (nil fontified t 679 . 723) (nil fontified t 669 . 679) (nil fontified t 666 . 669) (nil fontified t 661 . 666) (nil fontified t 660 . 661) (nil fontified t 659 . 660) (nil fontified t 658 . 659) (nil fontified t 651 . 658) (nil fontified t 639 . 651) (nil fontified t 638 . 639) (nil fontified t 637 . 638) (nil fontified t 635 . 637) (nil fontified t 631 . 635) (nil fontified t 630 . 631) (nil fontified t 594 . 630) (nil fontified t 593 . 594) (nil fontified t 572 . 593) (nil fontified t 564 . 572) (nil fontified t 562 . 564) (nil fontified t 561 . 562) (nil fontified t 551 . 561) (nil fontified t 550 . 551) (nil fontified t 548 . 550) (nil fontified t 514 . 548) (nil fontified t 512 . 514) (nil fontified t 511 . 512) (nil fontified t 509 . 511) (nil fontified t 507 . 509) (nil fontified t 506 . 507) (nil fontified t 499 . 506) (nil fontified t 493 . 499) (nil fontified t 481 . 493) (nil fontified t 478 . 481) (nil fontified t 474 . 478) (nil fontified t 473 . 474) (nil fontified t 472 . 473) (nil fontified t 456 . 472) (nil fontified t 414 . 456) (nil fontified t 404 . 414) (nil fontified t 401 . 404) (nil fontified t 396 . 401) (nil fontified t 395 . 396) (nil fontified t 394 . 395) (nil fontified t 393 . 394) (nil fontified t 386 . 393) (nil fontified t 376 . 386) (nil fontified t 375 . 376) (nil fontified t 374 . 375) (nil fontified t 372 . 374) (nil fontified t 368 . 372) (nil fontified t 367 . 368) (nil fontified t 289 . 367) (nil fontified t 267 . 289) (nil fontified t 266 . 267) (nil fontified t 247 . 266) (nil fontified t 241 . 247) (nil fontified t 239 . 241) (nil fontified t 238 . 239) (nil fontified t 230 . 238) (nil fontified t 229 . 230) (nil fontified t 227 . 229) (nil fontified t 210 . 227) (nil fontified t 208 . 210) (nil fontified t 207 . 208) (nil fontified t 205 . 207) (nil fontified t 203 . 205) (nil fontified t 202 . 203) (nil fontified t 195 . 202) (nil fontified t 189 . 195) (nil fontified t 177 . 189) (nil fontified t 174 . 177) (nil fontified t 170 . 174) (nil fontified t 169 . 170) (nil fontified t 168 . 169) (nil fontified t 152 . 168) (nil fontified t 113 . 152) (nil fontified t 103 . 113) (nil fontified t 100 . 103) (nil fontified t 95 . 100) (nil fontified t 94 . 95) (nil fontified t 93 . 94) (nil fontified t 92 . 93) (nil fontified t 88 . 92) (nil fontified t 87 . 88) (nil fontified t 73 . 87) (nil fontified t 72 . 73) (nil fontified t 64 . 72) (nil fontified t 63 . 64) (nil fontified t 62 . 63) (nil fontified t 61 . 62) (nil fontified t 60 . 61) (nil fontified t 58 . 60) (nil fontified t 42 . 58) (nil fontified t 40 . 42) (nil fontified t 39 . 40) (nil fontified t 37 . 39) (nil fontified t 36 . 37) (nil fontified t 35 . 36) (nil fontified t 34 . 35) (nil fontified t 33 . 34) (nil fontified t 32 . 33) (nil fontified t 28 . 32) (nil fontified t 27 . 28) (nil fontified t 26 . 27) (nil fontified t 25 . 26) (nil fontified t 24 . 25) (nil fontified t 23 . 24) (nil fontified t 22 . 23) (nil fontified t 21 . 22) (nil fontified t 11 . 21) (nil fontified t 10 . 11) (nil fontified t 9 . 10) (nil fontified t 2 . 9) (nil fontified t 1 . 2) (nil rear-nonsticky t 1232 . 1233) nil ("
" . 1233) nil ("
" . 1) nil ("
" . 1) nil ("#" . 1) ((marker . 40) . -1) ((marker . 1158) . -1) ((marker . 1) . -1) nil ("i" . 2) ((marker . 40) . -1) ((marker . 1) . -1) nil (2 . 3) nil ("inc" . 2) ((marker . 40) . -3) ((marker . 1) . -3) nil (2 . 5) ("include <stdio.h>" . 2) ((marker . 40) . -17) ((marker . 1158) . -14) ((marker . 1) . -14) nil (14 . 16) nil ("lib" . 14) ((marker . 1158) . -3) ((marker . 1) . -3) nil (11 . 17) ("stdlib.h>" . 11) (11 . 20) ("stdl" . 11) (11 . 18) ("stdlib.h>" . 11) ((marker . 40) . -9) nil ("
" . 21) ((marker . 1) . -1) nil (21 . 22) nil (20 . 21) nil ("
" . 1) nil ("#" . 1) ((marker . 40) . -1) ((marker . 1) . -1) ((marker . 1158) . -1) ((marker . 1) . -1) nil ("include " . 2) ((marker . 40) . -8) ((marker . 1) . -8) ((marker . 1158) . -8) ((marker . 1) . -8) nil ("<" . 10) ((marker . 40) . -1) ((marker . 1) . -1) ((marker . 1158) . -1) ((marker . 1) . -1) nil ("stdk" . 11) ((marker . 40) . -4) ((marker . 1) . -4) nil (14 . 15) nil ("lu" . 14) ((marker . 40) . -2) ((marker . 1) . -2) nil (15 . 16) nil (11 . 15) ("stdlib.h>" . 11) ((marker . 40) . -9) ((marker . 1158) . -6) ((marker . 1) . -6) nil (11 . 17) nil (10 . 12) nil ("<." . 10) ((marker . 1) . -1) ((marker . 1158) . -1) nil (11 . 13) nil ("ios" . 11) ((marker . 1158) . -3) ((marker . 1) . -3) nil (11 . 14) ("iostream>" . 11) (20 . 21) (t 25711 7391 933938 992000) nil (">" . 20) ((marker . 40) . -1) (11 . 20) ("ios" . -11) ((marker . 1158) . -3) ((marker . 1) . -3) 14 nil (11 . 14) nil ("." . -11) ((marker . 1) . -1) ("h" . -12) ((marker . 1) . -1) 13 nil (10 . 12) nil ("<" . -10) ((marker . 1) . -1) ((marker . 1158) . -1) ((marker . 1) . -1) ("." . -11) ((marker . 1) . -1) 12 nil ("stdlib" . 11) ((marker . 1158) . -6) ((marker . 1) . -6) ((marker) . -6) 17 (t 25711 7383 83993 572000) nil (11 . 20) ("stdl" . -11) ((marker . 40) . -4) ((marker . 1) . -4) 15 nil ("u" . -15) ((marker . 40) . -1) ((marker . 1) . -1) 16 nil (14 . 16) nil ("k" . -14) ((marker . 40) . -1) ((marker . 1) . -1) 15 nil (11 . 15) nil (10 . 11) nil (2 . 10) nil (1 . 2) nil (1 . 1) (1 . 2) nil ("
" . -20) ((marker . 1) . -1) 21 nil ("
" . -21) ((marker . 1) . -1) 22 nil (21 . 21) (21 . 22) nil (11 . 20) ("stdl.h>" . 11) ((marker . 40) . -7) (11 . 15) ("stdlib.h>" . -11) (11 . 20) ("stdlib" . -11) ((marker . 1158) . -6) ((marker . 1) . -6) 17 nil (14 . 17) nil ("i" . -14) ((marker . 1158) . -1) ((marker . 1) . -1) ("o" . -15) ((marker . 1158) . -1) ((marker . 1) . -1) 16 nil (2 . 19) ("inc" . -2) ((marker . 40) . -3) ((marker . 1) . -3) 5 nil (2 . 5) nil ("i" . -2) ((marker . 40) . -1) ((marker . 1) . -1) 3 nil (2 . 3) nil (1 . 2) nil (1 . 1) (1 . 2) nil (1 . 1) (1 . 2) (t 25711 7358 110717 523000) nil (1233 . 1234) nil (nil rear-nonsticky nil 1232 . 1233) (nil fontified nil 1 . 1233) (1 . 1233) nil ("[#include <iostream>
#include <stdlib.h>
#include <SDL2/SDL.h>

int main() {
    // Initialize SDL and create window with surface and renderer
    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        std::cout << \"SDL could not initialize! SDL Error: \" << SDL_GetError() << std::endl;
        return 1;
    }
    else {
        std::cout << \"SDL successfully initialized!\" << std::endl;
    }

    SDL_Window* window = SDL_CreateWindow(\"SDL Tutorial\", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 480, 640, SDL_WINDOW_SHOWN);
    SDL_Surface* surface = SDL_GetWindowSurface(window);

    // Create a renderer associated with the window
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    // Add main loop here

    bool quit = false;
    while (!quit) {
        SDL_Event e;
        while (SDL_PollEvent(&e) != 0) {
            if (e.type == SDL_QUIT) {
                quit = true;
            }
        }

        // Set renderer color to black
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);

        // Clear renderer
        SDL_RenderClear(renderer);

        // Update screen
        SDL_RenderPresent(renderer);
    }

    // Clean up
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);

    SDL_Quit();
    return 0;
}
]" . 1) ((marker . 40) . -20) ((marker . 1) . -1288) ((marker . 1286) . -1286) ((marker*) . 1288) ((marker) . -1) ((marker*) . 1) ((marker) . -1288) ((marker . 1286) . -1288) ((marker) . -1288) 1289 nil (1288 . 1289) ("]" . 2) (1 . 2) (1 . 2) (t 25711 7219 754099 132000) nil (1286 . 1287) nil (nil rear-nonsticky nil 1285 . 1286) (nil fontified nil 1 . 1286) (1 . 1286) nil ("#include <iostream>
#include <stdlib.h>
#include <SDL2/SDL.h>

int main() {
    // Initialize SDL and create window with surface and renderer
    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        std::cout << \"SDL could not initialize! SDL Error: \" << SDL_GetError() << std::endl;
        return 1;
    }
    else {
        std::cout << \"SDL successfully initialized!\" << std::endl;
    }

    SDL_Window* window = SDL_CreateWindow(\"SDL Tutorial\", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 480, 640, SDL_WINDOW_SHOWN);
    SDL_Surface* surface = SDL_GetWindowSurface(window);
    
    // Create a renderer associated with the window
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    // Add main loop here

    bool quit = false;
    while (!quit) {
        SDL_Event e;
        while (SDL_PollEvent(&e) != 0) {
            if (e.type == SDL_QUIT) {
                quit = true;
            }
        }

        // Set renderer color to black
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);

        // Clear renderer
        SDL_RenderClear(renderer);

        // Update screen
        SDL_RenderPresent(renderer);
    }

    // Clean up
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);

    SDL_Quit();
    return 0;
}
" . 1) ((marker . 40) . -19) ((marker . 1) . -1290) ((marker . 1) . -1290) ((marker) . -1290) 1291 (t 25711 7142 787456 230000) nil (1290 . 1291) nil (nil rear-nonsticky nil 1289 . 1290) (nil fontified nil 1 . 1290) (1 . 1290) nil ("#include <iostream>
#include <stdlib.h>
#include <SDL2/SDL.h>

int main(){
	// Initialize SDL and create window with surface and renderer
	if(SDL_Init(SDL_INIT_VIDEO)!= 0){
		std::cout << \"SDL could not initialize! SDL Error: \" << SDL_GetError() << std::endl;
		return 1;
	}
	else{
		std::cout << \"SDL successfully initialized!\" << std::endl;
	}
	SDL_Window* window = SDL_CreateWindow(\"SDL Tutorial\", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 480, 640, SDL_WINDOW_SHOWN);
	SDL_Surface* surface = SDL_GetWindowSurface(window);
	SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
	
	bool quit = false;
	while(!quit){
		SDL_Event e;
		while(SDL_PollEvent(&e)!= 0){
			if(e.type == SDL_QUIT){
				quit = true;
			}
			// set renderer color  to black
			SDL_SetRenderDrawColor(renderer, 0, 0,  0, 255);
			// clear renderer
			SDL_RenderClear(renderer);
			// update screen
			SDL_RenderPresent(renderer);
		}
	}
	
	// Clean up
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	
	SDL_Quit();
	return 0;
}
" . 1) ((marker . 40) . -19) ((marker . 1) . -1051) ((marker . 1) . -617) ((marker . 1) . -617) ((marker . 1) . -617) ((marker . 1) . -617) ((marker) . -1051) ((marker . 1) . -1048) ((marker . 1) . -1048) 1049 (t 25711 7024 527487 368000) nil ("
" . -618) ((marker . 1) . -1) ((marker . 1158) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) (" " . -619) ((marker . 1) . -1) ((marker . 1158) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) (" " . -620) ((marker . 1) . -1) ((marker . 1158) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ("	" . 621) ((marker . 1) . -1) ((marker . 1158) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) (619 . 621) 620 nil ("
 SDL_SetRenderTarget(renderer, surface);
	// Create a texture from the surface
	" . 620) ((marker . 1) . -81) ((marker . 1158) . -29) ((marker . 1) . -2) ((marker . 1) . -78) ((marker . 1) . -78) ((marker) . -81) nil ("  " . 700) (701 . 703) nil (698 . 701) nil (621 . 622) ("	" . 621) (t 25711 6998 327493 247000) nil (621 . 622) (" " . 621) ((marker . 1) . -1) nil ("e
 " . 698) ((marker . 1) . -3) ((marker . 1158) . -3) ((marker . 1) . -3) ((marker . 1) . -3) nil (" 	" . 701) ((marker . 1) . -2) ((marker . 1158) . -2) ((marker . 1) . -2) ((marker . 1) . -2) (700 . 702) nil ("SDL_Texture* texture" . 701) ((marker . 1) . -20) ((marker . 1158) . -20) ((marker . 1) . -20) ((marker . 1) . -20) nil (701 . 721) nil ("  " . 700) (701 . 703) nil (698 . 701) nil (621 . 622) ("	" . 621) (t 25711 6998 327493 247000) nil (621 . 622) (" " . 621) ((marker . 1) . -1) nil ("e
 " . 698) ((marker . 1158) . -3) ((marker . 1) . -3) nil (" 	" . 701) ((marker . 1158) . -2) ((marker . 1) . -2) (700 . 702) nil ("SDL_Texture* texture" . 701) ((marker . 1158) . -20) nil (701 . 721) nil ("  " . 700) (701 . 703) nil (698 . 701) nil (621 . 622) ("	" . 621) ((marker) . -1) (t 25711 6998 327493 247000) nil (621 . 622) (" " . 621) ((marker . 1) . -1) 658 nil ("e" . -698) ((marker . 1158) . -1) ((marker . 1) . -1) ("
" . -699) ((marker . 1158) . -1) ((marker . 1) . -1) (" " . -700) ((marker . 1158) . -1) ((marker . 1) . -1) 701 nil (" " . -701) ((marker . 1158) . -1) ((marker . 1) . -1) ("	" . 702) ((marker . 1158) . -1) ((marker . 1) . -1) (700 . 702) 701 nil ("S" . -701) ((marker . 1158) . -1) ((marker . 1) . -1) ("D" . -702) ((marker . 1158) . -1) ((marker . 1) . -1) ("L" . -703) ((marker . 1158) . -1) ((marker . 1) . -1) ("_" . -704) ((marker . 1158) . -1) ((marker . 1) . -1) ("T" . -705) ((marker . 1158) . -1) ((marker . 1) . -1) ("e" . -706) ((marker . 1158) . -1) ((marker . 1) . -1) ("x" . -707) ((marker . 1158) . -1) ((marker . 1) . -1) ("t" . -708) ((marker . 1158) . -1) ((marker . 1) . -1) ("u" . -709) ((marker . 1158) . -1) ((marker . 1) . -1) ("r" . -710) ((marker . 1158) . -1) ((marker . 1) . -1) ("e" . -711) ((marker . 1158) . -1) ((marker . 1) . -1) ("*" . -712) ((marker . 1158) . -1) ((marker . 1) . -1) (" " . -713) ((marker . 1158) . -1) ((marker . 1) . -1) ("t" . -714) ((marker . 1158) . -1) ((marker . 1) . -1) ("e" . -715) ((marker . 1158) . -1) ((marker . 1) . -1) ("x" . -716) ((marker . 1158) . -1) ((marker . 1) . -1) ("t" . -717) ((marker . 1158) . -1) ((marker . 1) . -1) ("u" . -718) ((marker . 1158) . -1) ((marker . 1) . -1) ("r" . -719) ((marker . 1158) . -1) ((marker . 1) . -1) ("e" . -720) ((marker . 1158) . -1) ((marker . 1) . -1) 721) (emacs-pending-undo-list (1 . 1289) nil ("#include <SDL2/SDL.h>

int main() {
  // Initialize SDL.
  if (SDL_Init(SDL_INIT_VIDEO) < 0) {
    std::cout << \"SDL could not initialize! SDL_Error: \" << SDL_GetError() << std::endl;
    return -1;
  }

  // Create a window.
  SDL_Window* window = SDL_CreateWindow(\"SDL2 Blue Background\", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 640, 480, SDL_WINDOW_SHOWN);
  if (window == nullptr) {
    std::cout << \"Window could not be created! SDL_Error: \" << SDL_GetError() << std::endl;
    return -1;
  }

  // Create a renderer for the window.
  SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
  if (renderer == nullptr) {
    std::cout << \"Renderer could not be created! SDL_Error: \" << SDL_GetError() << std::endl;
    return -1;
  }

  // Clear the window to blue.
  SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
  SDL_RenderClear(renderer);

  // Present the rendered image to the screen.
  SDL_RenderPresent(renderer);

  // Wait for the user to close the window.
  SDL_Event event;
  while (SDL_PollEvent(&event) != 0) {
    if (event.type == SDL_QUIT) {
      break;
    }
  }

  // Clean up.
  SDL_DestroyRenderer(renderer);
  SDL_DestroyWindow(window);
  SDL_Quit();

  return 0;
}" . 1) ((marker . 40) . -21) ((marker . 1) . -1232) ((marker . 1) . -23) ((marker*) . 1) ((marker) . -1232) ((marker*) . 1198) ((marker) . -35) (nil fontified t 1228 . 1232) (nil fontified t 1222 . 1228) (nil fontified t 1217 . 1222) (nil fontified t 1216 . 1217) (nil fontified t 1215 . 1216) (nil fontified t 1203 . 1215) (nil fontified t 1202 . 1203) (nil fontified t 1196 . 1202) (nil fontified t 1195 . 1196) (nil fontified t 1174 . 1195) (nil fontified t 1173 . 1174) (nil fontified t 1165 . 1173) (nil fontified t 1164 . 1165) (nil fontified t 1146 . 1164) (nil fontified t 1145 . 1146) (nil fontified t 1143 . 1145) (nil fontified t 1133 . 1143) (nil fontified t 1131 . 1133) (nil fontified t 1130 . 1131) (nil fontified t 1128 . 1130) (nil fontified t 1126 . 1128) (nil fontified t 1125 . 1126) (nil fontified t 1122 . 1125) (nil fontified t 1121 . 1122) (nil fontified t 1115 . 1121) (nil fontified t 1110 . 1115) (nil fontified t 1103 . 1110) (nil fontified t 1102 . 1103) (nil fontified t 1101 . 1102) (nil fontified t 1100 . 1101) (nil fontified t 1078 . 1100) (nil fontified t 1077 . 1078) (nil fontified t 1076 . 1077) (nil fontified t 1074 . 1076) (nil fontified t 1069 . 1074) (nil fontified t 1068 . 1069) (nil fontified t 1067 . 1068) (nil fontified t 1066 . 1067) (nil fontified t 1061 . 1066) (nil fontified t 1060 . 1061) (nil fontified t 1054 . 1060) (nil fontified t 1053 . 1054) (nil fontified t 1040 . 1053) (nil fontified t 1039 . 1040) (nil fontified t 1038 . 1039) (nil fontified t 1033 . 1038) (nil fontified t 1029 . 1033) (nil fontified t 1024 . 1029) (nil fontified t 1023 . 1024) (nil fontified t 1022 . 1023) (nil fontified t 1015 . 1022) (nil fontified t 1014 . 1015) (nil fontified t 1012 . 1014) (nil fontified t 973 . 1012) (nil fontified t 971 . 973) (nil fontified t 970 . 971) (nil fontified t 968 . 970) (nil fontified t 965 . 968) (nil fontified t 964 . 965) (nil fontified t 956 . 964) (nil fontified t 955 . 956) (nil fontified t 939 . 955) (nil fontified t 938 . 939) (nil fontified t 936 . 938) (nil fontified t 894 . 936) (nil fontified t 892 . 894) (nil fontified t 891 . 892) (nil fontified t 889 . 891) (nil fontified t 886 . 889) (nil fontified t 885 . 886) (nil fontified t 877 . 885) (nil fontified t 876 . 877) (nil fontified t 857 . 876) (nil fontified t 856 . 857) (nil fontified t 832 . 856) (nil fontified t 831 . 832) (nil fontified t 810 . 831) (nil fontified t 809 . 810) (nil fontified t 807 . 809) (nil fontified t 781 . 807) (nil fontified t 779 . 781) (nil fontified t 778 . 779) (nil fontified t 776 . 778) (nil fontified t 774 . 776) (nil fontified t 773 . 774) (nil fontified t 766 . 773) (nil fontified t 760 . 766) (nil fontified t 748 . 760) (nil fontified t 745 . 748) (nil fontified t 741 . 745) (nil fontified t 740 . 741) (nil fontified t 739 . 740) (nil fontified t 723 . 739) (nil fontified t 679 . 723) (nil fontified t 669 . 679) (nil fontified t 666 . 669) (nil fontified t 661 . 666) (nil fontified t 660 . 661) (nil fontified t 659 . 660) (nil fontified t 658 . 659) (nil fontified t 651 . 658) (nil fontified t 639 . 651) (nil fontified t 638 . 639) (nil fontified t 637 . 638) (nil fontified t 635 . 637) (nil fontified t 631 . 635) (nil fontified t 630 . 631) (nil fontified t 594 . 630) (nil fontified t 593 . 594) (nil fontified t 572 . 593) (nil fontified t 564 . 572) (nil fontified t 562 . 564) (nil fontified t 561 . 562) (nil fontified t 551 . 561) (nil fontified t 550 . 551) (nil fontified t 548 . 550) (nil fontified t 514 . 548) (nil fontified t 512 . 514) (nil fontified t 511 . 512) (nil fontified t 509 . 511) (nil fontified t 507 . 509) (nil fontified t 506 . 507) (nil fontified t 499 . 506) (nil fontified t 493 . 499) (nil fontified t 481 . 493) (nil fontified t 478 . 481) (nil fontified t 474 . 478) (nil fontified t 473 . 474) (nil fontified t 472 . 473) (nil fontified t 456 . 472) (nil fontified t 414 . 456) (nil fontified t 404 . 414) (nil fontified t 401 . 404) (nil fontified t 396 . 401) (nil fontified t 395 . 396) (nil fontified t 394 . 395) (nil fontified t 393 . 394) (nil fontified t 386 . 393) (nil fontified t 376 . 386) (nil fontified t 375 . 376) (nil fontified t 374 . 375) (nil fontified t 372 . 374) (nil fontified t 368 . 372) (nil fontified t 367 . 368) (nil fontified t 289 . 367) (nil fontified t 267 . 289) (nil fontified t 266 . 267) (nil fontified t 247 . 266) (nil fontified t 241 . 247) (nil fontified t 239 . 241) (nil fontified t 238 . 239) (nil fontified t 230 . 238) (nil fontified t 229 . 230) (nil fontified t 227 . 229) (nil fontified t 210 . 227) (nil fontified t 208 . 210) (nil fontified t 207 . 208) (nil fontified t 205 . 207) (nil fontified t 203 . 205) (nil fontified t 202 . 203) (nil fontified t 195 . 202) (nil fontified t 189 . 195) (nil fontified t 177 . 189) (nil fontified t 174 . 177) (nil fontified t 170 . 174) (nil fontified t 169 . 170) (nil fontified t 168 . 169) (nil fontified t 152 . 168) (nil fontified t 113 . 152) (nil fontified t 103 . 113) (nil fontified t 100 . 103) (nil fontified t 95 . 100) (nil fontified t 94 . 95) (nil fontified t 93 . 94) (nil fontified t 92 . 93) (nil fontified t 88 . 92) (nil fontified t 87 . 88) (nil fontified t 73 . 87) (nil fontified t 72 . 73) (nil fontified t 64 . 72) (nil fontified t 63 . 64) (nil fontified t 62 . 63) (nil fontified t 61 . 62) (nil fontified t 60 . 61) (nil fontified t 58 . 60) (nil fontified t 42 . 58) (nil fontified t 40 . 42) (nil fontified t 39 . 40) (nil fontified t 37 . 39) (nil fontified t 36 . 37) (nil fontified t 35 . 36) (nil fontified t 34 . 35) (nil fontified t 33 . 34) (nil fontified t 32 . 33) (nil fontified t 28 . 32) (nil fontified t 27 . 28) (nil fontified t 26 . 27) (nil fontified t 25 . 26) (nil fontified t 24 . 25) (nil fontified t 23 . 24) (nil fontified t 22 . 23) (nil fontified t 21 . 22) (nil fontified t 11 . 21) (nil fontified t 10 . 11) (nil fontified t 9 . 10) (nil fontified t 2 . 9) (nil fontified t 1 . 2) (nil rear-nonsticky t 1232 . 1233) nil ("
" . 1233) nil ("
" . 1) nil ("
" . 1) nil ("#" . 1) ((marker . 40) . -1) ((marker . 1158) . -1) ((marker . 1) . -1) nil ("i" . 2) ((marker . 40) . -1) ((marker . 1) . -1) nil (2 . 3) nil ("inc" . 2) ((marker . 40) . -3) ((marker . 1) . -3) nil (2 . 5) ("include <stdio.h>" . 2) ((marker . 40) . -17) ((marker . 1158) . -14) ((marker . 1) . -14) nil (14 . 16) nil ("lib" . 14) ((marker . 1158) . -3) ((marker . 1) . -3) nil (11 . 17) ("stdlib.h>" . 11) (11 . 20) ("stdl" . 11) (11 . 18) ("stdlib.h>" . 11) ((marker . 40) . -9) nil ("
" . 21) ((marker . 1) . -1) nil (21 . 22) nil (20 . 21) nil ("
" . 1) nil ("#" . 1) ((marker . 40) . -1) ((marker . 1) . -1) ((marker . 1158) . -1) ((marker . 1) . -1) nil ("include " . 2) ((marker . 40) . -8) ((marker . 1) . -8) ((marker . 1158) . -8) ((marker . 1) . -8) nil ("<" . 10) ((marker . 40) . -1) ((marker . 1) . -1) ((marker . 1158) . -1) ((marker . 1) . -1) nil ("stdk" . 11) ((marker . 40) . -4) ((marker . 1) . -4) nil (14 . 15) nil ("lu" . 14) ((marker . 40) . -2) ((marker . 1) . -2) nil (15 . 16) nil (11 . 15) ("stdlib.h>" . 11) ((marker . 40) . -9) ((marker . 1158) . -6) ((marker . 1) . -6) nil (11 . 17) nil (10 . 12) nil ("<." . 10) ((marker . 1) . -1) ((marker . 1158) . -1) nil (11 . 13) nil ("ios" . 11) ((marker . 1158) . -3) ((marker . 1) . -3) nil (11 . 14) ("iostream>" . 11) (20 . 21) (t 25711 7391 933938 992000) nil (">" . 20) ((marker . 40) . -1) (11 . 20) ("ios" . -11) ((marker . 1158) . -3) ((marker . 1) . -3) 14 nil (11 . 14) nil ("." . -11) ((marker . 1) . -1) ("h" . -12) ((marker . 1) . -1) 13 nil (10 . 12) nil ("<" . -10) ((marker . 1) . -1) ((marker . 1158) . -1) ((marker . 1) . -1) ("." . -11) ((marker . 1) . -1) 12 nil ("stdlib" . 11) ((marker . 1158) . -6) ((marker . 1) . -6) ((marker) . -6) 17 (t 25711 7383 83993 572000) nil (11 . 20) ("stdl" . -11) ((marker . 40) . -4) ((marker . 1) . -4) 15 nil ("u" . -15) ((marker . 40) . -1) ((marker . 1) . -1) 16 nil (14 . 16) nil ("k" . -14) ((marker . 40) . -1) ((marker . 1) . -1) 15 nil (11 . 15) nil (10 . 11) nil (2 . 10) nil (1 . 2) nil (1 . 1) (1 . 2) nil ("
" . -20) ((marker . 1) . -1) 21 nil ("
" . -21) ((marker . 1) . -1) 22 nil (21 . 21) (21 . 22) nil (11 . 20) ("stdl.h>" . 11) ((marker . 40) . -7) (11 . 15) ("stdlib.h>" . -11) (11 . 20) ("stdlib" . -11) ((marker . 1158) . -6) ((marker . 1) . -6) 17 nil (14 . 17) nil ("i" . -14) ((marker . 1158) . -1) ((marker . 1) . -1) ("o" . -15) ((marker . 1158) . -1) ((marker . 1) . -1) 16 nil (2 . 19) ("inc" . -2) ((marker . 40) . -3) ((marker . 1) . -3) 5 nil (2 . 5) nil ("i" . -2) ((marker . 40) . -1) ((marker . 1) . -1) 3 nil (2 . 3) nil (1 . 2) nil (1 . 1) (1 . 2) nil (1 . 1) (1 . 2) (t 25711 7358 110717 523000) nil (1233 . 1234) nil (nil rear-nonsticky nil 1232 . 1233) (nil fontified nil 1 . 1233) (1 . 1233) nil ("[#include <iostream>
#include <stdlib.h>
#include <SDL2/SDL.h>

int main() {
    // Initialize SDL and create window with surface and renderer
    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        std::cout << \"SDL could not initialize! SDL Error: \" << SDL_GetError() << std::endl;
        return 1;
    }
    else {
        std::cout << \"SDL successfully initialized!\" << std::endl;
    }

    SDL_Window* window = SDL_CreateWindow(\"SDL Tutorial\", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 480, 640, SDL_WINDOW_SHOWN);
    SDL_Surface* surface = SDL_GetWindowSurface(window);

    // Create a renderer associated with the window
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    // Add main loop here

    bool quit = false;
    while (!quit) {
        SDL_Event e;
        while (SDL_PollEvent(&e) != 0) {
            if (e.type == SDL_QUIT) {
                quit = true;
            }
        }

        // Set renderer color to black
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);

        // Clear renderer
        SDL_RenderClear(renderer);

        // Update screen
        SDL_RenderPresent(renderer);
    }

    // Clean up
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);

    SDL_Quit();
    return 0;
}
]" . 1) ((marker . 40) . -20) ((marker . 1) . -1288) ((marker . 1286) . -1286) ((marker*) . 1288) ((marker) . -1) ((marker*) . 1) ((marker) . -1288) ((marker . 1286) . -1288) ((marker) . -1288) 1289 nil (1288 . 1289) ("]" . 2) (1 . 2) (1 . 2) (t 25711 7219 754099 132000) nil (1286 . 1287) nil (nil rear-nonsticky nil 1285 . 1286) (nil fontified nil 1 . 1286) (1 . 1286) nil ("#include <iostream>
#include <stdlib.h>
#include <SDL2/SDL.h>

int main() {
    // Initialize SDL and create window with surface and renderer
    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        std::cout << \"SDL could not initialize! SDL Error: \" << SDL_GetError() << std::endl;
        return 1;
    }
    else {
        std::cout << \"SDL successfully initialized!\" << std::endl;
    }

    SDL_Window* window = SDL_CreateWindow(\"SDL Tutorial\", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 480, 640, SDL_WINDOW_SHOWN);
    SDL_Surface* surface = SDL_GetWindowSurface(window);
    
    // Create a renderer associated with the window
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    // Add main loop here

    bool quit = false;
    while (!quit) {
        SDL_Event e;
        while (SDL_PollEvent(&e) != 0) {
            if (e.type == SDL_QUIT) {
                quit = true;
            }
        }

        // Set renderer color to black
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);

        // Clear renderer
        SDL_RenderClear(renderer);

        // Update screen
        SDL_RenderPresent(renderer);
    }

    // Clean up
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);

    SDL_Quit();
    return 0;
}
" . 1) ((marker . 40) . -19) ((marker . 1) . -1290) ((marker . 1) . -1290) ((marker) . -1290) 1291 (t 25711 7142 787456 230000) nil (1290 . 1291) nil (nil rear-nonsticky nil 1289 . 1290) (nil fontified nil 1 . 1290) (1 . 1290) nil ("#include <iostream>
#include <stdlib.h>
#include <SDL2/SDL.h>

int main(){
	// Initialize SDL and create window with surface and renderer
	if(SDL_Init(SDL_INIT_VIDEO)!= 0){
		std::cout << \"SDL could not initialize! SDL Error: \" << SDL_GetError() << std::endl;
		return 1;
	}
	else{
		std::cout << \"SDL successfully initialized!\" << std::endl;
	}
	SDL_Window* window = SDL_CreateWindow(\"SDL Tutorial\", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 480, 640, SDL_WINDOW_SHOWN);
	SDL_Surface* surface = SDL_GetWindowSurface(window);
	SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
	
	bool quit = false;
	while(!quit){
		SDL_Event e;
		while(SDL_PollEvent(&e)!= 0){
			if(e.type == SDL_QUIT){
				quit = true;
			}
			// set renderer color  to black
			SDL_SetRenderDrawColor(renderer, 0, 0,  0, 255);
			// clear renderer
			SDL_RenderClear(renderer);
			// update screen
			SDL_RenderPresent(renderer);
		}
	}
	
	// Clean up
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	
	SDL_Quit();
	return 0;
}
" . 1) ((marker . 40) . -19) ((marker . 1) . -1051) ((marker . 1) . -617) ((marker . 1) . -617) ((marker . 1) . -617) ((marker . 1) . -617) ((marker) . -1051) ((marker . 1) . -1048) ((marker . 1) . -1048) 1049 (t 25711 7024 527487 368000) nil ("
" . -618) ((marker . 1) . -1) ((marker . 1158) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) (" " . -619) ((marker . 1) . -1) ((marker . 1158) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) (" " . -620) ((marker . 1) . -1) ((marker . 1158) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ("	" . 621) ((marker . 1) . -1) ((marker . 1158) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) (619 . 621) 620 nil ("
 SDL_SetRenderTarget(renderer, surface);
	// Create a texture from the surface
	" . 620) ((marker . 1) . -81) ((marker . 1158) . -29) ((marker . 1) . -2) ((marker . 1) . -78) ((marker . 1) . -78) ((marker) . -81) nil ("  " . 700) (701 . 703) nil (698 . 701) nil (621 . 622) ("	" . 621) (t 25711 6998 327493 247000) nil (621 . 622) (" " . 621) ((marker . 1) . -1) nil ("e
 " . 698) ((marker . 1) . -3) ((marker . 1158) . -3) ((marker . 1) . -3) ((marker . 1) . -3) nil (" 	" . 701) ((marker . 1) . -2) ((marker . 1158) . -2) ((marker . 1) . -2) ((marker . 1) . -2) (700 . 702) nil ("SDL_Texture* texture" . 701) ((marker . 1) . -20) ((marker . 1158) . -20) ((marker . 1) . -20) ((marker . 1) . -20) nil (701 . 721) nil ("  " . 700) (701 . 703) nil (698 . 701) nil (621 . 622) ("	" . 621) (t 25711 6998 327493 247000) nil (621 . 622) (" " . 621) ((marker . 1) . -1) nil ("e
 " . 698) ((marker . 1158) . -3) ((marker . 1) . -3) nil (" 	" . 701) ((marker . 1158) . -2) ((marker . 1) . -2) (700 . 702) nil ("SDL_Texture* texture" . 701) ((marker . 1158) . -20) nil (701 . 721) nil ("  " . 700) (701 . 703) nil (698 . 701) nil (621 . 622) ("	" . 621) ((marker) . -1) (t 25711 6998 327493 247000) nil (621 . 622) (" " . 621) ((marker . 1) . -1) 658 nil ("e" . -698) ((marker . 1158) . -1) ((marker . 1) . -1) ("
" . -699) ((marker . 1158) . -1) ((marker . 1) . -1) (" " . -700) ((marker . 1158) . -1) ((marker . 1) . -1) 701 nil (" " . -701) ((marker . 1158) . -1) ((marker . 1) . -1) ("	" . 702) ((marker . 1158) . -1) ((marker . 1) . -1) (700 . 702) 701 nil ("S" . -701) ((marker . 1158) . -1) ((marker . 1) . -1) ("D" . -702) ((marker . 1158) . -1) ((marker . 1) . -1) ("L" . -703) ((marker . 1158) . -1) ((marker . 1) . -1) ("_" . -704) ((marker . 1158) . -1) ((marker . 1) . -1) ("T" . -705) ((marker . 1158) . -1) ((marker . 1) . -1) ("e" . -706) ((marker . 1158) . -1) ((marker . 1) . -1) ("x" . -707) ((marker . 1158) . -1) ((marker . 1) . -1) ("t" . -708) ((marker . 1158) . -1) ((marker . 1) . -1) ("u" . -709) ((marker . 1158) . -1) ((marker . 1) . -1) ("r" . -710) ((marker . 1158) . -1) ((marker . 1) . -1) ("e" . -711) ((marker . 1158) . -1) ((marker . 1) . -1) ("*" . -712) ((marker . 1158) . -1) ((marker . 1) . -1) (" " . -713) ((marker . 1158) . -1) ((marker . 1) . -1) ("t" . -714) ((marker . 1158) . -1) ((marker . 1) . -1) ("e" . -715) ((marker . 1158) . -1) ((marker . 1) . -1) ("x" . -716) ((marker . 1158) . -1) ((marker . 1) . -1) ("t" . -717) ((marker . 1158) . -1) ((marker . 1) . -1) ("u" . -718) ((marker . 1158) . -1) ((marker . 1) . -1) ("r" . -719) ((marker . 1158) . -1) ((marker . 1) . -1) ("e" . -720) ((marker . 1158) . -1) ((marker . 1) . -1) 721) (emacs-undo-equiv-table (4 . -1) (5 . 39) (6 . 38) (7 . 37) (8 . 36) (9 . 35) (10 . 34) (11 . 33) (12 . 32) (13 . 31) (14 . 30) (15 . 29) (16 . 28) (19 . 25) (17 . 27) (18 . 26) (20 . 24) (21 . 23) (22 . 38) (23 . 37) (24 . 36) (25 . 35) (26 . 34) (27 . 33) (28 . 32) (29 . 31) (-75 . -83) (-23 . -41) (-1 . -63) (-15 . -49) (-84 . -90) (-2 . -62) (-83 . -91) (-10 . -54) (-82 . -92) (-29 . -35) (-81 . -93) (-4 . -60) (-11 . -53) (-18 . -46) (-25 . -39) (-79 . t) (-73 . -85) (-31 . -33) (-5 . -59) (-76 . -82) (-35 . -37) (-12 . -52) (-21 . -43) (-86 . -88) (-72 . -86) (-77 . -81) (-13 . -51) (-24 . -40) (-30 . -34) (-74 . -84) (-9 . -55) (-19 . -45) (-22 . -42) (-28 . -36) (-78 . -80) (-26 . -38) (-6 . -58) (-16 . -48) (-27 . -37) (-85 . -89) (-7 . -57) (-17 . -47) (-20 . -44) (-3 . -61) (-14 . -50) (-8 . -56) (-80 . -94)))