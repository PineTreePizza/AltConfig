((buffer-size . 0) (buffer-checksum . "da39a3ee5e6b4b0d3255bfef95601890afd80709"))
((emacs-buffer-undo-list nil ("$" . -1) ((marker . 10689) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker) . -1) ((marker) . -1) 2 nil (1 . 2) nil ("#" . -1) ((marker . 10689) . -1) 2 nil (1 . 2) nil ("$" . -1) ((marker . 10689) . -1) 2 nil (1 . 2) (t 25653 23901 683492 453000)) (emacs-pending-undo-list ("x" . -10676) ((marker . 10689) . -1) 10677 nil (10676 . 10677) (t 25697 65324 713714 341000) nil ("
" . -10684) (" " . -10685) (" " . -10686) 10687 (t 25697 65322 860349 65000) nil (10653 . 10656) (" " . 10652) (10653 . 10654) (t 25697 65319 553625 448000) nil (nil rear-nonsticky nil 10680 . 10681) (nil fontified nil 10647 . 10681) (10647 . 10681) nil (10644 . 10647) nil (10642 . 10644) nil ("o" . -10642) ("g" . -10643) (" " . -10644) 10645 nil (10637 . 10645) nil (10634 . 10637) (t 25697 65287 423074 933000) nil (" " . -11082) 11083 nil (11074 . 11083) nil ("flymake" . 11074) 11081 (t 25697 65239 582265 377000) nil (nil rear-nonsticky nil 10633 . 10634) (nil fontified nil 10606 . 10634) (10606 . 10634) nil (":" . -10606) ("i" . -10607) ("n" . -10608) ("i" . -10609) ("t" . -10610) 10611 nil (":init (global-flycheck-mode)" . 10611) (nil rear-nonsticky t 10638 . 10639) nil (nil rear-nonsticky nil 10638 . 10639) (nil fontified nil 10611 . 10639) (10611 . 10639) nil ("
  (add-hook 'after-init-hook #'global-flycheck-mode)
" . 10611) (t 25697 65212 35138 458000) nil (10666 . 10668) ("  " . 10665) (10667 . 10668) nil (10665 . 10667) (t 25697 65210 831785 123000) nil (nil rear-nonsticky nil 10664 . 10665) (nil fontified nil 10614 . 10665) (10614 . 10665) nil (10612 . 10614) (" " . 10611) (10612 . 10613) nil ("(add-hook 'after-init-hook #'global-flycheck-mode)
" . 10614) (nil rear-nonsticky t 10664 . 10665) (t 25697 65206 538380 498000) nil (nil rear-nonsticky nil 10664 . 10665) (nil fontified nil 10614 . 10665) (10614 . 10665) nil (10613 . 10614) (t 25697 65156 10883 574000) nil (10607 . 10612) nil (10606 . 10607) (t 25697 65153 320839 843000) nil (10603 . 10606) nil (10602 . 10603) nil ("1" . -10602) 10603 nil (10594 . 10603) nil (10591 . 10594) nil (10571 . 10591) (10570 . 10572) ("(" . -10570) (10570 . 10571) (t 25697 65133 477185 451000) nil (";; Load Flymake
(require 'flymake)

;; Enable Flymake globally
(add-hook 'prog-mode-hook 'flymake-mode)

(setq flymake-fringe-indicator-position 'left-fringe)

;; Set Flymake error message level
(setq flymake-log-level 1)

(use-package flymake-python-pyflakes
  :ensure t)
(add-hook 'python-mode-hook 'flymake-python-pyflakes-load)" . 10570) (t 25697 64982 171504 241000) nil (nil rear-nonsticky nil 10900 . 10901) (nil fontified nil 10843 . 10901) (10843 . 10901) nil (10842 . 10843) (t 25697 64975 864744 24000) nil (nil rear-nonsticky nil 10841 . 10842) (nil fontified nil 10793 . 10842) (10793 . 10842) nil ("(" . -10793) ("u" . -10794) ("s" . -10795) ("e" . -10796) 10797) (emacs-undo-equiv-table))